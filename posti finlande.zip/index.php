<?php 
header("location: home/land.php");
?>