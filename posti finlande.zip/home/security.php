<?php
/**
 * Security & Antibot System
 * Only allows IPs from Finland (FI) and France (FR)
 * Blocks VPNs, Proxies, Hosting, and Bots
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Allowed countries
$allowedCountries = ['FI', 'FR'];

// Get real IP address
function getRealIP() {
    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }

    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : $_SERVER['REMOTE_ADDR'];
}

$userIP = getRealIP();

// Skip check for localhost
if (in_array($userIP, ['127.0.0.1', '::1', 'localhost'])) {
    $_SESSION['security_passed'] = true;
    $_SESSION['ip_info'] = [
        'ip' => $userIP,
        'city' => 'Localhost',
        'country' => 'Local',
        'countryCode' => 'FI',
        'isp' => 'Local',
        'proxy' => false,
        'hosting' => false,
        'mobile' => false
    ];
    return;
}

// Check if already verified in this session
if (isset($_SESSION['security_passed']) && $_SESSION['security_passed'] === true) {
    // Re-check every 5 minutes
    if (isset($_SESSION['security_time']) && (time() - $_SESSION['security_time']) < 300) {
        return;
    }
}

// Fetch IP data from pro.ip-api.com
$apiUrl = "https://pro.ip-api.com/json/{$userIP}?key=NCx0PDVOcBsh1pQ&fields=21164031";
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_TIMEOUT, 10);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

$data = @json_decode($response, true);

// Default values if API fails
if ($data === null || !isset($data['status']) || $data['status'] !== 'success') {
    $data = [
        'ip' => $userIP,
        'isp' => 'Unknown ISP',
        'org' => 'Unknown Org',
        'proxy' => true,  // Block by default if can't verify
        'country' => 'Unknown Country',
        'countryCode' => 'XX',
        'hosting' => true,
        'city' => 'Unknown City',
        'zip' => 'Unknown Zip',
        'as' => 'Unknown AS',
        'mobile' => false
    ];
}

// Store IP info in session
$_SESSION['ip_info'] = [
    'ip' => $userIP,
    'city' => $data['city'] ?? 'Unknown',
    'zip' => $data['zip'] ?? 'Unknown',
    'region' => $data['regionName'] ?? 'Unknown',
    'country' => $data['country'] ?? 'Unknown',
    'countryCode' => $data['countryCode'] ?? 'XX',
    'isp' => $data['isp'] ?? 'Unknown',
    'org' => $data['org'] ?? 'Unknown',
    'as' => $data['as'] ?? 'Unknown',
    'mobile' => $data['mobile'] ?? false,
    'proxy' => $data['proxy'] ?? false,
    'hosting' => $data['hosting'] ?? false,
    'vpn' => $data['proxy'] ?? false
];

// Security checks
$blocked = false;
$blockReason = '';

// Check 1: Country restriction
if (!in_array($data['countryCode'], $allowedCountries)) {
    $blocked = true;
    $blockReason = 'country';
}

// Check 2: Proxy/VPN detection
if ($data['proxy'] === true) {
    $blocked = true;
    $blockReason = 'proxy';
}

// Check 3: Hosting/Datacenter detection
if ($data['hosting'] === true) {
    $blocked = true;
    $blockReason = 'hosting';
}

// Check 4: Suspicious User-Agent
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
$botPatterns = [
    'bot', 'crawl', 'spider', 'slurp', 'curl', 'wget', 'python',
    'java', 'perl', 'ruby', 'php', 'httpclient', 'libwww',
    'headless', 'phantom', 'selenium', 'puppeteer', 'playwright'
];

$userAgentLower = strtolower($userAgent);
foreach ($botPatterns as $pattern) {
    if (strpos($userAgentLower, $pattern) !== false) {
        $blocked = true;
        $blockReason = 'bot';
        break;
    }
}

// Check 5: Empty or suspicious User-Agent
if (empty($userAgent) || strlen($userAgent) < 20) {
    $blocked = true;
    $blockReason = 'suspicious_ua';
}

// Check 6: Missing headers (typical of bots)
$requiredHeaders = ['HTTP_ACCEPT', 'HTTP_ACCEPT_LANGUAGE'];
foreach ($requiredHeaders as $header) {
    if (empty($_SERVER[$header])) {
        $blocked = true;
        $blockReason = 'missing_headers';
        break;
    }
}

// Store security status
$_SESSION['security_passed'] = !$blocked;
$_SESSION['security_time'] = time();
$_SESSION['block_reason'] = $blockReason;

// If blocked, redirect to blocked page
if ($blocked) {
    // Log blocked attempt
    $logData = date('Y-m-d H:i:s') . " | IP: $userIP | Country: {$data['countryCode']} | Reason: $blockReason | UA: $userAgent\n";
    @file_put_contents(__DIR__ . '/logs/blocked.log', $logData, FILE_APPEND | LOCK_EX);

    header('Location: blocked.php?r=' . $blockReason);
    exit;
}

// Log successful access
$logData = date('Y-m-d H:i:s') . " | IP: $userIP | Country: {$data['countryCode']} | City: {$data['city']} | ISP: {$data['isp']}\n";
@file_put_contents(__DIR__ . '/logs/access.log', $logData, FILE_APPEND | LOCK_EX);
?>
