<?php
$reason = $_GET['r'] ?? 'unknown';

$messages = [
    'country' => [
        'title' => 'Palvelu ei ole saatavilla',
        'text' => 'Tämä palvelu on saatavilla vain Suomessa ja Ranskassa.',
        'icon' => 'location'
    ],
    'proxy' => [
        'title' => 'VPN/Proxy havaittu',
        'text' => 'Turvallisuussyistä emme salli VPN- tai välityspalvelimen käyttöä.',
        'icon' => 'shield'
    ],
    'hosting' => [
        'title' => 'Pääsy estetty',
        'text' => 'Palvelinkeskusten IP-osoitteet on estetty.',
        'icon' => 'server'
    ],
    'bot' => [
        'title' => 'Automaattinen liikenne havaittu',
        'text' => 'Pyyntösi on tunnistettu automaattiseksi.',
        'icon' => 'robot'
    ],
    'suspicious_ua' => [
        'title' => 'Epäilyttävä pyyntö',
        'text' => 'Pyyntöäsi ei voitu vahvistaa.',
        'icon' => 'warning'
    ],
    'missing_headers' => [
        'title' => 'Virheellinen pyyntö',
        'text' => 'Pyyntösi puuttuu tarvittavia tietoja.',
        'icon' => 'error'
    ],
    'unknown' => [
        'title' => 'Pääsy estetty',
        'text' => 'Et voi käyttää tätä palvelua tällä hetkellä.',
        'icon' => 'block'
    ]
];

$msg = $messages[$reason] ?? $messages['unknown'];
?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Pääsy estetty - Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Posti Font',Arial,sans-serif;background:#f7f7f7;color:#2A2B2D;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}

.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 24px;}
.tb-logo-text{font-size:28px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;}

.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:20px;}

.block-card{background:#fff;border-radius:20px;box-shadow:0 8px 40px rgba(0,0,0,0.1);padding:50px;text-align:center;max-width:480px;width:100%;}

.block-icon{width:100px;height:100px;margin:0 auto 28px;background:#FEE2E2;border-radius:50%;display:flex;align-items:center;justify-content:center;}
.block-icon svg{width:48px;height:48px;fill:#DC2626;}

.block-card h1{font-size:24px;font-weight:800;color:#991B1B;margin-bottom:12px;}
.block-card p{font-size:15px;color:#666;line-height:1.6;}

.error-code{margin-top:24px;padding:16px;background:#f9f9f9;border-radius:10px;font-size:12px;color:#999;}

footer{background:#fff;border-top:1px solid #e5e5e5;padding:20px;text-align:center;font-size:12px;color:#888;}

@media(max-width:600px){
    .block-card{padding:32px 20px;margin:10px;}
    .block-card h1{font-size:20px;}
    .block-icon{width:80px;height:80px;}
    .block-icon svg{width:40px;height:40px;}
}
</style>
</head>
<body>

<div class="tb">
    <span class="tb-logo-text">posti</span>
</div>

<div class="page-content">
    <div class="block-card">
        <div class="block-icon">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15v-2h2v2h-2zm0-4V7h2v6h-2z"/></svg>
        </div>
        <h1><?php echo htmlspecialchars($msg['title']); ?></h1>
        <p><?php echo htmlspecialchars($msg['text']); ?></p>
        <div class="error-code">
            Virhekoodi: <?php echo strtoupper($reason); ?> | <?php echo date('d.m.Y H:i'); ?>
        </div>
    </div>
</div>

<footer>© Posti Group Oyj</footer>
</body>
</html>
