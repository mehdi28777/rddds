<?php
/**
 * Générateur d'image Captcha
 * Crée une image avec le code captcha déformé
 */

// Démarrage de session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Vérifier que le captcha existe en session
if (!isset($_SESSION['captcha']) || !isset($_SESSION['captcha']['code'])) {
    // Générer une image d'erreur
    header('Content-Type: image/png');
    $img = imagecreatetruecolor(300, 100);
    $bgColor = imagecolorallocate($img, 255, 255, 255);
    $textColor = imagecolorallocate($img, 255, 0, 0);
    imagefill($img, 0, 0, $bgColor);
    imagestring($img, 5, 80, 40, 'ERROR', $textColor);
    imagepng($img);
    imagedestroy($img);
    exit();
}

$code = $_SESSION['captcha']['code'];

// Dimensions de l'image
$width = 300;
$height = 100;

// Créer l'image
$img = imagecreatetruecolor($width, $height);

// Couleurs aléatoires
$bgColor = imagecolorallocate($img, rand(240, 255), rand(240, 255), rand(240, 255));
$textColor = imagecolorallocate($img, rand(0, 100), rand(0, 100), rand(0, 100));

// Remplir le fond
imagefill($img, 0, 0, $bgColor);

// Ajouter du bruit (points aléatoires)
for ($i = 0; $i < 200; $i++) {
    $noiseColor = imagecolorallocate($img, rand(150, 200), rand(150, 200), rand(150, 200));
    imagesetpixel($img, rand(0, $width), rand(0, $height), $noiseColor);
}

// Ajouter des lignes de bruit
for ($i = 0; $i < 5; $i++) {
    $lineColor = imagecolorallocate($img, rand(150, 220), rand(150, 220), rand(150, 220));
    imageline($img, rand(0, $width), rand(0, $height), rand(0, $width), rand(0, $height), $lineColor);
}

// Ajouter des cercles de bruit
for ($i = 0; $i < 3; $i++) {
    $circleColor = imagecolorallocate($img, rand(180, 240), rand(180, 240), rand(180, 240));
    imageellipse($img, rand(0, $width), rand(0, $height), rand(20, 50), rand(20, 50), $circleColor);
}

// Chemins possibles pour les polices
$fontPaths = [
    '/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',
    '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf',
    '/System/Library/Fonts/Supplemental/Arial Bold.ttf',
    'C:\\Windows\\Fonts\\arialbd.ttf'
];

$fontPath = null;
foreach ($fontPaths as $path) {
    if (file_exists($path)) {
        $fontPath = $path;
        break;
    }
}

// Position de départ
$x = 20;
$y = 65;

// Dessiner chaque caractère avec déformation
$codeLength = strlen($code);
$spacing = ($width - 40) / $codeLength;

for ($i = 0; $i < $codeLength; $i++) {
    $char = $code[$i];

    // Couleur aléatoire pour chaque caractère
    $charColor = imagecolorallocate($img, rand(0, 100), rand(0, 100), rand(0, 100));

    // Angle de rotation aléatoire
    $angle = rand(-25, 25);

    // Taille de police aléatoire
    $fontSize = rand(28, 36);

    // Position avec variation
    $charX = $x + ($i * $spacing) + rand(-5, 5);
    $charY = $y + rand(-10, 10);

    if ($fontPath && function_exists('imagettftext')) {
        // Utiliser TrueType font si disponible
        imagettftext($img, $fontSize, $angle, $charX, $charY, $charColor, $fontPath, $char);
    } else {
        // Fallback avec police par défaut (plus basique)
        // Créer un effet de taille avec plusieurs dessins décalés
        for ($dx = 0; $dx < 3; $dx++) {
            for ($dy = 0; $dy < 3; $dy++) {
                imagestring($img, 5, $charX + $dx, $charY - 30 + $dy, $char, $charColor);
            }
        }
    }
}

// Ajouter une déformation ondulée
$img2 = imagecreatetruecolor($width, $height);
imagefill($img2, 0, 0, $bgColor);

for ($x = 0; $x < $width; $x++) {
    for ($y = 0; $y < $height; $y++) {
        // Déformation sinusoïdale
        $offsetX = sin($y / 10) * 3;
        $offsetY = sin($x / 10) * 3;

        $srcX = $x + $offsetX;
        $srcY = $y + $offsetY;

        if ($srcX >= 0 && $srcX < $width && $srcY >= 0 && $srcY < $height) {
            $color = imagecolorat($img, $srcX, $srcY);
            imagesetpixel($img2, $x, $y, $color);
        }
    }
}

// Headers pour l'image
header('Content-Type: image/png');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Sortir l'image
imagepng($img2, null, 9);

// Libérer la mémoire
imagedestroy($img);
imagedestroy($img2);
?>
