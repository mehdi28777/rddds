/**
 * TRACKER COMPORTEMENTAL
 * Détection bot côté client
 */

(function(){
'use strict';

let m=0,k=0,s=0;

// Mouvements souris
document.addEventListener('mousemove',()=>m++);

// Touches clavier
document.addEventListener('keydown',()=>k++);

// Scroll
window.addEventListener('scroll',()=>s++);

// Envoyer après 3 secondes
setTimeout(()=>{
    try{
        const d={
            mouse:m,
            keys:k,
            scroll:s,
            screen:screen.width+'x'+screen.height,
            tz:new Date().getTimezoneOffset(),
            lang:navigator.language,
            canvas:getCanvas()
        };

        fetch('/?r=api',{
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body:JSON.stringify({action:'track',data:d})
        }).catch(()=>{});
    }catch(e){}
},3000);

function getCanvas(){
    try{
        const c=document.createElement('canvas');
        const ctx=c.getContext('2d');
        ctx.textBaseline='top';
        ctx.font='14px Arial';
        ctx.fillText('Test',2,2);
        return c.toDataURL().substring(0,50);
    }catch(e){
        return'error';
    }
}

})();
