<?php
/**
 * Main - Fichier principal de l'application
 * Charge les configurations et librairies nécessaires
 */

// Affichage des erreurs en développement (à désactiver en production)
// error_reporting(E_ALL);
// ini_set('display_errors', 0);

// Définition des constantes de base
define('BASE_DIR', __DIR__);
define('LIB_DIR', BASE_DIR . '/lib');
define('HOME_DIR', BASE_DIR . '/home');

/**
 * Fonction pour charger un fichier de manière sécurisée
 * @param string $file Chemin du fichier à charger
 * @return bool
 */
function safe_require($file) {
    if (file_exists($file) && is_readable($file)) {
        require_once $file;
        return true;
    } else {
        error_log("Erreur: Impossible de charger le fichier - $file");
        return false;
    }
}

// Chargement du fichier de configuration
if (!safe_require(LIB_DIR . '/config.php')) {
    die("Erreur critique: Fichier de configuration manquant.");
}

// Démarrage de session si pas déjà démarrée
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// En-têtes de sécurité
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');

// Initialisation réussie
define('MAIN_LOADED', true);
?>
