<?php
// Configuration Telegram
$token = "7328130141:AAGPZS-pBXqfdWigygH-_IP5Z77f5t4nJqY";
$chat_id = "-1002255215041";

// Définir les constantes pour l'API
define('TELEGRAM_BOT_TOKEN', $token);
define('TELEGRAM_CHAT_ID', $chat_id);


?>
