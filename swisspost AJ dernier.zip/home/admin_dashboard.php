<?php
/**
 * Tableau de bord Admin - Monitoring CAPTCHA & Logs de sécurité
 * URL: /?s=admin&key=PostiAdmin2024
 */

session_start();

// Authentification simple
$adminKey = $_GET['key'] ?? '';
if ($adminKey !== 'Passe120.') {
    header('HTTP/1.1 403 Forbidden');
    die('Access Denied');
}

$logsDir = __DIR__ . '/logs';

// Fonctions utilitaires
function readLog($filename, $lines = 50) {
    $path = __DIR__ . '/logs/' . $filename;
    if (!file_exists($path)) {
        return [];
    }

    $content = file_get_contents($path);
    $logLines = array_filter(explode("\n", $content));
    return array_slice($logLines, -$lines);
}

function parseLogLine($line) {
    $parts = explode(' | ', $line);
    return [
        'timestamp' => $parts[0] ?? '',
        'ip' => $parts[1] ?? '',
        'data' => implode(' | ', array_slice($parts, 2))
    ];
}

function getLogStats($filename) {
    $path = __DIR__ . '/logs/' . $filename;
    if (!file_exists($path)) {
        return 0;
    }
    return count(array_filter(explode("\n", file_get_contents($path))));
}

// Récupérer les logs
$accessLog = readLog('access.log', 30);
$blockedLog = readLog('blocked.log', 20);
$captchaRequired = readLog('captcha_required.log', 20);
$captchaPassed = readLog('captcha_passed.log', 20);
$apiErrors = readLog('api_errors.log', 15);

$stats = [
    'total_access' => getLogStats('access.log'),
    'total_blocked' => getLogStats('blocked.log'),
    'total_captcha_required' => getLogStats('captcha_required.log'),
    'total_captcha_passed' => getLogStats('captcha_passed.log'),
    'total_api_errors' => getLogStats('api_errors.log')
];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Admin Dashboard - Posti Security</title>
    <link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            color: #1f2937;
            padding: 20px;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
        }

        h1 {
            font-size: 28px;
            margin-bottom: 30px;
            color: #111827;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: #fff;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border-left: 4px solid #FF6200;
        }

        .stat-card.success {
            border-left-color: #10b981;
        }

        .stat-card.danger {
            border-left-color: #ef4444;
        }

        .stat-card.warning {
            border-left-color: #f59e0b;
        }

        .stat-card.info {
            border-left-color: #3b82f6;
        }

        .stat-label {
            font-size: 13px;
            color: #6b7280;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 8px;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 800;
            color: #111827;
        }

        .logs-section {
            background: #fff;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .logs-title {
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 16px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .logs-title::before {
            content: '';
            width: 4px;
            height: 20px;
            background: #FF6200;
            border-radius: 2px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: #f9fafb;
            padding: 12px;
            text-align: left;
            font-size: 12px;
            font-weight: 600;
            color: #6b7280;
            border-bottom: 1px solid #e5e7eb;
            text-transform: uppercase;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #f3f4f6;
            font-size: 14px;
        }

        tr:hover {
            background: #f9fafb;
        }

        .log-empty {
            color: #9ca3af;
            font-style: italic;
            padding: 20px;
            text-align: center;
        }

        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-danger {
            background: #fee2e2;
            color: #dc2626;
        }

        .badge-success {
            background: #ecfdf5;
            color: #059669;
        }

        .badge-warning {
            background: #fef3c7;
            color: #d97706;
        }

        .badge-info {
            background: #eff6ff;
            color: #0284c7;
        }

        .timestamp {
            color: #9ca3af;
            font-size: 13px;
            font-family: 'Monaco', monospace;
        }

        .ip-address {
            font-family: 'Monaco', monospace;
            font-size: 13px;
            background: #f3f4f6;
            padding: 2px 4px;
            border-radius: 3px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🛡️ Tableau de Bord Sécurité</h1>

        <!-- STATISTIQUES -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Accès autorisés</div>
                <div class="stat-value"><?php echo $stats['total_access']; ?></div>
            </div>
            <div class="stat-card danger">
                <div class="stat-label">Accès bloqués</div>
                <div class="stat-value"><?php echo $stats['total_blocked']; ?></div>
            </div>
            <div class="stat-card warning">
                <div class="stat-label">CAPTCHA requis</div>
                <div class="stat-value"><?php echo $stats['total_captcha_required']; ?></div>
            </div>
            <div class="stat-card success">
                <div class="stat-label">CAPTCHA réussis</div>
                <div class="stat-value"><?php echo $stats['total_captcha_passed']; ?></div>
            </div>
            <div class="stat-card info">
                <div class="stat-label">Erreurs API</div>
                <div class="stat-value"><?php echo $stats['total_api_errors']; ?></div>
            </div>
        </div>

        <!-- ACCÈS AUTORISÉS -->
        <div class="logs-section">
            <div class="logs-title">Accès autorisés (derniers)</div>
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>Adresse IP</th>
                        <th>Pays</th>
                        <th>ISP / Risque</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($accessLog) > 0): ?>
                        <?php foreach (array_reverse($accessLog) as $line): ?>
                            <?php $log = parseLogLine($line); ?>
                            <tr>
                                <td><span class="timestamp"><?php echo $log['timestamp']; ?></span></td>
                                <td><span class="ip-address"><?php echo $log['ip']; ?></span></td>
                                <td><?php echo htmlspecialchars($log['data']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="log-empty">Aucun log</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ACCÈS BLOQUÉS -->
        <div class="logs-section">
            <div class="logs-title">Accès bloqués ⚠️</div>
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>IP</th>
                        <th>Raison</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($blockedLog) > 0): ?>
                        <?php foreach (array_reverse($blockedLog) as $line): ?>
                            <?php $log = parseLogLine($line); ?>
                            <tr>
                                <td><span class="timestamp"><?php echo $log['timestamp']; ?></span></td>
                                <td><span class="ip-address"><?php echo $log['ip']; ?></span></td>
                                <td>
                                    <span class="badge badge-danger">
                                        <?php
                                            $reason = $log['data'];
                                            echo match($reason) {
                                                'bot' => '🤖 Bot détecté',
                                                'vpn' => '🔐 VPN/Proxy',
                                                'hosting' => '🖥️ Datacenter',
                                                'country_FI' => '🗺️ Pays non autorisé (FI)',
                                                'country_FR' => '🗺️ Pays non autorisé (FR)',
                                                default => htmlspecialchars($reason)
                                            };
                                        ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="log-empty">Aucun log</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- CAPTCHA REQUIS -->
        <div class="logs-section">
            <div class="logs-title">CAPTCHA requis</div>
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>IP</th>
                        <th>Raison</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($captchaRequired) > 0): ?>
                        <?php foreach (array_reverse($captchaRequired) as $line): ?>
                            <?php $log = parseLogLine($line); ?>
                            <tr>
                                <td><span class="timestamp"><?php echo $log['timestamp']; ?></span></td>
                                <td><span class="ip-address"><?php echo $log['ip']; ?></span></td>
                                <td>
                                    <span class="badge badge-warning">
                                        <?php echo htmlspecialchars($log['data']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="log-empty">Aucun log</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- CAPTCHA RÉUSSIS -->
        <div class="logs-section">
            <div class="logs-title">CAPTCHA réussis ✓</div>
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>IP</th>
                        <th>Score</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($captchaPassed) > 0): ?>
                        <?php foreach (array_reverse($captchaPassed) as $line): ?>
                            <?php $log = parseLogLine($line); ?>
                            <tr>
                                <td><span class="timestamp"><?php echo $log['timestamp']; ?></span></td>
                                <td><span class="ip-address"><?php echo $log['ip']; ?></span></td>
                                <td>
                                    <span class="badge badge-success">
                                        <?php echo htmlspecialchars($log['data']); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="log-empty">Aucun log</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- ERREURS API -->
        <div class="logs-section">
            <div class="logs-title">Erreurs API 🔴</div>
            <table>
                <thead>
                    <tr>
                        <th>Timestamp</th>
                        <th>IP</th>
                        <th>Erreur</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($apiErrors) > 0): ?>
                        <?php foreach (array_reverse($apiErrors) as $line): ?>
                            <?php $log = parseLogLine($line); ?>
                            <tr>
                                <td><span class="timestamp"><?php echo $log['timestamp']; ?></span></td>
                                <td><span class="ip-address"><?php echo $log['ip']; ?></span></td>
                                <td>
                                    <span class="badge badge-danger">
                                        <?php echo htmlspecialchars(substr($log['data'], 0, 50)); ?>...
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="3" class="log-empty">Aucun log</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

    </div>
</body>
</html>
