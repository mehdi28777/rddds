<?php
session_start();
header('Content-Type: application/json');

$statusDir = __DIR__ . '/status';
$sessionId = $_SESSION['session_id'] ?? null;

if (!$sessionId) {
    echo json_encode(['status' => 'error', 'message' => 'No session']);
    exit;
}

$statusFile = "$statusDir/$sessionId.txt";

if (!file_exists($statusFile)) {
    echo json_encode(['status' => 'pending']);
    exit;
}

$status = trim(file_get_contents($statusFile));

echo json_encode(['status' => $status]);
?>
