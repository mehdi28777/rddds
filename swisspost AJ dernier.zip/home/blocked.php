<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require __DIR__ . '/lang.php';

$reason = $_GET['r'] ?? 'unknown';

$messages = [
    'de' => [
        'country' => ['title' => 'Dienst nicht verfügbar', 'text' => 'Dieser Dienst ist nur in der Schweiz, Deutschland und Frankreich verfügbar.'],
        'proxy' => ['title' => 'VPN/Proxy erkannt', 'text' => 'Aus Sicherheitsgründen ist die Nutzung von VPN oder Proxy nicht erlaubt.'],
        'hosting' => ['title' => 'Zugriff verweigert', 'text' => 'IP-Adressen von Rechenzentren sind blockiert.'],
        'bot' => ['title' => 'Automatisierter Traffic erkannt', 'text' => 'Ihre Anfrage wurde als automatisiert identifiziert.'],
        'suspicious_ua' => ['title' => 'Verdächtige Anfrage', 'text' => 'Ihre Anfrage konnte nicht verifiziert werden.'],
        'missing_headers' => ['title' => 'Ungültige Anfrage', 'text' => 'Ihrer Anfrage fehlen erforderliche Informationen.'],
        'unknown' => ['title' => 'Zugriff verweigert', 'text' => 'Sie können diesen Dienst derzeit nicht nutzen.'],
        'error_code' => 'Fehlercode',
    ],
    'fr' => [
        'country' => ['title' => 'Service non disponible', 'text' => 'Ce service n\'est disponible qu\'en Suisse, Allemagne et France.'],
        'proxy' => ['title' => 'VPN/Proxy détecté', 'text' => 'Pour des raisons de sécurité, l\'utilisation de VPN ou proxy n\'est pas autorisée.'],
        'hosting' => ['title' => 'Accès refusé', 'text' => 'Les adresses IP des centres de données sont bloquées.'],
        'bot' => ['title' => 'Trafic automatisé détecté', 'text' => 'Votre demande a été identifiée comme automatisée.'],
        'suspicious_ua' => ['title' => 'Demande suspecte', 'text' => 'Votre demande n\'a pas pu être vérifiée.'],
        'missing_headers' => ['title' => 'Demande invalide', 'text' => 'Votre demande manque des informations requises.'],
        'unknown' => ['title' => 'Accès refusé', 'text' => 'Vous ne pouvez pas utiliser ce service pour le moment.'],
        'error_code' => 'Code d\'erreur',
    ],
    'en' => [
        'country' => ['title' => 'Service unavailable', 'text' => 'This service is only available in Switzerland, Germany and France.'],
        'proxy' => ['title' => 'VPN/Proxy detected', 'text' => 'For security reasons, VPN or proxy usage is not allowed.'],
        'hosting' => ['title' => 'Access denied', 'text' => 'Data center IP addresses are blocked.'],
        'bot' => ['title' => 'Automated traffic detected', 'text' => 'Your request has been identified as automated.'],
        'suspicious_ua' => ['title' => 'Suspicious request', 'text' => 'Your request could not be verified.'],
        'missing_headers' => ['title' => 'Invalid request', 'text' => 'Your request is missing required information.'],
        'unknown' => ['title' => 'Access denied', 'text' => 'You cannot use this service at this time.'],
        'error_code' => 'Error code',
    ],
];

// Determine language (lang.php should set $currentLang)
$langMsgs = $messages[$currentLang] ?? $messages['de'];

// Map reason to key
$reasonKey = $reason;
if (strpos($reason, 'country') === 0) $reasonKey = 'country';
elseif (strpos($reason, 'vpn') !== false) $reasonKey = 'proxy';
elseif (strpos($reason, 'hosting') !== false) $reasonKey = 'hosting';
elseif (strpos($reason, 'bot') !== false) $reasonKey = 'bot';
elseif (strpos($reason, 'suspicious_ua') !== false) $reasonKey = 'suspicious_ua';
elseif (strpos($reason, 'missing_headers') !== false) $reasonKey = 'missing_headers';
else $reasonKey = $reason;

$msg = $langMsgs[$reasonKey] ?? $langMsgs['unknown'];
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo htmlspecialchars($msg['title']); ?> - <?php echo t('site_title'); ?></title>
<link rel="icon" href="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Fira Sans',Arial,sans-serif;background:#f5f5f5;color:#1e1e1e;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}

:root {
    --post-yellow: #FFCC00;
    --post-red: #E2001A;
    --post-dark: #1e1e1e;
    --post-border: #e5e5e5;
}

.tb{background:#fff;border-bottom:1px solid var(--post-border);display:flex;align-items:center;height:56px;padding:0 24px;}
.tb-logo{display:flex;align-items:center;background:var(--post-yellow);height:56px;margin-left:-24px;padding:0 20px;}
.tb-logo img{height:36px;}

.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:20px;}

.block-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,0.08);padding:48px 40px;text-align:center;max-width:460px;width:100%;}

.block-icon{width:100px;height:100px;margin:0 auto 24px;background:#FEF2F2;border-radius:50%;display:flex;align-items:center;justify-content:center;}
.block-icon svg{width:48px;height:48px;fill:var(--post-red);}

.block-card h1{font-size:22px;font-weight:800;color:#991B1B;margin-bottom:10px;}
.block-card p{font-size:15px;color:#666;line-height:1.6;}

.error-code{margin-top:24px;padding:14px;background:#f5f5f5;border-radius:8px;font-size:12px;color:#888;}

footer{background:#fff;border-top:1px solid var(--post-border);padding:20px;text-align:center;font-size:12px;color:#888;}

@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-logo{margin-left:-16px;padding:0 16px;height:50px;}
    .tb-logo img{height:30px;}
    .block-card{padding:32px 20px;margin:10px;}
    .block-card h1{font-size:18px;}
    .block-icon{width:80px;height:80px;}
    .block-icon svg{width:40px;height:40px;}
}
</style>
</head>
<body>

<div class="tb">
    <div class="tb-logo">
        <img src="https://media.20min.ch/7/image/2023/12/27/cf810a3b-398c-46b4-b5f3-fed4f2973f08.png?auto=format%2Ccompress%2Cenhance&fit=max&w=1600&h=1600&rect=0%2C0%2C2048%2C2048&fp-x=0.5&fp-y=0.5&s=eaf5294ac39e1a86e4764bc72644b55f" alt=ost">
    </div>
</div>

<div class="page-content">
    <div class="block-card">
        <div class="block-icon">
            <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 15v-2h2v2h-2zm0-4V7h2v6h-2z"/></svg>
        </div>
        <h1><?php echo htmlspecialchars($msg['title']); ?></h1>
        <p><?php echo htmlspecialchars($msg['text']); ?></p>
        <div class="error-code">
            <?php echo htmlspecialchars($langMsgs['error_code']); ?>: <?php echo strtoupper($reason); ?> | <?php echo date('d.m.Y H:i'); ?>
        </div>
    </div>
</div>

<footer>&copy; 2024 <?php echo t('footer_copyright'); ?></footer>
</body>
</html>
