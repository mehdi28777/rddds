<?php 
require_once "../cors.php";
require_once './func.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['bin']) && isset($_GET['PWD']) && $_GET['PWD'] === 'BLACKFORCE') {

    $bin = $_GET['bin'];

    $response = fetch_bin_data($bin);
    echo $response;

}