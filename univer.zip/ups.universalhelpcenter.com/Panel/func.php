<?php

define('ACTIONS_FILE', './action/actions.json');

// ─── Utilitaires fichier JSON ─────────────────────────────────────────────────

function readActionsFile(): array
{
    if (!file_exists(ACTIONS_FILE)) {
        throw new RuntimeException("Fichier introuvable : " . ACTIONS_FILE);
    }

    $raw  = file_get_contents(ACTIONS_FILE);
    $data = json_decode($raw, true);

    if (!is_array($data) || !isset($data['actions'])) {
        throw new RuntimeException("JSON invalide ou structure incorrecte : " . ACTIONS_FILE);
    }

    return $data;
}

function writeActionsFile(array $data): void
{
    $result = file_put_contents(
        ACTIONS_FILE,
        json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );

    if ($result === false) {
        throw new RuntimeException("Impossible d'écrire dans : " . ACTIONS_FILE);
    }
}

function findActionIndex(array $actions, string $id): int
{
    foreach ($actions as $index => $action) {
        if (($action['id'] ?? null) === $id) {
            return $index;
        }
    }
    return -1;
}

// ─── Fonctions principales ────────────────────────────────────────────────────

/**
 * Réinitialise le step d'une action par son ID.
 */
function update(string $id): string
{
    try {
        $data  = readActionsFile();
        $index = findActionIndex($data['actions'], $id);

        if ($index === -1) {
            throw new RuntimeException("Action ID '{$id}' introuvable.");
        }

        $data['actions'][$index]['step'] = '';
        writeActionsFile($data);

        return "Step réinitialisé avec succès.";
    } catch (RuntimeException $e) {
        error_log("[update] " . $e->getMessage());
        return "Erreur : " . $e->getMessage();
    }
}

/**
 * Retourne le step d'une action par son ID.
 */
function response(string $id): string
{
    try {
        $data  = readActionsFile();
        $index = findActionIndex($data['actions'], $id);

        if ($index === -1) {
            return 'unknown';
        }

        return (string)($data['actions'][$index]['step'] ?? '');
    } catch (RuntimeException $e) {
        error_log("[response] " . $e->getMessage());
        return "Erreur : " . $e->getMessage();
    }
}

/**
 * Retourne step + text + input d'une action par son ID.
 */
function response_custom(string $id): array|string
{
    try {
        $data  = readActionsFile();
        $index = findActionIndex($data['actions'], $id);

        if ($index === -1) {
            return 'unknown';
        }

        $action = $data['actions'][$index];

        return [
            'step'  => $action['step']  ?? '',
            'text'  => $action['text']  ?? '',
            'input' => $action['input'] ?? '',
        ];
    } catch (RuntimeException $e) {
        error_log("[response_custom] " . $e->getMessage());
        return "Erreur : " . $e->getMessage();
    }
}

/**
 * Lookup BIN via l'API Binlist.
 * Retourne un tableau décodé ou null en cas d'erreur.
 */
function fetch_bin_data(string $bin): array|null
{
    // Validation basique : BIN = 6 à 8 chiffres
    if (!preg_match('/^\d{6,8}$/', $bin)) {
        error_log("[fetch_bin_data] BIN invalide : {$bin}");
        return null;
    }

    $url = 'https://lookup.binlist.net/' . urlencode($bin);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Accept-Version: 3'],
        CURLOPT_SSL_VERIFYPEER => true,   // Toujours vérifier en prod
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_USERAGENT      => 'Mozilla/5.0',
    ]);

    $response  = curl_exec($ch);
    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        error_log("[fetch_bin_data] cURL error : {$curlError}");
        return null;
    }

    if ($httpCode !== 200) {
        error_log("[fetch_bin_data] HTTP {$httpCode} pour BIN {$bin}");
        return null;
    }

    $decoded = json_decode($response, true);

    if (!is_array($decoded)) {
        error_log("[fetch_bin_data] Réponse JSON invalide pour BIN {$bin}");
        return null;
    }

    return $decoded;
}

/**
 * Met à jour un fichier INI section par section.
 */
function update_ini(array $data, string $file): bool
{
    if (!file_exists($file) || !is_writable($file)) {
        error_log("[update_ini] Fichier inaccessible : {$file}");
        return false;
    }

    $existing = parse_ini_file($file, true);
    if ($existing === false) {
        error_log("[update_ini] Impossible de parser : {$file}");
        return false;
    }

    // Merge : on écrase uniquement les clés fournies
    $merged = array_merge($existing, $data);

    $content = '';
    foreach ($merged as $key => $value) {
        if (is_array($value)) {
            // Section INI [section]
            $content .= "\n[{$key}]\n";
            foreach ($value as $k => $v) {
                $content .= "{$k} = " . (is_bool($v) ? ($v ? 'true' : 'false') : $v) . "\n";
            }
        } else {
            $content .= "{$key} = " . (is_bool($value) ? ($value ? 'true' : 'false') : $value) . "\n";
        }
    }

    $handle = fopen($file, 'w');
    if (!$handle) {
        error_log("[update_ini] Impossible d'ouvrir en écriture : {$file}");
        return false;
    }

    fwrite($handle, $content);
    fclose($handle);

    return true;
}