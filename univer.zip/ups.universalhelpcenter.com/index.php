<?php
/**
 * index.php — Page principale sécurisée
 * Vérification anti-bot directe via ip-api.com (pro).
 * Remplace index.html — supprimer ou renommer l'ancien.
 */

// ─── Configuration ────────────────────────────────────────────────────────────
define('IPAPI_KEY',    'NCx0PDVOcBsh1pQ');
define('CACHE_DIR',    __DIR__ . '/ip_cache');
define('CACHE_TTL',    3600);                       // 1h de cache par IP
define('BOT_REDIRECT', 'https://www.google.com');   // destination des bots

// ─── User-Agents bloqués (sans appel API) ─────────────────────────────────────
const BOT_UA_PATTERNS = [
    'googlebot','bingbot','slurp','duckduckbot','baiduspider',
    'yandexbot','sogou','exabot','facebot','facebookexternalhit',
    'ia_archiver','semrushbot','ahrefsbot','mj12bot','dotbot',
    'masscan','zgrab','shodan','censys','python-requests',
    'python-urllib','libwww-perl','curl/','wget/','go-http-client',
    'axios','node-fetch','headlesschrome','phantomjs','selenium',
    'puppeteer','playwright','nmap','nikto','sqlmap','petalbot',
    'bytespider','applebot','twitterbot','linkedinbot','rogerbot',
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getVisitorIp(): string
{
    $candidates = [
        $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '', // Cloudflare
        $_SERVER['HTTP_X_FORWARDED_FOR']  ?? '', // Proxy / LB
        $_SERVER['HTTP_X_REAL_IP']        ?? '', // Nginx
        $_SERVER['REMOTE_ADDR']           ?? '',
    ];

    foreach ($candidates as $ip) {
        $ip = trim(explode(',', $ip)[0]);
        if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
            return $ip;
        }
    }

    return trim($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0');
}

function isBotUserAgent(): bool
{
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ($ua === '') return true;

    foreach (BOT_UA_PATTERNS as $pattern) {
        if (str_contains($ua, $pattern)) return true;
    }
    return false;
}

function getCachePath(string $ip): string
{
    return CACHE_DIR . '/' . md5($ip) . '.json';
}

function getCachedResult(string $ip): ?array
{
    $path = getCachePath($ip);
    if (!file_exists($path)) return null;

    $data = json_decode(file_get_contents($path), true);
    if (!$data || (time() - ($data['ts'] ?? 0)) > CACHE_TTL) {
        @unlink($path);
        return null;
    }
    return $data['result'];
}

function setCachedResult(string $ip, array $result): void
{
    if (!is_dir(CACHE_DIR)) {
        mkdir(CACHE_DIR, 0700, true);
        file_put_contents(CACHE_DIR . '/.htaccess', "Deny from all\n");
    }
    file_put_contents(
        getCachePath($ip),
        json_encode(['ts' => time(), 'result' => $result])
    );
}

/**
 * Appel direct ip-api.com pro — ta méthode exacte, avec fallback.
 */
function getIpData(string $ip): array
{
    $data = @json_decode(
        @file_get_contents(
            'https://pro.ip-api.com/json/' . $ip
            . '?key=' . IPAPI_KEY . '&fields=21164031'
        ),
        true
    );

    if ($data === null || !isset($data['status'])) {
        // Fallback si l'API est injoignable — fail-open
        return [
            'status'      => 'success',
            'isp'         => 'Unknown ISP',
            'org'         => 'Unknown Org',
            'proxy'       => false,
            'hosting'     => false,
            'country'     => 'Unknown Country',
            'countryCode' => 'US',
            'city'        => 'Unknown City',
            'zip'         => 'Unknown Zip',
            'as'          => 'Unknown AS',
            'mobile'      => false,
        ];
    }

    return $data;
}

/**
 * Décide si les données ip-api correspondent à un bot.
 */
function isIpBot(array $data): bool
{
    if (($data['status'] ?? '') !== 'success') return true;
    if ($data['proxy']   ?? false)             return true;
    if ($data['hosting'] ?? false)             return true;
    return false;
}

function blockBot(): never
{
    header('Location: ' . BOT_REDIRECT, true, 302);
    exit;
}

function serveApp(): never
{
    ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/favicon.ico" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Track</title>
    <meta name="robots" content="noindex, nofollow, noarchive, nosnippet" />
    <script type="module" crossorigin src="/assets/index-D9ylUgtY.js"></script>
    <link rel="stylesheet" crossorigin href="/assets/index-CNJ9uCtU.css">
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
    <?php
    exit;
}

// ─── Pipeline de vérification ─────────────────────────────────────────────────

// 1. User-Agent — bloquage immédiat, zéro appel API
if (isBotUserAgent()) {
    blockBot();
}

// 2. Header Accept vide — signature fréquente des scrapers
if (empty($_SERVER['HTTP_ACCEPT'] ?? '')) {
    blockBot();
}

// 3. IP réelle du visiteur
$ip = getVisitorIp();

// 4. Cache — évite un appel API à chaque page view
$cached = getCachedResult($ip);

if ($cached !== null) {
    isIpBot($cached) ? blockBot() : serveApp();
}

// 5. Appel ip-api.com (ta méthode)
$data = getIpData($ip);

// 6. Mise en cache du résultat
setCachedResult($ip, $data);

// 7. Décision finale
isIpBot($data) ? blockBot() : serveApp();