<?php
http_response_code(404);
header('Content-Type: text/plain; charset=utf-8');
die('404 Not Found: The page you are looking for does not exist.');
?>