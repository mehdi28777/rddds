<?php
/**
 * Telegram Webhook Setup Script
 * Access: home/setup_webhook.php?key=Passe120.
 */

$adminKey = 'Passe120.';

if (!isset($_GET['key']) || $_GET['key'] !== $adminKey) {
    http_response_code(403);
    die('<!DOCTYPE html><html><head><meta charset="UTF-8"><title>403</title></head><body style="font-family:Arial;text-align:center;padding:50px;"><h1>403 Forbidden</h1><p>Access Denied</p></body></html>');
}

// Path to root directory
$rootDir = dirname(__DIR__);
require $rootDir . '/config.php';

// Get current domain and build webhook URL - CORRECTED
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$domain = $_SERVER['HTTP_HOST'];

// Get the base path of the application
$scriptPath = $_SERVER['SCRIPT_NAME'];
$basePath = dirname(dirname($scriptPath)); // Go up from /home/setup_webhook.php to root
if ($basePath === '/' || $basePath === '\\') {
    $basePath = '';
}

// The callback.php is in /home/callback.php
$webhookUrl = "$protocol://$domain$basePath/home/callback.php";

$action = $_GET['action'] ?? 'info';

// Function to make Telegram API call
function telegramApiCall($method, $params = []) {
    global $token;
    $url = "https://api.telegram.org/bot$token/$method";

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);

    if (!empty($params)) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);
    }

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Execute action
$result = null;
$message = '';

switch ($action) {
    case 'set':
        $result = telegramApiCall('setWebhook', ['url' => $webhookUrl]);
        $message = 'Setting webhook...';
        break;
    case 'delete':
        $result = telegramApiCall('deleteWebhook');
        $message = 'Deleting webhook...';
        break;
    case 'info':
    default:
        $result = telegramApiCall('getWebhookInfo');
        $message = 'Getting webhook info...';
        break;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webhook Setup - Posti Admin</title>
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{font-family:Arial,sans-serif;background:#1a1a2e;color:#fff;padding:20px;min-height:100vh;}
        .container{max-width:800px;margin:0 auto;}
        h1{color:#FF6200;margin-bottom:30px;text-align:center;}
        .card{background:#16213e;border-radius:12px;padding:25px;margin-bottom:20px;}
        .card h2{color:#FF6200;margin-bottom:15px;font-size:18px;}
        .info{background:#0f0f1a;padding:15px;border-radius:8px;font-family:monospace;font-size:12px;overflow-x:auto;white-space:pre-wrap;word-break:break-all;}
        .status{padding:10px 15px;border-radius:8px;margin-bottom:15px;font-weight:bold;}
        .status.success{background:#27ae60;color:#fff;}
        .status.error{background:#e74c3c;color:#fff;}
        .status.pending{background:#f39c12;color:#000;}
        .actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px;}
        .btn{padding:12px 25px;border-radius:8px;font-weight:bold;cursor:pointer;text-decoration:none;display:inline-block;border:none;font-size:14px;}
        .btn-primary{background:#FF6200;color:#fff;}
        .btn-danger{background:#e74c3c;color:#fff;}
        .btn-info{background:#3498db;color:#fff;}
        .btn:hover{opacity:0.8;}
        .url-box{background:#0f0f1a;padding:15px;border-radius:8px;margin:15px 0;word-break:break-all;}
        .url-box label{color:#888;font-size:12px;display:block;margin-bottom:5px;}
        .url-box code{color:#27ae60;font-size:13px;}
        table{width:100%;border-collapse:collapse;margin-top:10px;}
        td{padding:8px;border-bottom:1px solid #2a2a4a;font-size:14px;}
        td:first-child{color:#888;width:150px;}
        .nav{display:flex;justify-content:center;gap:10px;margin-bottom:30px;flex-wrap:wrap;}
        .nav a{padding:10px 20px;background:#16213e;color:#fff;text-decoration:none;border-radius:8px;font-size:14px;}
        .nav a:hover{background:#FF6200;}
        @media(max-width:600px){
            .card{padding:15px;}
            .actions{flex-direction:column;}
            .btn{width:100%;text-align:center;}
            td{display:block;width:100%;}
            td:first-child{border-bottom:none;padding-bottom:0;}
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>⚙️ Webhook Setup</h1>

        <div class="nav">
            <a href="admin/admin.php?key=<?php echo $adminKey; ?>">🎛️ Panel Admin</a>
            <a href="setup_webhook.php?key=<?php echo $adminKey; ?>">🔄 Actualiser</a>
        </div>

        <div class="card">
            <h2>📡 Webhook URL</h2>
            <div class="url-box">
                <label>URL du callback:</label>
                <code><?php echo htmlspecialchars($webhookUrl); ?></code>
            </div>
            <p style="color:#888;font-size:12px;margin-top:10px;">
                ⚠️ <strong>Important:</strong> Votre site doit utiliser HTTPS pour que le webhook fonctionne.
            </p>
        </div>

        <div class="card">
            <h2>📊 Résultat: <?php echo $message; ?></h2>
            <?php if ($result): ?>
                <div class="status <?php echo ($result['ok'] ?? false) ? 'success' : 'error'; ?>">
                    <?php echo ($result['ok'] ?? false) ? '✅ Succès' : '❌ Erreur'; ?>
                </div>
                <div class="info"><?php echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE); ?></div>
            <?php else: ?>
                <div class="status error">❌ Échec de connexion à l'API Telegram</div>
            <?php endif; ?>
        </div>

        <?php if ($action === 'info' && isset($result['result'])): ?>
        <div class="card">
            <h2>📋 Détails du Webhook</h2>
            <table>
                <tr><td>URL:</td><td><?php echo $result['result']['url'] ?: '<em style="color:#888;">Non configuré</em>'; ?></td></tr>
                <tr><td>Certificat custom:</td><td><?php echo $result['result']['has_custom_certificate'] ? 'Oui' : 'Non'; ?></td></tr>
                <tr><td>Updates en attente:</td><td><?php echo $result['result']['pending_update_count'] ?? 0; ?></td></tr>
                <?php if (isset($result['result']['last_error_message'])): ?>
                <tr><td>Dernière erreur:</td><td style="color:#e74c3c;"><?php echo $result['result']['last_error_message']; ?></td></tr>
                <tr><td>Date erreur:</td><td><?php echo isset($result['result']['last_error_date']) ? date('d/m/Y H:i:s', $result['result']['last_error_date']) : '-'; ?></td></tr>
                <?php endif; ?>
            </table>
        </div>
        <?php endif; ?>

        <div class="card">
            <h2>⚡ Actions</h2>
            <div class="actions">
                <a href="?key=<?php echo $adminKey; ?>&action=info" class="btn btn-info">🔍 Vérifier Status</a>
                <a href="?key=<?php echo $adminKey; ?>&action=set" class="btn btn-primary">✅ Configurer Webhook</a>
                <a href="?key=<?php echo $adminKey; ?>&action=delete" class="btn btn-danger">❌ Supprimer Webhook</a>
            </div>
        </div>

        <div class="card">
            <h2>📝 Instructions</h2>
            <ol style="margin-left:20px;line-height:2;color:#888;font-size:14px;">
                <li>Cliquez sur <strong>"Vérifier Status"</strong> pour voir la config actuelle</li>
                <li>Cliquez sur <strong>"Configurer Webhook"</strong> pour activer les boutons Telegram</li>
                <li>Votre site <strong>doit utiliser HTTPS</strong> (requis par Telegram)</li>
                <li>Si les boutons inline ne marchent pas, utilisez les <strong>boutons URL</strong></li>
                <li>Vous pouvez aussi utiliser le <strong>Panel Admin</strong> directement</li>
            </ol>
        </div>

        <div class="card">
            <h2>💡 Note</h2>
            <p style="color:#888;font-size:14px;line-height:1.6;">
                Les boutons <strong>URL</strong> dans Telegram fonctionnent <strong>sans webhook</strong>.
                Si vous avez des problèmes avec le webhook, utilisez simplement ces boutons ou le Panel Admin.
            </p>
        </div>
    </div>
</body>
</html>
