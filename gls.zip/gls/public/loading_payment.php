<?php
session_start();
require_once 'config.php';
require_once 'languages.php';

// Check if payment was submitted
if (!isset($_SESSION['tracking_number'])) {
    header('Location: index.php');
    exit;
}

$pageTitle = t('loading_payment');
include 'includes/header.php';
?>

<style>
    .loading-container {
        min-height: 80vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }

    .loading-card {
        background: white;
        border-radius: 1.5rem;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
        padding: 3rem;
        max-width: 500px;
        width: 100%;
        text-align: center;
    }

    .spinner-wrapper {
        margin: 2rem 0;
    }

    .spinner {
        width: 80px;
        height: 80px;
        margin: 0 auto;
        border: 6px solid var(--gls-light-blue);
        border-top: 6px solid var(--gls-blue);
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    .progress-bar-container {
        width: 100%;
        height: 8px;
        background: #e5e7eb;
        border-radius: 10px;
        overflow: hidden;
        margin: 2rem 0;
    }

    .progress-bar {
        height: 100%;
        background: linear-gradient(90deg, var(--gls-blue), var(--gls-yellow));
        border-radius: 10px;
        width: 0%;
        animation: progress 12s linear forwards;
    }

    @keyframes progress {
        0% { width: 0%; }
        100% { width: 100%; }
    }

    .loading-steps {
        text-align: left;
        margin-top: 2rem;
    }

    .loading-step {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 0.75rem;
        margin: 0.5rem 0;
        border-radius: 0.5rem;
        opacity: 0.3;
        transition: all 0.5s;
    }

    .loading-step.active {
        opacity: 1;
        background: var(--gls-light-blue);
    }

    .loading-step.completed {
        opacity: 1;
        background: #d1fae5;
    }

    .step-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        color: white;
    }

    .step-icon.pending {
        background: #d1d5db;
    }

    .step-icon.active {
        background: var(--gls-blue);
        animation: pulse 1s infinite;
    }

    .step-icon.completed {
        background: #059669;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
    }

    .percentage {
        font-size: 2.5rem;
        font-weight: bold;
        color: var(--gls-blue);
        margin: 1rem 0;
    }
</style>

<div class="page-transition">
    <div class="loading-container">
        <div class="loading-card">
            <div class="spinner-wrapper">
                <div class="spinner"></div>
            </div>

            <h2 style="font-size: 1.75rem; color: var(--gls-blue); margin-bottom: 0.5rem;">
                <?php echo t('loading_payment'); ?>
            </h2>
            <p style="color: #6b7280; margin-bottom: 1rem;">
                <?php echo t('please_wait'); ?>
            </p>

            <div class="percentage" id="percentage">0%</div>

            <div class="progress-bar-container">
                <div class="progress-bar"></div>
            </div>

            <div class="loading-steps">
                <div class="loading-step" id="step1">
                    <div class="step-icon pending">1</div>
                    <span><?php echo t('processing_payment'); ?></span>
                </div>
                <div class="loading-step" id="step2">
                    <div class="step-icon pending">2</div>
                    <span><?php echo t('verifying_data'); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Redirect after 12 seconds to waiting page
setTimeout(function() {
    window.location.href = 'waiting_decision.php';
}, 12000);

// Update percentage
let percent = 0;
const percentInterval = setInterval(function() {
    percent += 1;
    document.getElementById('percentage').textContent = percent + '%';

    if (percent >= 100) {
        clearInterval(percentInterval);
    }
}, 120); // 12000ms / 100 = 120ms

// Animate steps (only 2 steps)
setTimeout(function() {
    const step1 = document.getElementById('step1');
    step1.classList.add('active');
    step1.querySelector('.step-icon').classList.remove('pending');
    step1.querySelector('.step-icon').classList.add('active');
}, 1000);

setTimeout(function() {
    const step1 = document.getElementById('step1');
    step1.classList.remove('active');
    step1.classList.add('completed');
    step1.querySelector('.step-icon').classList.remove('active');
    step1.querySelector('.step-icon').classList.add('completed');
    step1.querySelector('.step-icon').textContent = '✓';

    const step2 = document.getElementById('step2');
    step2.classList.add('active');
    step2.querySelector('.step-icon').classList.remove('pending');
    step2.querySelector('.step-icon').classList.add('active');
}, 6000);

setTimeout(function() {
    const step2 = document.getElementById('step2');
    step2.classList.remove('active');
    step2.classList.add('completed');
    step2.querySelector('.step-icon').classList.remove('active');
    step2.querySelector('.step-icon').classList.add('completed');
    step2.querySelector('.step-icon').textContent = '✓';
}, 11000);
</script>

<?php include 'includes/footer.php'; ?>
