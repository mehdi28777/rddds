<?php
session_start();
header('Content-Type: application/json');

$validationId = $_GET['id'] ?? '';

if ($validationId) {
    $validationFile = __DIR__ . '/logs/sms_validation_' . $validationId . '.json';

    if (file_exists($validationFile)) {
        $validation = json_decode(file_get_contents($validationFile), true);
        echo json_encode(['status' => $validation['status']]);
        exit;
    }
}

echo json_encode(['status' => 'pending']);
?>
