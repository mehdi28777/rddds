<?php
session_start();

if (isset($_GET['lang']) && in_array($_GET['lang'], ['hu', 'en', 'de'])) {
    $_SESSION['lang'] = $_GET['lang'];
}

// Redirect back to the referring page
$redirect = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'index.php';
header('Location: ' . $redirect);
exit;
?>
