<?php
if (!isset($_SESSION)) {
    session_start();
}
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../languages.php';

$currentLang = getCurrentLang();
?>
<!DOCTYPE html>
<html lang="<?php echo $currentLang; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <meta name="mobile-web-app-capable" content="yes">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' : ''; ?>GLS Hungary - <?php echo t('package_tracking'); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Header GLS Style -->
    <header class="gls-header">
        <div class="header-top-bar">
            <div class="container-fluid">
                <div class="header-top-content">
                    <!-- Logo -->
                    <div class="gls-logo">
                        <a href="index.php">
                            <span class="logo-text">GLS</span><span class="logo-dot">.</span>
                        </a>
                    </div>

                    <!-- Right Actions -->
                    <div class="header-actions">
                        <!-- Search Icon -->
                        <button class="header-icon-btn" aria-label="<?php echo t('search'); ?>">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                            </svg>
                        </button>

                        <!-- Country -->
                        <div class="header-country">
                            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <span><?php echo t('hungary'); ?></span>
                        </div>

                        <!-- Language Selector -->
                        <div class="header-lang">
                            <a href="set_language.php?lang=en" class="<?php echo $currentLang === 'en' ? 'active' : ''; ?>">EN</a>
                            <a href="set_language.php?lang=hu" class="<?php echo $currentLang === 'hu' ? 'active' : ''; ?>">HU</a>
                            <a href="set_language.php?lang=de" class="<?php echo $currentLang === 'de' ? 'active' : ''; ?>">DE</a>
                        </div>

                        <!-- FAQ -->
                        <a href="#" class="header-link"><?php echo t('faq'); ?></a>

                        <!-- Login -->
                        <button class="header-login-btn">
                            <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                            </svg>
                            <span><?php echo t('login'); ?></span>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Navigation Menu -->
        <nav class="gls-nav">
            <div class="container-fluid">
                <div class="nav-menu">
                    <a href="#" class="nav-item"><?php echo t('menu_business'); ?></a>
                    <a href="#" class="nav-item"><?php echo t('menu_app'); ?></a>
                    <a href="#" class="nav-item"><?php echo t('menu_points'); ?></a>
                    <a href="#" class="nav-item"><?php echo t('menu_private'); ?></a>
                    <a href="#" class="nav-item"><?php echo t('menu_company'); ?></a>
                    <a href="#" class="nav-item"><?php echo t('menu_careers'); ?></a>
                    <a href="#" class="nav-item"><?php echo t('menu_contacts'); ?></a>
                </div>
            </div>
        </nav>
    </header>
