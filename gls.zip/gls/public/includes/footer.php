<!-- GLS Footer -->
    <footer class="gls-footer">
        <div class="footer-decorative">
            <svg class="footer-arrow" viewBox="0 0 400 100" xmlns="http://www.w3.org/2000/svg">
                <line x1="0" y1="50" x2="300" y2="50" stroke="white" stroke-width="4"/>
                <polygon points="300,35 320,50 300,65" fill="#ffcb05"/>
                <circle cx="330" cy="50" r="10" fill="#ffcb05"/>
            </svg>
        </div>

        <div class="footer-main">
            <div class="container-fluid">
                <div class="footer-columns">
                    <!-- Quick Links -->
                    <div class="footer-column">
                        <h3><?php echo t('footer_quick_links'); ?></h3>
                        <ul>
                            <li><a href="index.php"><?php echo t('footer_track_trace'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_parcelshop_search'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_price_calculator'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_fuel_surcharge'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_gls_online'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_mygls'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_faq'); ?></a></li>
                        </ul>
                    </div>

                    <!-- Careers -->
                    <div class="footer-column">
                        <h3><?php echo t('footer_careers'); ?></h3>
                        <ul>
                            <li><a href="#"><?php echo t('footer_office_jobs'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_operational_jobs'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_courier_jobs'); ?></a></li>
                        </ul>
                    </div>

                    <!-- Services -->
                    <div class="footer-column">
                        <h3><?php echo t('footer_services'); ?></h3>
                        <ul>
                            <li><a href="#"><?php echo t('footer_price_offer'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_ee_region'); ?></a></li>
                            <li><a href="#"><?php echo t('footer_occasional_shipment'); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="container-fluid">
                <div class="footer-bottom-content">
                    <!-- Social Media -->
                    <div class="footer-social">
                        <a href="#" aria-label="Facebook"><svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c5.05-.5 9-4.76 9-9.95z"/></svg></a>
                        <a href="#" aria-label="LinkedIn"><svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M19 3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14m-.5 15.5v-5.3a3.26 3.26 0 0 0-3.26-3.26c-.85 0-1.84.52-2.32 1.3v-1.11h-2.79v8.37h2.79v-4.93c0-.77.62-1.4 1.39-1.4a1.4 1.4 0 0 1 1.4 1.4v4.93h2.79M6.88 8.56a1.68 1.68 0 0 0 1.68-1.68c0-.93-.75-1.69-1.68-1.69a1.69 1.69 0 0 0-1.69 1.69c0 .93.76 1.68 1.69 1.68m1.39 9.94v-8.37H5.5v8.37h2.77z"/></svg></a>
                        <a href="#" aria-label="YouTube"><svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M10 15l5.19-3L10 9v6m11.56-7.83c.13.47.22 1.1.28 1.9.07.8.1 1.49.1 2.09L22 12c0 2.19-.16 3.8-.44 4.83-.25.9-.83 1.48-1.73 1.73-.47.13-1.33.22-2.65.28-1.3.07-2.49.1-3.59.1L12 19c-4.19 0-6.8-.16-7.83-.44-.9-.25-1.48-.83-1.73-1.73-.13-.47-.22-1.1-.28-1.9-.07-.8-.1-1.49-.1-2.09L2 12c0-2.19.16-3.8.44-4.83.25-.9.83-1.48 1.73-1.73.47-.13 1.33-.22 2.65-.28 1.3-.07 2.49-.1 3.59-.1L12 5c4.19 0 6.8.16 7.83.44.9.25 1.48.83 1.73 1.73z"/></svg></a>
                        <a href="#" aria-label="TikTok"><svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M16.6 5.82s.51.5 0 0A4.278 4.278 0 0 1 15.54 3h-3.09v12.4a2.592 2.592 0 0 1-2.59 2.5c-1.42 0-2.6-1.16-2.6-2.6 0-1.72 1.66-3.01 3.37-2.48V9.66c-3.45-.46-6.47 2.22-6.47 5.64 0 3.33 2.76 5.7 5.69 5.7 3.14 0 5.69-2.55 5.69-5.7V9.01a7.35 7.35 0 0 0 4.3 1.38V7.3s-1.88.09-3.24-1.48z"/></svg></a>
                        <a href="#" aria-label="Instagram"><svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M7.8 2h8.4C19.4 2 22 4.6 22 7.8v8.4a5.8 5.8 0 0 1-5.8 5.8H7.8C4.6 22 2 19.4 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2m-.2 2A3.6 3.6 0 0 0 4 7.6v8.8C4 18.39 5.61 20 7.6 20h8.8a3.6 3.6 0 0 0 3.6-3.6V7.6C20 5.61 18.39 4 16.4 4H7.6m9.65 1.5a1.25 1.25 0 0 1 1.25 1.25A1.25 1.25 0 0 1 17.25 8 1.25 1.25 0 0 1 16 6.75a1.25 1.25 0 0 1 1.25-1.25M12 7a5 5 0 0 1 5 5 5 5 0 0 1-5 5 5 5 0 0 1-5-5 5 5 0 0 1 5-5m0 2a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg></a>
                    </div>

                    <!-- Legal Links -->
                    <div class="footer-legal">
                        <a href="#"><?php echo t('footer_privacy'); ?></a>
                        <span>|</span>
                        <a href="#"><?php echo t('footer_terms'); ?></a>
                        <span>|</span>
                        <a href="#"><?php echo t('footer_corporate'); ?></a>
                        <span>|</span>
                        <a href="#"><?php echo t('footer_disclaimer'); ?></a>
                        <span>|</span>
                        <a href="#"><?php echo t('footer_supplier'); ?></a>
                    </div>

                    <!-- Cookie & Scroll Top -->
                    <div class="footer-actions">
                        <button class="cookie-settings-btn" aria-label="<?php echo t('footer_cookie_settings'); ?>">
                            <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 3c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3zm0 14.2c-2.5 0-4.71-1.28-6-3.22.03-1.99 4-3.08 6-3.08 1.99 0 5.97 1.09 6 3.08-1.29 1.94-3.5 3.22-6 3.22z"/></svg>
                        </button>
                        <button class="scroll-top-btn" onclick="window.scrollTo({top: 0, behavior: 'smooth'})" aria-label="<?php echo t('footer_scroll_top'); ?>">
                            <svg width="24" height="24" fill="currentColor" viewBox="0 0 24 24"><path d="M7.41 15.41L12 10.83l4.59 4.58L18 14l-6-6-6 6z"/></svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>
