<?php
/**
 * Anti-Bot Protection System
 * Using pro.ip-api.com API
 */

function checkAntiBot() {
    // Get client IP
    $client_ip = $_SERVER['REMOTE_ADDR'];
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $client_ip = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0];
    }

    // API Configuration
    $api_key = "NCx0PDVOcBsh1pQ";

    $ip_api_url = "https://pro.ip-api.com/json/" . urlencode($client_ip) .
                  "?key=" . $api_key .
                  "&fields=status,country,countryCode,city,zip,as,mobile,proxy,hosting,isp,org";

    // Make API request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $ip_api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_code == 200 && $response) {
        $data = json_decode($response, true);

        // Check for suspicious activity
        $is_suspicious = false;
        $reasons = [];

        // Check if proxy
        if (isset($data['proxy']) && $data['proxy'] === true) {
            $is_suspicious = true;
            $reasons[] = 'Proxy detected';
        }

        // Check if hosting/VPS
        if (isset($data['hosting']) && $data['hosting'] === true) {
            $is_suspicious = true;
            $reasons[] = 'Hosting/VPS detected';
        }

        // Check if mobile (mobile connections are usually safe)
        if (isset($data['mobile']) && $data['mobile'] === true) {
            // Mobile is generally safe, reduce suspicion
            $is_suspicious = false;
            $reasons = []; // Clear reasons for mobile
        }

        // Log the check
        $log_data = [
            'ip' => $client_ip,
            'country' => $data['country'] ?? 'Unknown',
            'countryCode' => $data['countryCode'] ?? 'XX',
            'city' => $data['city'] ?? 'Unknown',
            'isp' => $data['isp'] ?? 'Unknown',
            'org' => $data['org'] ?? 'Unknown',
            'proxy' => $data['proxy'] ?? false,
            'hosting' => $data['hosting'] ?? false,
            'mobile' => $data['mobile'] ?? false,
            'suspicious' => $is_suspicious,
            'reasons' => implode(', ', $reasons),
            'timestamp' => date('Y-m-d H:i:s')
        ];

        // Log to file
        $log_file = __DIR__ . '/logs/antibot.log';
        $log_dir = dirname($log_file);
        if (!file_exists($log_dir)) {
            @mkdir($log_dir, 0755, true);
        }
        @file_put_contents($log_file, json_encode($log_data) . "\n", FILE_APPEND);

        // Store in session
        $_SESSION['antibot_check'] = $log_data;

        // Block if suspicious (NO TELEGRAM NOTIFICATION)
        if ($is_suspicious) {
            // BLOCK BOTS - Show error page (no Telegram alert)
            header('HTTP/1.1 403 Forbidden');
            echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Access Denied</title>';
            echo '<style>body{font-family:Arial;text-align:center;padding:50px;background:#fee2e2;}';
            echo 'h1{color:#991b1b;font-size:3rem;}p{color:#7f1d1d;font-size:1.2rem;}</style></head><body>';
            echo '<h1>🚫 Access Denied</h1>';
            echo '<p>Suspicious activity detected. Your access has been blocked.</p>';
            echo '<p>If you believe this is an error, please contact support.</p>';
            echo '</body></html>';
            die();
        }

        return [
            'allowed' => !$is_suspicious,
            'data' => $data,
            'reasons' => $reasons
        ];
    }

    // If API fails, allow by default (fail open)
    return [
        'allowed' => true,
        'data' => null,
        'reasons' => ['API check failed']
    ];
}

// Auto-run check if session is started
if (session_status() === PHP_SESSION_ACTIVE) {
    if (!isset($_SESSION['antibot_checked'])) {
        $result = checkAntiBot();
        $_SESSION['antibot_checked'] = true;

        // Log result
        error_log("ANTI-BOT CHECK: " . ($result['allowed'] ? 'ALLOWED' : 'BLOCKED'));
    }
}
?>
