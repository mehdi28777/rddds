<?php
session_start();
require_once 'config.php';
require_once 'languages.php';

// Redirect if no tracking number
if (!isset($_SESSION['tracking_number'])) {
    header('Location: index.php');
    exit;
}

// Generate transaction ID
$transaction_id = 'TXN-' . strtoupper(substr(md5(time()), 0, 9));

// Get price based on language
$currentLang = getCurrentLang();
$priceInfo = getCustomsPriceByLanguage($currentLang);

$pageTitle = t('payment_successful');
include 'includes/header.php';
?>

<div class="page-transition">
    <div class="container" style="padding: 3rem 1rem;">
        <div class="card" style="max-width: 800px;">
            <div style="text-align: center;">
                <div style="background: #d1fae5; width: 6rem; height: 6rem; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1.5rem; animation: pulse 2s infinite;">
                    <svg width="60" height="60" fill="none" stroke="#059669" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                    </svg>
                </div>

                <h1 style="font-size: 2.5rem; margin-bottom: 0.5rem; color: #059669;"><?php echo t('payment_successful'); ?></h1>
                <h2 style="font-size: 1.75rem; color: var(--gls-blue); margin-bottom: 1rem;"><?php echo t('delivery_resumed'); ?></h2>
                <p style="font-size: 1.25rem; color: #6b7280; margin-bottom: 2rem;">
                    <?php echo t('customs_paid'); ?>
                </p>

                <!-- Transaction Details -->
                <div style="background: #dbeafe; border: 1px solid #93c5fd; border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 2rem;">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; text-align: left;">
                        <div>
                            <p style="font-size: 0.875rem; color: #6b7280; margin-bottom: 0.25rem;"><?php echo t('transaction_id'); ?></p>
                            <p style="font-weight: bold; color: var(--gls-blue);"><?php echo $transaction_id; ?></p>
                        </div>
                        <div>
                            <p style="font-size: 0.875rem; color: #6b7280; margin-bottom: 0.25rem;"><?php echo t('amount'); ?></p>
                            <p style="font-weight: bold; color: var(--gls-blue);"><?php echo $priceInfo['display']; ?></p>
                        </div>
                        <div>
                            <p style="font-size: 0.875rem; color: #6b7280; margin-bottom: 0.25rem;"><?php echo t('date'); ?></p>
                            <p style="font-weight: bold;"><?php echo date('Y.m.d'); ?></p>
                        </div>
                        <div>
                            <p style="font-size: 0.875rem; color: #6b7280; margin-bottom: 0.25rem;"><?php echo t('time'); ?></p>
                            <p style="font-weight: bold;"><?php echo date('H:i'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Important Notice -->
                <div class="alert alert-success" style="margin-bottom: 2rem; text-align: left; font-size: 1rem;">
                    <strong><?php echo t('payment_completed'); ?></strong><br><br>
                    <?php echo t('customs_paid_text'); ?>
                </div>

                <!-- Package Status -->
                <div style="background: white; border: 2px solid var(--gls-blue); border-radius: 0.75rem; padding: 2rem; margin-bottom: 2rem; text-align: left;">
                    <h3 style="font-size: 1.5rem; margin-bottom: 1.5rem; display: flex; align-items: center; justify-content: center; gap: 0.5rem;">
                        <svg width="24" height="24" fill="none" stroke="var(--gls-blue)" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                        </svg>
                        <?php echo t('package_status'); ?>
                    </h3>

                    <div class="timeline">
                        <div class="timeline-item">
                            <div class="timeline-icon active">
                                <svg width="20" height="20" fill="none" stroke="#059669" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                            </div>
                            <div class="timeline-content">
                                <h4><?php echo t('package_sent'); ?></h4>
                                <p><?php echo date('Y-m-d', strtotime('-2 days')); ?> 09:30</p>
                            </div>
                        </div>

                        <div class="timeline-item">
                            <div class="timeline-icon active">
                                <svg width="20" height="20" fill="none" stroke="#059669" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                            </div>
                            <div class="timeline-content">
                                <h4><?php echo t('customs_processing'); ?></h4>
                                <p><?php echo date('Y-m-d', strtotime('-1 day')); ?> 14:20</p>
                            </div>
                        </div>

                        <div class="timeline-item">
                            <div class="timeline-icon active">
                                <svg width="20" height="20" fill="none" stroke="#059669" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                </svg>
                            </div>
                            <div class="timeline-content">
                                <h4><?php echo t('customs_fee_paid'); ?></h4>
                                <p><?php echo date('Y-m-d H:i'); ?></p>
                            </div>
                        </div>

                        <div class="timeline-item">
                            <div class="timeline-icon current">
                                <svg width="20" height="20" fill="none" stroke="#000" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"/>
                                </svg>
                            </div>
                            <div class="timeline-content">
                                <h4><?php echo t('delivery_in_progress'); ?></h4>
                                <p style="color: #059669; font-weight: bold;"><?php echo t('expected_delivery'); ?></p>
                            </div>
                        </div>

                        <div class="timeline-item">
                            <div class="timeline-icon pending">
                                <svg width="20" height="20" fill="none" stroke="#9ca3af" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                </svg>
                            </div>
                            <div class="timeline-content">
                                <h4><?php echo t('delivered'); ?></h4>
                                <p><?php echo t('in_progress'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="alert alert-success" style="margin-bottom: 2rem; font-size: 0.875rem; text-align: left;">
                    <?php echo t('email_confirmation'); ?><br>
                    <?php echo t('sms_notification'); ?> <?php echo isset($_SESSION['phone']) ? $_SESSION['phone'] : '+36 ** *** ****'; ?><br>
                    <?php echo t('track_app'); ?><br>
                    <?php echo t('courier_contact'); ?>
                </div>

                <!-- Delivery Info -->
                <?php if (isset($_SESSION['address'])): ?>
                <div style="background: #f3f4f6; border-radius: 0.75rem; padding: 1.5rem; margin-bottom: 2rem; text-align: left;">
                    <h4 style="margin-bottom: 1rem; color: var(--gls-blue);"><?php echo t('delivery_address'); ?></h4>
                    <p style="line-height: 1.8;">
                        <strong><?php echo htmlspecialchars($_SESSION['address'] ?? ''); ?></strong><br>
                        <?php echo htmlspecialchars($_SESSION['postal'] ?? ''); ?> <?php echo htmlspecialchars($_SESSION['city'] ?? ''); ?><br>
                        <?php echo htmlspecialchars($_SESSION['country'] ?? ''); ?>
                    </p>
                </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <a href="index.php" class="btn btn-primary" style="display: inline-flex; align-items: center; justify-content: center; gap: 0.5rem;" onclick="<?php session_destroy(); ?>">
                        <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                        </svg>
                        <?php echo t('back_home'); ?>
                    </a>
                    <button onclick="window.print()" class="btn btn-secondary">
                        <?php echo t('print_receipt'); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- Contact Info -->
        <div style="text-align: center; margin-top: 2rem; font-size: 0.875rem; color: #6b7280;">
            <p><?php echo t('contact_text'); ?></p>
            <p style="font-weight: bold; color: var(--gls-blue); margin-top: 0.5rem;">
                +36 1 888 8888 | info@gls-hungary.com
            </p>
        </div>
    </div>
</div>

<style>
@keyframes pulse {
    0%, 100% {
        transform: scale(1);
    }
    50% {
        transform: scale(1.05);
    }
}
</style>

<?php include 'includes/footer.php'; ?>
