<?php
session_start();
header('Content-Type: application/json');

$decisionId = $_GET['id'] ?? '';

if ($decisionId) {
    $decisionFile = __DIR__ . '/logs/decision_' . $decisionId . '.json';

    if (file_exists($decisionFile)) {
        $decision = json_decode(file_get_contents($decisionFile), true);
        echo json_encode(['action' => $decision['action']]);
        exit;
    }
}

echo json_encode(['action' => 'waiting']);
?>
