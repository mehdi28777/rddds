<?php
/**
 * Configuration hCaptcha
 * À compléter avec vos vraies clés depuis https://dashboard.hcaptcha.com
 */

// ── hCaptcha Keys ─────────────────────────────────────────────
// Obtenir les clés gratuitement : https://dashboard.hcaptcha.com
define('HCAPTCHA_SITE_KEY', '913eacae-d4fc-4dee-8762-e97ca81ad890');
define('HCAPTCHA_SECRET_KEY', 'ES_b2f3fb5406c646a78f18d60a7813a239');

// ── Configuration Antibot ─────────────────────────────────────
define('CAPTCHA_TIMEOUT', 600); // 10 minutes avant re-CAPTCHA

// IP-API Pro (optionnel, sinon utiliser la version gratuite)
define('IP_API_KEY', 'NCx0PDVOcBsh1pQ'); // Remplacer si vous en avez un autre

// ── Répertoires de logs ──────────────────────────────────────
define('LOGS_DIR', __DIR__ . '/logs');

// Créer le répertoire logs s'il n'existe pas
if (!is_dir(LOGS_DIR)) {
    @mkdir(LOGS_DIR, 0755, true);
}

// ── Allowed Countries ────────────────────────────────────────
define('ALLOWED_COUNTRIES', ['FI', 'FR']); // Finlande, France
?>
