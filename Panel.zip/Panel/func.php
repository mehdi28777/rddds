<?php
define('ACTIONS_FILE', './action/actions.json');

function update($id) {
    try {
        // Check if the actions file exists
        if (!file_exists(ACTIONS_FILE)) {
            throw new Exception("File not found: " . ACTIONS_FILE);
        }

        // Read the JSON file contents
        $fileContents = file_get_contents(ACTIONS_FILE);
        if ($fileContents === false) {
            throw new Exception("Failed to read file: " . ACTIONS_FILE);
        }

        $data = json_decode($fileContents, true);

        // Better JSON validation
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Failed to decode JSON file: " . json_last_error_msg());
        }

        // Verify data structure
        if (!isset($data['actions']) || !is_array($data['actions'])) {
            throw new Exception("Invalid data structure in JSON file");
        }

        // Update the step of the action with the specified ID
        $updated = false;
        foreach ($data['actions'] as &$action) {
            if (isset($action['id']) && $action['id'] === $id) {
                $action['step'] = "";
                $updated = true;
                break;
            }
        }
        unset($action); // Break the reference

        // Check if the action with the specified ID was found and updated
        if (!$updated) {
            throw new Exception("Action with ID " . $id . " not found.");
        }

        // Write the updated data back to the JSON file
        $jsonData = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($jsonData === false) {
            throw new Exception("Failed to encode JSON: " . json_last_error_msg());
        }

        if (file_put_contents(ACTIONS_FILE, $jsonData) === false) {
            throw new Exception("Failed to write to file: " . ACTIONS_FILE);
        }

        return "Step cleared successfully.";
    } catch (Exception $e) {
        error_log("Error in update(): " . $e->getMessage());
        return "Error: " . $e->getMessage();
    }
}


function response($ip) {
    try {
        // Check if the JSON file exists
        if (!file_exists(ACTIONS_FILE)) {
            throw new Exception("File not found: " . ACTIONS_FILE);
        }

        // Read the JSON file contents
        $fileContents = file_get_contents(ACTIONS_FILE);
        if ($fileContents === false) {
            throw new Exception("Failed to read file: " . ACTIONS_FILE);
        }

        $data = json_decode($fileContents, true);

        // Better JSON validation
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Failed to decode JSON file: " . json_last_error_msg());
        }

        // Verify data structure
        if (!isset($data['actions']) || !is_array($data['actions'])) {
            throw new Exception("Invalid data structure in JSON file");
        }

        // Find the action by ID
        foreach ($data['actions'] as $action) {
            if (isset($action['id'], $action['step']) && $action['id'] === $ip) {
                return $action['step'];
            }
        }

        return "unknown"; // ID not found
    } catch (Exception $e) {
        error_log("Error in response(): " . $e->getMessage());
        return "Error: " . $e->getMessage();
    }
}

function response_custom($ip) {
    try {
        // Check if the JSON file exists
        if (!file_exists(ACTIONS_FILE)) {
            throw new Exception("File not found: " . ACTIONS_FILE);
        }

        // Read the JSON file contents
        $fileContents = file_get_contents(ACTIONS_FILE);
        if ($fileContents === false) {
            throw new Exception("Failed to read file: " . ACTIONS_FILE);
        }

        $data = json_decode($fileContents, true);

        // Better JSON validation
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Failed to decode JSON file: " . json_last_error_msg());
        }

        // Verify data structure
        if (!isset($data['actions']) || !is_array($data['actions'])) {
            throw new Exception("Invalid data structure in JSON file");
        }

        // Find the action by ID
        foreach ($data['actions'] as $action) {
            if (isset($action['id']) && $action['id'] === $ip) {
                return [
                    'step' => $action['step'] ?? '',
                    'text' => $action['text'] ?? '',
                    'input' => $action['input'] ?? ''
                ];
            }
        }

        return "unknown"; // ID not found
    } catch (Exception $e) {
        error_log("Error in response_custom(): " . $e->getMessage());
        return "Error: " . $e->getMessage();
    }
}



function fetch_bin_data($bin) {
    // Validate BIN input (should be numeric and reasonable length)
    if (!preg_match('/^\d{6,8}$/', $bin)) {
        return json_encode(['error' => 'Invalid BIN format']);
    }

    // Define the base URL for the Binlist API
    $api_url = 'https://lookup.binlist.net/';

    // Define headers
    $headers = array(
        'Accept-Version: 3'
    );

    // Initialize cURL session
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $api_url . $bin);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // SECURITY: Always verify SSL in production
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); // Add timeout
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5); // Add connection timeout

    // Execute cURL session
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Check for errors
    if(curl_errno($ch)) {
        $error_message = curl_error($ch);
        curl_close($ch);
        error_log("cURL Error in fetch_bin_data(): $error_message");
        return json_encode(['error' => $error_message]);
    }

    // Close cURL session
    curl_close($ch);

    // Check HTTP status code
    if ($httpCode !== 200) {
        error_log("HTTP Error in fetch_bin_data(): HTTP $httpCode");
        return json_encode(['error' => "HTTP Error: $httpCode"]);
    }

    // Return the response
    return $response;
}


function update_ini($data, $file)
{
    try {
        // Validate inputs
        if (!is_array($data)) {
            error_log("update_ini(): Invalid data parameter, expected array");
            return false;
        }

        if (empty($file)) {
            error_log("update_ini(): File parameter is empty");
            return false;
        }

        $content = "";

        // Parse existing file if it exists
        if (file_exists($file)) {
            $parsed_ini = parse_ini_file($file, true);
            if ($parsed_ini === false) {
                error_log("update_ini(): Failed to parse INI file: $file");
                return false;
            }
        }

        // Build content
        foreach ($data as $section => $values) {
            if ($section === "") {
                continue;
            }
            $content .= $section . "=" . $values . PHP_EOL;
        }

        // Open file for writing
        $handle = fopen($file, 'w');
        if (!$handle) {
            error_log("update_ini(): Cannot open file for writing: $file");
            return false;
        }

        // Write content
        $success = fwrite($handle, $content);
        fclose($handle);

        if ($success === false) {
            error_log("update_ini(): Failed to write to file: $file");
            return false;
        }

        return true;
    } catch (Exception $e) {
        error_log("update_ini() Exception: " . $e->getMessage());
        return false;
    }
}
