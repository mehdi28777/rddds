<?php 
require_once "../cors.php";
require_once './func.php';

header('Content-Type: application/json'); // Ensure the response is in JSON format

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id']) && isset($_GET['PWD']) && $_GET['PWD'] === 'BLACK') {
    $id = $_GET['id'];
    $response = response_custom($id);
    echo json_encode($response); // Encode the response as JSON
} else {
    echo json_encode(['error' => 'Invalid request']); // Handle invalid requests
}
?>
