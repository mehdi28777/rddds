<?php
require_once "../../cors.php";
require_once '../func.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['PWD']) && $_GET['PWD'] === 'BLACK') {
    $filepath = 'stats.ini';
    if (file_exists($filepath) && is_readable($filepath)) {
        $data = parse_ini_file($filepath, true);

        if ($data !== false) {
            $json_data = json_encode($data);
            echo $json_data;
        } else {

            http_response_code(500);
            echo "Error parsing INI file";
        }
    } else {
        http_response_code(404);
        echo "File not found or inaccessible";
    }
}
?>
