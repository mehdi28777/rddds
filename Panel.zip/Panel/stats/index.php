<?php

echo 'snrt.com';

?>