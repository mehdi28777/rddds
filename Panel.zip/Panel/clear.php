<?php
require_once "../cors.php";
require_once './func.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id']) && isset($_GET['PWD']) && $_GET['PWD'] === 'BLACK') {
    $id = $_GET['id'];
    echo update($id);
}